<?php
/**
 * Email Module Installer
 * 
 * Automated installation script for HostBill Advanced Email Manager
 * Creates database tables, registers module, installs templates, and sets up configuration
 * 
 * @version 1.0.0
 */

// Prevent direct access
if (php_sapi_name() !== 'cli' && !defined('HOSTBILL')) {
    die('This script can only be run from command line or HostBill admin area');
}

/**
 * Main installation function
 */
function install_email_module() {
    echo "🚀 Installing HostBill Advanced Email Manager...\n";
    
    try {
        // Step 1: Create database tables
        echo "1️⃣ Creating database tables...\n";
        create_email_tables();
        echo "✅ Database tables created successfully\n";
        
        // Step 2: Register module in HostBill
        echo "2️⃣ Registering module in HostBill...\n";
        register_email_module();
        echo "✅ Module registered successfully\n";
        
        // Step 3: Install default email templates
        echo "3️⃣ Installing default email templates...\n";
        install_default_templates();
        echo "✅ Default templates installed\n";
        
        // Step 4: Set default configuration
        echo "4️⃣ Setting default configuration...\n";
        set_default_email_config();
        echo "✅ Default configuration set\n";
        
        // Step 5: Set file permissions
        echo "5️⃣ Setting file permissions...\n";
        set_email_permissions();
        echo "✅ File permissions set\n";
        
        // Step 6: Create cron job entry
        echo "6️⃣ Setting up cron job...\n";
        setup_email_cron();
        echo "✅ Cron job configured\n";
        
        echo "\n🎉 HostBill Advanced Email Manager installed successfully!\n";
        echo "\n📋 Next steps:\n";
        echo "1. Configure SMTP settings in HostBill admin\n";
        echo "2. Test SMTP connection\n";
        echo "3. Customize email templates if needed\n";
        echo "4. Enable email verification for new clients\n";
        echo "5. Set up cron job for queue processing\n";
        
        return true;
        
    } catch (Exception $e) {
        echo "❌ Installation failed: " . $e->getMessage() . "\n";
        return false;
    }
}

/**
 * Create database tables
 */
function create_email_tables() {
    // Email queue table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_queue` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `to_email` varchar(255) NOT NULL,
        `to_name` varchar(255) DEFAULT NULL,
        `from_email` varchar(255) NOT NULL,
        `from_name` varchar(255) DEFAULT NULL,
        `reply_to` varchar(255) DEFAULT NULL,
        `subject` varchar(500) NOT NULL,
        `body_html` longtext,
        `body_text` longtext,
        `attachments` text,
        `priority` tinyint(1) NOT NULL DEFAULT 5,
        `status` enum('pending','sending','sent','failed') NOT NULL DEFAULT 'pending',
        `attempts` tinyint(1) NOT NULL DEFAULT 0,
        `max_attempts` tinyint(1) NOT NULL DEFAULT 3,
        `error_message` text,
        `scheduled_at` timestamp NULL DEFAULT NULL,
        `sent_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `status` (`status`),
        KEY `priority` (`priority`),
        KEY `scheduled_at` (`scheduled_at`),
        KEY `created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_email_queue table");
    }
    
    // Email verification table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_verification` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `client_id` int(11) NOT NULL,
        `email` varchar(255) NOT NULL,
        `token` varchar(64) NOT NULL,
        `return_url` text,
        `verified` tinyint(1) NOT NULL DEFAULT 0,
        `expires_at` timestamp NOT NULL,
        `verified_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `token` (`token`),
        KEY `client_id` (`client_id`),
        KEY `email` (`email`),
        KEY `verified` (`verified`),
        KEY `expires_at` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_email_verification table");
    }
    
    // Email templates table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_templates` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `subject` varchar(500) NOT NULL,
        `body_html` longtext,
        `body_text` longtext,
        `variables` text,
        `active` tinyint(1) NOT NULL DEFAULT 1,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `name` (`name`),
        KEY `active` (`active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_email_templates table");
    }
    
    // Email log table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `client_id` int(11) DEFAULT NULL,
        `to_email` varchar(255) NOT NULL,
        `subject` varchar(500) NOT NULL,
        `template_name` varchar(100) DEFAULT NULL,
        `status` enum('sent','failed','bounced','opened','clicked') NOT NULL,
        `error_message` text,
        `sent_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `client_id` (`client_id`),
        KEY `to_email` (`to_email`),
        KEY `status` (`status`),
        KEY `sent_at` (`sent_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_email_log table");
    }
    
    // Email configuration table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_config` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting` varchar(100) NOT NULL,
        `value` text,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting` (`setting`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_email_config table");
    }
}

/**
 * Register module in HostBill
 */
function register_email_module() {
    // Check if module is already registered
    $result = full_query("SELECT id FROM tbladdonmodules WHERE module = 'email'");
    
    if (mysql_num_rows($result) == 0) {
        // Register the module
        $sql = "INSERT INTO tbladdonmodules (module, name, description, version, author, active) 
                VALUES ('email', 'Advanced Email Manager', 'Comprehensive email management with verification and automated sending', '1.0.0', 'HostBill Email Module', 1)";
        
        if (!full_query($sql)) {
            throw new Exception("Failed to register module in HostBill");
        }
    }
}

/**
 * Install default email templates
 */
function install_default_templates() {
    require_once dirname(__FILE__) . '/email-templates.php';
    install_default_email_templates();
}

/**
 * Set default configuration
 */
function set_default_email_config() {
    $defaultConfig = [
        'smtp_host' => '',
        'smtp_port' => '587',
        'smtp_security' => 'tls',
        'smtp_username' => '',
        'smtp_password' => '',
        'from_email' => '',
        'from_name' => '',
        'reply_to' => '',
        'email_verification' => 'yes',
        'verification_expiry' => '24',
        'auto_welcome_email' => 'yes',
        'auto_invoice_email' => 'yes',
        'auto_payment_email' => 'yes',
        'email_queue' => 'yes',
        'queue_batch_size' => '10',
        'debug_mode' => 'no'
    ];
    
    foreach ($defaultConfig as $setting => $value) {
        $sql = "INSERT INTO mod_email_config (setting, value) 
                VALUES ('" . mysql_real_escape_string($setting) . "', '" . mysql_real_escape_string($value) . "')
                ON DUPLICATE KEY UPDATE value = VALUES(value)";
        
        if (!full_query($sql)) {
            throw new Exception("Failed to set default configuration for: " . $setting);
        }
    }
}

/**
 * Set file permissions
 */
function set_email_permissions() {
    $module_path = dirname(__FILE__);
    
    // Set directory permissions
    if (is_dir($module_path)) {
        chmod($module_path, 0755);
    }
    
    // Set file permissions
    $files = [
        'email.php',
        'email-client.php',
        'email-templates.php',
        'verify.php',
        'hooks.php',
        'admin.php',
        'install.php'
    ];
    
    foreach ($files as $file) {
        $file_path = $module_path . '/' . $file;
        if (file_exists($file_path)) {
            chmod($file_path, 0644);
        }
    }
}

/**
 * Setup cron job
 */
function setup_email_cron() {
    // Add cron job entry to HostBill
    $cronCommand = 'php ' . dirname(__FILE__) . '/cron.php';
    
    $sql = "INSERT INTO tblcron (name, filename, description, type, lastrun, nextrun) 
            VALUES (
                'Email Queue Processing',
                '" . mysql_real_escape_string($cronCommand) . "',
                'Process email queue and send pending emails',
                'addon',
                '0000-00-00 00:00:00',
                NOW()
            )
            ON DUPLICATE KEY UPDATE filename = VALUES(filename)";
    
    full_query($sql);
    
    // Create cron.php file
    $phpTag = '<' . '?php';
    $cronContent = $phpTag . '
/**
 * Email Module Cron Job
 * Process email queue and cleanup old records
 */

require_once "../../../configuration.php";
require_once "../../../includes/functions.php";
require_once "hooks.php";

// Process email queue
$result = process_email_queue();
if ($result["success"]) {
    echo "Queue processed: " . $result["processed"] . " emails sent\\n";
} else {
    echo "Queue processing failed: " . $result["message"] . "\\n";
}

// Cleanup old records
cleanup_expired_verifications();
echo "Cleanup completed\\n";
?' . '>';
    
    file_put_contents(dirname(__FILE__) . '/cron.php', $cronContent);
    chmod(dirname(__FILE__) . '/cron.php', 0644);
}

/**
 * Uninstall function
 */
function uninstall_email_module() {
    echo "🗑️ Uninstalling HostBill Advanced Email Manager...\n";
    
    try {
        // Remove database tables
        echo "1️⃣ Removing database tables...\n";
        full_query("DROP TABLE IF EXISTS mod_email_queue");
        full_query("DROP TABLE IF EXISTS mod_email_verification");
        full_query("DROP TABLE IF EXISTS mod_email_templates");
        full_query("DROP TABLE IF EXISTS mod_email_log");
        full_query("DROP TABLE IF EXISTS mod_email_config");
        echo "✅ Database tables removed\n";
        
        // Remove module registration
        echo "2️⃣ Removing module registration...\n";
        full_query("DELETE FROM tbladdonmodules WHERE module = 'email'");
        echo "✅ Module registration removed\n";
        
        // Remove hooks
        echo "3️⃣ Removing hooks...\n";
        full_query("DELETE FROM tblhooks WHERE hook IN ('ClientAdd', 'InvoiceCreated', 'AfterModuleCreate', 'InvoiceChangeStatus', 'ClientEdit')");
        echo "✅ Hooks removed\n";
        
        // Remove cron job
        echo "4️⃣ Removing cron job...\n";
        full_query("DELETE FROM tblcron WHERE name = 'Email Queue Processing'");
        if (file_exists(dirname(__FILE__) . '/cron.php')) {
            unlink(dirname(__FILE__) . '/cron.php');
        }
        echo "✅ Cron job removed\n";
        
        echo "\n🎉 HostBill Advanced Email Manager uninstalled successfully!\n";
        
        return true;
        
    } catch (Exception $e) {
        echo "❌ Uninstallation failed: " . $e->getMessage() . "\n";
        return false;
    }
}

/**
 * Test installation
 */
function test_email_installation() {
    echo "🧪 Testing HostBill Advanced Email Manager installation...\n";
    
    $tests = [
        'Database tables' => test_database_tables(),
        'Module registration' => test_module_registration(),
        'Email templates' => test_email_templates(),
        'Configuration' => test_configuration(),
        'File permissions' => test_file_permissions(),
        'Cron job' => test_cron_job()
    ];
    
    $passed = 0;
    $total = count($tests);
    
    foreach ($tests as $test => $result) {
        if ($result) {
            echo "✅ " . $test . ": PASSED\n";
            $passed++;
        } else {
            echo "❌ " . $test . ": FAILED\n";
        }
    }
    
    echo "\n📊 Test Results: " . $passed . "/" . $total . " tests passed\n";
    
    if ($passed === $total) {
        echo "🎉 All tests passed! Module is ready for use.\n";
        return true;
    } else {
        echo "⚠️ Some tests failed. Please check the installation.\n";
        return false;
    }
}

/**
 * Test database tables
 */
function test_database_tables() {
    $tables = ['mod_email_queue', 'mod_email_verification', 'mod_email_templates', 'mod_email_log', 'mod_email_config'];
    
    foreach ($tables as $table) {
        $result = full_query("SHOW TABLES LIKE '" . $table . "'");
        if (mysql_num_rows($result) == 0) {
            return false;
        }
    }
    
    return true;
}

/**
 * Test module registration
 */
function test_module_registration() {
    $result = full_query("SELECT id FROM tbladdonmodules WHERE module = 'email'");
    return mysql_num_rows($result) > 0;
}

/**
 * Test email templates
 */
function test_email_templates() {
    $result = full_query("SELECT COUNT(*) as count FROM mod_email_templates");
    $row = mysql_fetch_assoc($result);
    return $row['count'] > 0;
}

/**
 * Test configuration
 */
function test_configuration() {
    $result = full_query("SELECT COUNT(*) as count FROM mod_email_config");
    $row = mysql_fetch_assoc($result);
    return $row['count'] > 0;
}

/**
 * Test file permissions
 */
function test_file_permissions() {
    $module_path = dirname(__FILE__);
    return is_readable($module_path . '/email.php') && is_readable($module_path . '/verify.php');
}

/**
 * Test cron job
 */
function test_cron_job() {
    $result = full_query("SELECT id FROM tblcron WHERE name = 'Email Queue Processing'");
    return mysql_num_rows($result) > 0 && file_exists(dirname(__FILE__) . '/cron.php');
}

// Command line interface
if (php_sapi_name() === 'cli') {
    $action = isset($argv[1]) ? $argv[1] : 'help';
    
    switch ($action) {
        case 'install':
            install_email_module();
            break;
        case 'uninstall':
            uninstall_email_module();
            break;
        case 'test':
            test_email_installation();
            break;
        case 'help':
        default:
            echo "HostBill Advanced Email Manager Installer\n";
            echo "Usage: php install.php [action]\n";
            echo "Actions:\n";
            echo "  install   - Install the module\n";
            echo "  uninstall - Uninstall the module\n";
            echo "  test      - Test the installation\n";
            echo "  help      - Show this help message\n";
            break;
    }
}
?>
