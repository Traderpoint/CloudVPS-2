<?php
/**
 * Email Module Admin Interface
 * 
 * Admin dashboard for HostBill Email Module
 * Provides configuration, monitoring, template management, and testing tools
 * 
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Main admin dashboard
 */
function email_admin_dashboard($params) {
    $output = '';
    
    // Handle actions
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'test_connection':
                $output .= email_admin_test_connection($params);
                break;
            case 'process_queue':
                $output .= email_admin_process_queue($params);
                break;
            case 'send_test_email':
                $output .= email_admin_send_test_email($params);
                break;
            case 'view_templates':
                $output .= email_admin_view_templates($params);
                break;
            case 'view_queue':
                $output .= email_admin_view_queue($params);
                break;
            case 'view_logs':
                $output .= email_admin_view_logs($params);
                break;
        }
    }
    
    // Dashboard header
    $output .= '<div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">
                <i class="fa fa-envelope"></i> Advanced Email Manager Dashboard
            </h3>
        </div>
        <div class="panel-body">';
    
    // Configuration status
    $output .= email_admin_config_status($params);
    
    // Quick actions
    $output .= email_admin_quick_actions($params);
    
    // Statistics
    $output .= email_admin_statistics($params);
    
    // Recent activity
    $output .= email_admin_recent_activity($params);
    
    $output .= '</div></div>';
    
    return $output;
}

/**
 * Configuration status panel
 */
function email_admin_config_status($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h4 class="panel-title">Configuration Status</h4>
                </div>
                <div class="panel-body">
                    <div class="row">';
    
    // Check configuration
    $configStatus = [
        'SMTP Host' => !empty($params['smtp_host']),
        'SMTP Username' => !empty($params['smtp_username']),
        'SMTP Password' => !empty($params['smtp_password']),
        'From Email' => !empty($params['from_email']),
        'From Name' => !empty($params['from_name']),
        'Email Verification' => isset($params['email_verification']),
        'Email Queue' => isset($params['email_queue'])
    ];
    
    foreach ($configStatus as $item => $status) {
        $icon = $status ? 'fa-check text-success' : 'fa-times text-danger';
        $output .= '<div class="col-md-4">
            <i class="fa ' . $icon . '"></i> ' . $item . '
        </div>';
    }
    
    $output .= '</div>';
    
    // SMTP Configuration Summary
    if (!empty($params['smtp_host'])) {
        $output .= '<hr>
            <div class="alert alert-info">
                <strong>SMTP Configuration:</strong><br>
                <strong>Server:</strong> ' . htmlspecialchars($params['smtp_host']) . ':' . htmlspecialchars($params['smtp_port']) . '<br>
                <strong>Security:</strong> ' . strtoupper($params['smtp_security']) . '<br>
                <strong>Username:</strong> ' . htmlspecialchars($params['smtp_username']) . '<br>
                <strong>From:</strong> ' . htmlspecialchars($params['from_name']) . ' &lt;' . htmlspecialchars($params['from_email']) . '&gt;
            </div>';
    }
    
    $output .= '</div></div></div></div>';
    
    return $output;
}

/**
 * Quick actions panel
 */
function email_admin_quick_actions($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Quick Actions</h4>
                </div>
                <div class="panel-body">
                    <div class="btn-group" role="group">';
    
    // Test connection button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="test_connection">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-plug"></i> Test SMTP Connection
        </button>
    </form>';
    
    // Process queue button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="process_queue">
        <button type="submit" class="btn btn-success">
            <i class="fa fa-play"></i> Process Email Queue
        </button>
    </form>';
    
    // Send test email button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="send_test_email">
        <button type="submit" class="btn btn-info">
            <i class="fa fa-paper-plane"></i> Send Test Email
        </button>
    </form>';
    
    // View templates button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="view_templates">
        <button type="submit" class="btn btn-default">
            <i class="fa fa-file-text"></i> Manage Templates
        </button>
    </form>';
    
    // View queue button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="view_queue">
        <button type="submit" class="btn btn-warning">
            <i class="fa fa-list"></i> View Queue
        </button>
    </form>';
    
    // View logs button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="view_logs">
        <button type="submit" class="btn btn-default">
            <i class="fa fa-history"></i> View Logs
        </button>
    </form>';
    
    $output .= '</div></div></div></div></div>';
    
    return $output;
}

/**
 * Statistics panel
 */
function email_admin_statistics($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h4 class="panel-title">Email Statistics (Last 30 Days)</h4>
                </div>
                <div class="panel-body">
                    <div class="row">';
    
    // Get statistics
    $stats = email_get_statistics();
    
    $output .= '<div class="col-md-3 text-center">
        <h3 class="text-primary">' . $stats['total_sent'] . '</h3>
        <p>Total Emails Sent</p>
    </div>
    <div class="col-md-3 text-center">
        <h3 class="text-success">' . $stats['successful'] . '</h3>
        <p>Successfully Delivered</p>
    </div>
    <div class="col-md-3 text-center">
        <h3 class="text-danger">' . $stats['failed'] . '</h3>
        <p>Failed Deliveries</p>
    </div>
    <div class="col-md-3 text-center">
        <h3 class="text-warning">' . $stats['queue_size'] . '</h3>
        <p>Pending in Queue</p>
    </div>';
    
    $output .= '</div>';
    
    // Success rate
    if ($stats['total_sent'] > 0) {
        $successRate = round(($stats['successful'] / $stats['total_sent']) * 100, 1);
        $output .= '<hr>
            <div class="progress">
                <div class="progress-bar progress-bar-success" role="progressbar" style="width: ' . $successRate . '%">
                    Success Rate: ' . $successRate . '%
                </div>
            </div>';
    }
    
    $output .= '</div></div></div></div>';
    
    return $output;
}

/**
 * Recent activity panel
 */
function email_admin_recent_activity($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Recent Email Activity</h4>
                </div>
                <div class="panel-body">';
    
    // Get recent emails
    $recentEmails = email_get_recent_emails();
    
    if (!empty($recentEmails)) {
        $output .= '<div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Recipient</th>
                        <th>Subject</th>
                        <th>Template</th>
                        <th>Status</th>
                        <th>Sent At</th>
                    </tr>
                </thead>
                <tbody>';
        
        foreach ($recentEmails as $email) {
            $statusClass = '';
            switch ($email['status']) {
                case 'sent':
                    $statusClass = 'label-success';
                    break;
                case 'failed':
                    $statusClass = 'label-danger';
                    break;
                case 'bounced':
                    $statusClass = 'label-warning';
                    break;
                default:
                    $statusClass = 'label-default';
            }
            
            $output .= '<tr>
                <td>' . htmlspecialchars($email['to_email']) . '</td>
                <td>' . htmlspecialchars(substr($email['subject'], 0, 50)) . '...</td>
                <td>' . ($email['template_name'] ? '<span class="label label-info">' . htmlspecialchars($email['template_name']) . '</span>' : '-') . '</td>
                <td><span class="label ' . $statusClass . '">' . ucfirst($email['status']) . '</span></td>
                <td>' . date('Y-m-d H:i', strtotime($email['sent_at'])) . '</td>
            </tr>';
        }
        
        $output .= '</tbody></table></div>';
    } else {
        $output .= '<div class="alert alert-info">No recent email activity found.</div>';
    }
    
    $output .= '</div></div></div></div>';
    
    return $output;
}

/**
 * Test SMTP connection
 */
function email_admin_test_connection($params) {
    $output = '<div class="alert alert-info">
        <h4><i class="fa fa-spinner fa-spin"></i> Testing SMTP Connection...</h4>
    </div>';
    
    try {
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($params);
        
        $result = $emailClient->testConnection();
        
        if ($result['success']) {
            $output = '<div class="alert alert-success">
                <h4><i class="fa fa-check"></i> SMTP Connection Successful!</h4>
                <p>' . $result['message'] . '</p>
                <p><strong>Server:</strong> ' . $result['server_info'] . '</p>
            </div>';
        } else {
            $output = '<div class="alert alert-danger">
                <h4><i class="fa fa-times"></i> SMTP Connection Failed!</h4>
                <p>' . $result['message'] . '</p>
            </div>';
        }
        
    } catch (Exception $e) {
        $output = '<div class="alert alert-danger">
            <h4><i class="fa fa-times"></i> Connection Error!</h4>
            <p>' . $e->getMessage() . '</p>
        </div>';
    }
    
    return $output;
}

/**
 * Process email queue
 */
function email_admin_process_queue($params) {
    $output = '';
    
    try {
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($params);
        
        $result = $emailClient->processQueue($params);
        
        if ($result['success']) {
            $output = '<div class="alert alert-success">
                <h4><i class="fa fa-check"></i> Queue Processing Completed!</h4>
                <p>' . $result['message'] . '</p>
                <p><strong>Processed:</strong> ' . $result['processed'] . ' emails</p>';
            
            if (!empty($result['errors'])) {
                $output .= '<p><strong>Errors:</strong></p><ul>';
                foreach ($result['errors'] as $error) {
                    $output .= '<li>' . htmlspecialchars($error) . '</li>';
                }
                $output .= '</ul>';
            }
            
            $output .= '</div>';
        } else {
            $output = '<div class="alert alert-danger">
                <h4><i class="fa fa-times"></i> Queue Processing Failed!</h4>
                <p>' . $result['message'] . '</p>
            </div>';
        }
        
    } catch (Exception $e) {
        $output = '<div class="alert alert-danger">
            <h4><i class="fa fa-times"></i> Processing Error!</h4>
            <p>' . $e->getMessage() . '</p>
        </div>';
    }
    
    return $output;
}

/**
 * Send test email
 */
function email_admin_send_test_email($params) {
    $output = '';
    
    try {
        $testEmail = $params['from_email'];
        
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($params);
        
        $emailData = [
            'to_email' => $testEmail,
            'subject' => 'HostBill Email Module Test - ' . date('Y-m-d H:i:s'),
            'body_html' => '
                <h2>Email Module Test</h2>
                <p>This is a test email from HostBill Advanced Email Manager.</p>
                <p><strong>Test Details:</strong></p>
                <ul>
                    <li>Sent at: ' . date('Y-m-d H:i:s') . '</li>
                    <li>SMTP Host: ' . $params['smtp_host'] . '</li>
                    <li>From: ' . $params['from_email'] . '</li>
                </ul>
                <p>If you received this email, your configuration is working correctly!</p>
            ',
            'body_text' => 'Email Module Test

This is a test email from HostBill Advanced Email Manager.

Test Details:
- Sent at: ' . date('Y-m-d H:i:s') . '
- SMTP Host: ' . $params['smtp_host'] . '
- From: ' . $params['from_email'] . '

If you received this email, your configuration is working correctly!'
        ];
        
        $result = $emailClient->sendEmail($emailData);
        
        if ($result['success']) {
            $output = '<div class="alert alert-success">
                <h4><i class="fa fa-check"></i> Test Email Sent Successfully!</h4>
                <p>Test email has been sent to: <strong>' . $testEmail . '</strong></p>
                <p>Please check your inbox to confirm delivery.</p>
            </div>';
        } else {
            $output = '<div class="alert alert-danger">
                <h4><i class="fa fa-times"></i> Test Email Failed!</h4>
                <p>' . $result['message'] . '</p>
            </div>';
        }
        
    } catch (Exception $e) {
        $output = '<div class="alert alert-danger">
            <h4><i class="fa fa-times"></i> Test Email Error!</h4>
            <p>' . $e->getMessage() . '</p>
        </div>';
    }
    
    return $output;
}

/**
 * View email templates
 */
function email_admin_view_templates($params) {
    $output = '<div class="panel panel-default">
        <div class="panel-heading">
            <h4 class="panel-title">Email Templates</h4>
        </div>
        <div class="panel-body">';
    
    // Get all templates
    require_once dirname(__FILE__) . '/email-templates.php';
    $templates = get_all_email_templates();
    
    if (!empty($templates)) {
        $output .= '<div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Subject</th>
                        <th>Variables</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>';
        
        foreach ($templates as $template) {
            $statusClass = $template['active'] ? 'label-success' : 'label-default';
            $statusText = $template['active'] ? 'Active' : 'Inactive';
            
            $output .= '<tr>
                <td><strong>' . htmlspecialchars($template['name']) . '</strong></td>
                <td>' . htmlspecialchars(substr($template['subject'], 0, 50)) . '...</td>
                <td><small>' . htmlspecialchars($template['variables']) . '</small></td>
                <td><span class="label ' . $statusClass . '">' . $statusText . '</span></td>
                <td>
                    <button class="btn btn-xs btn-info" onclick="viewTemplate(\'' . $template['name'] . '\')">
                        <i class="fa fa-eye"></i> View
                    </button>
                </td>
            </tr>';
        }
        
        $output .= '</tbody></table></div>';
    } else {
        $output .= '<div class="alert alert-info">No email templates found.</div>';
    }
    
    $output .= '</div></div>';
    
    return $output;
}

/**
 * Get email statistics
 */
function email_get_statistics() {
    $stats = [
        'total_sent' => 0,
        'successful' => 0,
        'failed' => 0,
        'queue_size' => 0
    ];
    
    try {
        // Total emails sent in last 30 days
        $result = full_query("SELECT COUNT(*) as count FROM mod_email_log WHERE sent_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $row = mysql_fetch_assoc($result);
        $stats['total_sent'] = $row['count'];
        
        // Successful emails
        $result = full_query("SELECT COUNT(*) as count FROM mod_email_log WHERE status = 'sent' AND sent_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $row = mysql_fetch_assoc($result);
        $stats['successful'] = $row['count'];
        
        // Failed emails
        $result = full_query("SELECT COUNT(*) as count FROM mod_email_log WHERE status = 'failed' AND sent_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $row = mysql_fetch_assoc($result);
        $stats['failed'] = $row['count'];
        
        // Queue size
        $result = full_query("SELECT COUNT(*) as count FROM mod_email_queue WHERE status = 'pending'");
        $row = mysql_fetch_assoc($result);
        $stats['queue_size'] = $row['count'];
        
    } catch (Exception $e) {
        // Return default stats on error
    }
    
    return $stats;
}

/**
 * Get recent emails
 */
function email_get_recent_emails($limit = 10) {
    $emails = [];
    
    try {
        $result = full_query("SELECT * FROM mod_email_log ORDER BY sent_at DESC LIMIT " . intval($limit));
        
        while ($row = mysql_fetch_assoc($result)) {
            $emails[] = $row;
        }
        
    } catch (Exception $e) {
        // Return empty array on error
    }
    
    return $emails;
}
?>
