# HostBill Advanced Email Manager

## 🎯 **Kompletní email management pro HostBill**

Pokročilý email modul pro HostBill s automatickým odesíláním, ověřováním emailových adres a kompletním správou komunikace se zákazníky.

### ✅ **Klíčové funkce:**
- ✅ **Email ověření** - automatické potvrzení emailové adresy nových klientů
- ✅ **Automatické emaily** - welcome, faktury, platby, notifikace
- ✅ **SMTP podpora** - Gmail, Outlook, vlastní SMTP servery
- ✅ **Email šablony** - přizpůsobitelné HTML/text šablony
- ✅ **Email fronta** - queue systém pro lepší výkon
- ✅ **Admin dashboard** - kompletní správa a monitoring
- ✅ **Hook systém** - automatické spouštění při events
- ✅ **Bezpečnost** - šifrovaná komunikace a validace
- ✅ **Logování** - detailní záznamy všech emailů

---

## **🚀 Rychlá instalace (5 minut)**

### **1. Zkopírování souborů:**
```bash
# Zkopírujte modul do HostBill
cp -r hostbill-email-module/ /path/to/hostbill/modules/addons/email/
```

### **2. Spuštění instalace:**
```bash
cd /path/to/hostbill/modules/addons/email/
php install.php install
```

### **3. Aktivace v HostBill:**
1. **Admin** → **Setup** → **Addon Modules**
2. **Najděte**: "Advanced Email Manager"
3. **Klikněte**: **Activate**

### **4. Konfigurace SMTP:**
1. **Vyplňte SMTP nastavení** (Gmail, Outlook, vlastní server)
2. **Nastavte From Email** a From Name
3. **Zapněte Email Verification** pro nové klienty
4. **Otestujte připojení**

---

## **📁 Struktura modulu**

```
hostbill-email-module/
├── email.php               # Hlavní modul soubor
├── email-client.php        # SMTP client a email odesílání
├── email-templates.php     # Email šablony a správa
├── verify.php               # Email verification handler
├── hooks.php                # Automatické hooks pro events
├── admin.php                # Admin interface a dashboard
├── install.php              # Instalační skript
├── test-module.php          # Test suite
├── cron.php                 # Cron job pro queue processing
└── README.md                # Tato dokumentace
```

---

## **⚙️ Konfigurace**

### **A) SMTP nastavení:**
- **SMTP Host**: smtp.gmail.com, smtp-mail.outlook.com, vlastní server
- **SMTP Port**: 587 (TLS), 465 (SSL), 25 (plain)
- **SMTP Security**: TLS (doporučeno), SSL, None
- **SMTP Username**: obvykle emailová adresa
- **SMTP Password**: heslo nebo app-specific password

### **B) Email nastavení:**
- **From Email**: odesílací emailová adresa
- **From Name**: jméno odesílatele
- **Reply-To**: adresa pro odpovědi (volitelné)

### **C) Funkce modulu:**
- **Email Verification**: ověření emailu nových klientů
- **Verification Expiry**: doba platnosti ověřovacího linku (hodiny)
- **Auto Welcome Email**: uvítací email po ověření
- **Auto Invoice Email**: email při vytvoření faktury
- **Auto Payment Email**: email při přijetí platby
- **Email Queue**: fronta pro lepší výkon
- **Debug Mode**: detailní logování

---

## **📧 Email ověření workflow**

### **1. Nový klient se registruje:**
- HostBill vytvoří nového klienta
- Email modul automaticky odešle ověřovací email
- Klient je označen jako "neověřený"

### **2. Klient klikne na ověřovací link:**
- Link obsahuje unikátní token
- Modul ověří token a platnost
- Email je označen jako ověřený
- Volitelně se odešle uvítací email

### **3. Návrat na původní URL:**
- Po ověření je klient přesměrován
- Return URL lze předat při registraci
- Fallback na hlavní stránku HostBill

### **Příklad volání s return URL:**
```php
// Při registraci klienta
$returnUrl = 'https://example.com/welcome';
$vars['return_url'] = $returnUrl;

// Email modul automaticky použije return URL
```

---

## **🎨 Email šablony**

### **Přednastavené šablony:**

#### **1. Email Verification (email_verification)**
- **Účel**: Ověření emailové adresy nových klientů
- **Proměnné**: `{client_name}`, `{verification_url}`, `{company_name}`
- **Funkce**: Obsahuje ověřovací link s tokenem

#### **2. Welcome Email (welcome_email)**
- **Účel**: Uvítací email po ověření
- **Proměnné**: `{client_name}`, `{client_email}`, `{company_url}`
- **Funkce**: Informace o službách a přihlašovacích údajích

#### **3. Invoice Created (invoice_created)**
- **Účel**: Notifikace o nové faktuře
- **Proměnné**: `{invoice_number}`, `{total_amount}`, `{due_date}`, `{invoice_url}`
- **Funkce**: Detaily faktury a platební link

#### **4. Payment Received (payment_received)**
- **Účel**: Potvrzení přijaté platby
- **Proměnné**: `{payment_amount}`, `{transaction_id}`, `{payment_method}`
- **Funkce**: Detaily platby a potvrzení

### **Vlastní šablony:**
```php
// Vytvoření vlastní šablony
create_email_template(
    'custom_template',
    'Vlastní email - {client_name}',
    '<h1>Ahoj {client_name}!</h1><p>Vlastní obsah...</p>',
    'Ahoj {client_name}! Vlastní obsah...',
    'client_name, client_email, custom_variable'
);
```

---

## **🔄 Automatické hooks**

### **Podporované HostBill events:**

#### **ClientAdd** - Registrace nového klienta
- **Akce**: Odeslání ověřovacího emailu
- **Podmínka**: Email verification zapnuto
- **Return URL**: Podporováno přes `$vars['return_url']`

#### **InvoiceCreated** - Vytvoření faktury
- **Akce**: Odeslání invoice emailu
- **Podmínka**: Auto invoice email zapnuto + ověřený email

#### **AfterModuleCreate** - Přijetí platby
- **Akce**: Odeslání payment confirmation
- **Podmínka**: Auto payment email zapnuto + ověřený email

#### **InvoiceChangeStatus** - Změna stavu faktury
- **Akce**: Notifikace o změně (Paid, Cancelled, Overdue)
- **Podmínka**: Podle typu změny

#### **ClientEdit** - Změna emailu klienta
- **Akce**: Nové ověření emailu
- **Podmínka**: Email verification zapnuto

---

## **📊 Admin Dashboard**

### **Přístup:**
**HostBill Admin** → **Setup** → **Addon Modules** → **Advanced Email Manager** → **Configure**

### **Funkce dashboardu:**
- ✅ **Configuration Status** - kontrola SMTP nastavení
- ✅ **Quick Actions** - test připojení, zpracování fronty
- ✅ **Email Statistics** - statistiky za 30 dní
- ✅ **Recent Activity** - poslední odeslané emaily
- ✅ **Template Management** - správa šablon
- ✅ **Queue Monitoring** - sledování email fronty
- ✅ **Email Logs** - detailní logy všech emailů

### **Test funkce:**
- **Test SMTP Connection** - ověření připojení k serveru
- **Send Test Email** - odeslání testovacího emailu
- **Process Queue** - manuální zpracování fronty

---

## **⚡ Email fronta (Queue)**

### **Výhody fronty:**
- **Lepší výkon** - asynchronní odesílání
- **Retry mechanismus** - opakování při chybách
- **Batch processing** - zpracování po dávkách
- **Prioritizace** - důležité emaily první

### **Konfigurace:**
- **Email Queue**: Zapnout/vypnout frontu
- **Queue Batch Size**: Počet emailů na dávku (výchozí: 10)
- **Max Attempts**: Maximální počet pokusů (výchozí: 3)

### **Cron job setup:**
```bash
# Přidejte do crontab pro zpracování fronty každých 5 minut
*/5 * * * * php /path/to/hostbill/modules/addons/email/cron.php
```

---

## **🧪 Testování**

### **Automatické testy:**
```bash
cd /path/to/hostbill/modules/addons/email/
php test-module.php test
```

### **Test SMTP připojení:**
```bash
php test-module.php smtp smtp.gmail.com username@gmail.com app_password
```

### **Test instalace:**
```bash
php install.php test
```

---

## **🔧 SMTP konfigurace pro populární služby**

### **Gmail:**
```
SMTP Host: smtp.gmail.com
SMTP Port: 587
Security: TLS
Username: your-email@gmail.com
Password: App-specific password (ne běžné heslo!)
```

### **Outlook/Hotmail:**
```
SMTP Host: smtp-mail.outlook.com
SMTP Port: 587
Security: TLS
Username: your-email@outlook.com
Password: Vaše heslo
```

### **Vlastní server:**
```
SMTP Host: mail.your-domain.com
SMTP Port: 587 (nebo 465, 25)
Security: TLS (nebo SSL, None)
Username: your-email@your-domain.com
Password: Vaše heslo
```

---

## **🛡️ Bezpečnost**

### **Implementované funkce:**
- ✅ **Token-based verification** - bezpečné ověřovací tokeny
- ✅ **Expiry kontrola** - časově omezené tokeny
- ✅ **HTTPS komunikace** - šifrovaný přenos
- ✅ **SQL injection ochrana** - bezpečné databázové dotazy
- ✅ **XSS ochrana** - escapování výstupů
- ✅ **Access controls** - HostBill integrace
- ✅ **Rate limiting** - ochrana proti spamu

---

## **📈 Monitoring a logování**

### **Email Log:**
Všechny emaily jsou logovány v tabulce `mod_email_log`:
- Příjemce a předmět
- Použitá šablona
- Status (sent, failed, bounced)
- Časové razítko
- Chybové zprávy

### **Activity Log:**
Důležité události v HostBill Activity Log:
- Ověření emailů
- Chyby odesílání
- SMTP problémy
- Hook spouštění

### **Queue Monitoring:**
Sledování email fronty:
- Pending emaily
- Failed pokusy
- Processing statistiky
- Error messages

---

## **🔍 Troubleshooting**

### **Časté problémy:**

#### **❌ "SMTP connection failed"**
- **Problém**: Nesprávné SMTP nastavení
- **Řešení**: Zkontrolujte host, port, username, password

#### **❌ "Authentication failed"**
- **Problém**: Nesprávné přihlašovací údaje
- **Řešení**: Pro Gmail použijte App Password, ne běžné heslo

#### **❌ "Verification email not sent"**
- **Problém**: Email verification vypnuto nebo SMTP chyba
- **Řešení**: Zapněte verification a otestujte SMTP

#### **❌ "Token expired"**
- **Problém**: Ověřovací link vypršel
- **Řešení**: Požádejte o nový ověřovací email

#### **❌ "Module not found"**
- **Problém**: Soubory nejsou správně zkopírovány
- **Řešení**: Zkontrolujte cestu `/modules/addons/email/`

### **Debug kroky:**
1. **Zapněte Debug Mode** v konfiguraci
2. **Zkontrolujte Activity Log** v HostBill
3. **Spusťte test suite**: `php test-module.php test`
4. **Test SMTP**: Admin dashboard → Test Connection
5. **Zkontrolujte email logy**: Admin → View Logs

---

## **📞 Podpora**

### **Při problémech:**
1. **Zkontrolujte logy**: HostBill Activity Log a Email Logs
2. **Spusťte testy**: `php test-module.php test`
3. **Ověřte konfiguraci**: Admin dashboard
4. **Test SMTP**: Použijte test connection
5. **Kontaktujte podporu**: S detailními logy a error messages

## **📖 Detailní instalační návod**

### **Krok 1: Příprava (2 minuty)**

#### **A) Stažení modulu:**
```bash
# Zkopírujte složku hostbill-email-module do HostBill
cp -r hostbill-email-module/ /var/www/hostbill/modules/addons/email/
```

#### **B) Nastavení oprávnění (Linux):**
```bash
chown -R www-data:www-data /var/www/hostbill/modules/addons/email/
chmod -R 644 /var/www/hostbill/modules/addons/email/
chmod 755 /var/www/hostbill/modules/addons/email/
```

### **Krok 2: Instalace (1 minuta)**

```bash
cd /var/www/hostbill/modules/addons/email/
php install.php install
```

**Očekávaný výstup:**
```
🚀 Installing HostBill Advanced Email Manager...
1️⃣ Creating database tables...
✅ Database tables created successfully
2️⃣ Registering module in HostBill...
✅ Module registered successfully
3️⃣ Installing default email templates...
✅ Default templates installed
4️⃣ Setting default configuration...
✅ Default configuration set
5️⃣ Setting file permissions...
✅ File permissions set
6️⃣ Setting up cron job...
✅ Cron job configured

🎉 HostBill Advanced Email Manager installed successfully!
```

### **Krok 3: Aktivace v HostBill (1 minuta)**

1. **Přihlaste se** do HostBill Admin
2. **Jděte na**: **Setup** → **Addon Modules**
3. **Najděte**: "Advanced Email Manager"
4. **Klikněte**: **Activate**
5. **Ověřte**: Status "Active" se zeleným indikátorem

### **Krok 4: Konfigurace SMTP (5 minut)**

#### **A) Základní SMTP nastavení:**
1. **Advanced Email Manager** → **Configure**
2. **Vyplňte**:
   - **SMTP Host**: smtp.gmail.com (pro Gmail)
   - **SMTP Port**: 587
   - **SMTP Security**: TLS
   - **SMTP Username**: your-email@gmail.com
   - **SMTP Password**: App-specific password
   - **From Email**: your-email@gmail.com
   - **From Name**: Your Company Name

#### **B) Gmail App Password setup:**
1. **Jděte na**: https://myaccount.google.com/security
2. **Zapněte**: 2-Step Verification
3. **Vygenerujte**: App Password pro "Mail"
4. **Použijte**: Vygenerované heslo (ne běžné heslo)

### **Krok 5: Test a ověření (2 minuty)**

#### **A) Test SMTP připojení:**
1. **V konfiguraci** klikněte: **Test SMTP Connection**
2. **Očekávaný výsledek**: ✅ "SMTP Connection Successful!"
3. **Pokud chyba**: Zkontrolujte SMTP nastavení

#### **B) Test email odesílání:**
1. **Klikněte**: **Send Test Email**
2. **Zkontrolujte**: Inbox na from_email adrese
3. **Ověřte**: Email byl doručen

### **Krok 6: Nastavení cron job (3 minuty)**

#### **A) Přidání do crontab:**
```bash
# Editujte crontab
crontab -e

# Přidejte řádek pro zpracování email fronty každých 5 minut
*/5 * * * * php /var/www/hostbill/modules/addons/email/cron.php >/dev/null 2>&1
```

#### **B) Test cron job:**
```bash
# Manuální spuštění
php /var/www/hostbill/modules/addons/email/cron.php
```

---

## **🎯 Produkční nasazení**

### **Doporučené nastavení pro produkci:**
- ✅ **Email Verification**: Yes (ověření nových klientů)
- ✅ **Auto Welcome Email**: Yes (uvítací email)
- ✅ **Auto Invoice Email**: Yes (faktury)
- ✅ **Auto Payment Email**: Yes (platby)
- ✅ **Email Queue**: Yes (lepší výkon)
- ✅ **Debug Mode**: No (vypnout v produkci)

### **Monitoring checklist:**
- ✅ **SMTP připojení** funguje
- ✅ **Test emaily** se doručují
- ✅ **Cron job** běží každých 5 minut
- ✅ **Email fronta** se zpracovává
- ✅ **Logy** neobsahují chyby

### **Bezpečnostní doporučení:**
- ✅ **HTTPS** pro verification linky
- ✅ **App passwords** místo běžných hesel
- ✅ **Firewall** pravidla pro SMTP porty
- ✅ **Backup** databáze včetně email tabulek

**HostBill Advanced Email Manager je připraven k produkčnímu nasazení! 🚀**
