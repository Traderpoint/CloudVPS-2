<?php
/**
 * Email Templates
 * 
 * Predefined email templates for HostBill Email Module
 * Includes templates for verification, welcome, invoices, and notifications
 * 
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Get default email templates
 */
function get_default_email_templates() {
    return [
        'email_verification' => [
            'name' => 'email_verification',
            'subject' => 'Potvrďte svou emailovou adresu - {company_name}',
            'body_html' => '
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Potvrzení emailové adresy</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #007bff; color: white; padding: 20px; text-align: center; }
        .content { padding: 30px; background: #f8f9fa; }
        .button { display: inline-block; padding: 12px 30px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{company_name}</h1>
            <h2>Potvrzení emailové adresy</h2>
        </div>
        <div class="content">
            <p>Vážený/á {client_name},</p>
            
            <p>Děkujeme za registraci v našem systému. Pro dokončení registrace je potřeba potvrdit vaši emailovou adresu.</p>
            
            <p>Klikněte na tlačítko níže pro potvrzení:</p>
            
            <p style="text-align: center;">
                <a href="{verification_url}" class="button">Potvrdit emailovou adresu</a>
            </p>
            
            <p>Nebo zkopírujte a vložte následující odkaz do vašeho prohlížeče:</p>
            <p style="word-break: break-all; background: #e9ecef; padding: 10px; border-radius: 3px;">
                {verification_url}
            </p>
            
            <p><strong>Důležité:</strong> Tento odkaz je platný pouze 24 hodin.</p>
            
            <p>Pokud jste se neregistrovali v našem systému, ignorujte tento email.</p>
            
            <p>S pozdravem,<br>
            Tým {company_name}</p>
        </div>
        <div class="footer">
            <p>&copy; {current_year} {company_name}. Všechna práva vyhrazena.</p>
            <p>Tento email byl odeslán automaticky, neodpovídejte na něj.</p>
        </div>
    </div>
</body>
</html>',
            'body_text' => 'Vážený/á {client_name},

Děkujeme za registraci v našem systému. Pro dokončení registrace je potřeba potvrdit vaši emailovou adresu.

Klikněte na následující odkaz pro potvrzení:
{verification_url}

Tento odkaz je platný pouze 24 hodin.

Pokud jste se neregistrovali v našem systému, ignorujte tento email.

S pozdravem,
Tým {company_name}

© {current_year} {company_name}. Všechna práva vyhrazena.',
            'variables' => 'client_name, client_email, verification_url, company_name, current_year',
            'active' => 1
        ],
        
        'welcome_email' => [
            'name' => 'welcome_email',
            'subject' => 'Vítejte v {company_name}!',
            'body_html' => '
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Vítejte</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #007bff; color: white; padding: 20px; text-align: center; }
        .content { padding: 30px; background: #f8f9fa; }
        .button { display: inline-block; padding: 12px 30px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
        .features { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Vítejte v {company_name}!</h1>
        </div>
        <div class="content">
            <p>Vážený/á {client_name},</p>
            
            <p>Srdečně vás vítáme mezi našimi zákazníky! Jsme rádi, že jste se rozhodli pro naše služby.</p>
            
            <div class="features">
                <h3>Co můžete očekávat:</h3>
                <ul>
                    <li>✅ Spolehlivé služby 24/7</li>
                    <li>✅ Profesionální technickou podporu</li>
                    <li>✅ Pravidelné aktualizace a vylepšení</li>
                    <li>✅ Transparentní fakturaci</li>
                </ul>
            </div>
            
            <p>Pro přístup do vašeho zákaznického účtu klikněte na tlačítko níže:</p>
            
            <p style="text-align: center;">
                <a href="{company_url}/clientarea.php" class="button">Přejít do zákaznického účtu</a>
            </p>
            
            <p>Vaše přihlašovací údaje:</p>
            <ul>
                <li><strong>Email:</strong> {client_email}</li>
                <li><strong>Heslo:</strong> Heslo, které jste si zvolili při registraci</li>
            </ul>
            
            <p>Pokud máte jakékoli otázky, neváhejte nás kontaktovat.</p>
            
            <p>Těšíme se na spolupráci!</p>
            
            <p>S pozdravem,<br>
            Tým {company_name}</p>
        </div>
        <div class="footer">
            <p>&copy; {current_year} {company_name}. Všechna práva vyhrazena.</p>
        </div>
    </div>
</body>
</html>',
            'body_text' => 'Vážený/á {client_name},

Srdečně vás vítáme mezi našimi zákazníky! Jsme rádi, že jste se rozhodli pro naše služby.

Co můžete očekávat:
- Spolehlivé služby 24/7
- Profesionální technickou podporu
- Pravidelné aktualizace a vylepšení
- Transparentní fakturaci

Pro přístup do vašeho zákaznického účtu navštivte:
{company_url}/clientarea.php

Vaše přihlašovací údaje:
Email: {client_email}
Heslo: Heslo, které jste si zvolili při registraci

Pokud máte jakékoli otázky, neváhejte nás kontaktovat.

Těšíme se na spolupráci!

S pozdravem,
Tým {company_name}

© {current_year} {company_name}. Všechna práva vyhrazena.',
            'variables' => 'client_name, client_email, company_name, company_url, current_year',
            'active' => 1
        ],
        
        'invoice_created' => [
            'name' => 'invoice_created',
            'subject' => 'Nová faktura #{invoice_number} - {company_name}',
            'body_html' => '
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Nová faktura</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #17a2b8; color: white; padding: 20px; text-align: center; }
        .content { padding: 30px; background: #f8f9fa; }
        .button { display: inline-block; padding: 12px 30px; background: #28a745; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .invoice-details { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; border-left: 4px solid #17a2b8; }
        .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{company_name}</h1>
            <h2>Nová faktura</h2>
        </div>
        <div class="content">
            <p>Vážený/á {client_name},</p>
            
            <p>Byla vám vystavena nová faktura. Níže najdete detaily:</p>
            
            <div class="invoice-details">
                <h3>Detaily faktury</h3>
                <ul>
                    <li><strong>Číslo faktury:</strong> #{invoice_number}</li>
                    <li><strong>Datum vystavení:</strong> {invoice_date}</li>
                    <li><strong>Datum splatnosti:</strong> {due_date}</li>
                    <li><strong>Celková částka:</strong> {total_amount} {currency}</li>
                    <li><strong>Status:</strong> {invoice_status}</li>
                </ul>
            </div>
            
            <p>Pro zobrazení a úhradu faktury klikněte na tlačítko níže:</p>
            
            <p style="text-align: center;">
                <a href="{invoice_url}" class="button">Zobrazit a zaplatit fakturu</a>
            </p>
            
            <p><strong>Důležité:</strong> Prosíme o úhradu faktury do data splatnosti.</p>
            
            <p>Děkujeme za vaši důvěru.</p>
            
            <p>S pozdravem,<br>
            Tým {company_name}</p>
        </div>
        <div class="footer">
            <p>&copy; {current_year} {company_name}. Všechna práva vyhrazena.</p>
        </div>
    </div>
</body>
</html>',
            'body_text' => 'Vážený/á {client_name},

Byla vám vystavena nová faktura. Níže najdete detaily:

Detaily faktury:
- Číslo faktury: #{invoice_number}
- Datum vystavení: {invoice_date}
- Datum splatnosti: {due_date}
- Celková částka: {total_amount} {currency}
- Status: {invoice_status}

Pro zobrazení a úhradu faktury navštivte:
{invoice_url}

Důležité: Prosíme o úhradu faktury do data splatnosti.

Děkujeme za vaši důvěru.

S pozdravem,
Tým {company_name}

© {current_year} {company_name}. Všechna práva vyhrazena.',
            'variables' => 'client_name, invoice_number, invoice_date, due_date, total_amount, currency, invoice_status, invoice_url, company_name, current_year',
            'active' => 1
        ],
        
        'payment_received' => [
            'name' => 'payment_received',
            'subject' => 'Platba přijata - Faktura #{invoice_number}',
            'body_html' => '
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Platba přijata</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #28a745; color: white; padding: 20px; text-align: center; }
        .content { padding: 30px; background: #f8f9fa; }
        .button { display: inline-block; padding: 12px 30px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
        .payment-details { background: white; padding: 20px; margin: 20px 0; border-radius: 5px; border-left: 4px solid #28a745; }
        .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>✅ Platba přijata</h1>
        </div>
        <div class="content">
            <p>Vážený/á {client_name},</p>
            
            <p>S radostí vám potvrzujeme, že jsme přijali vaši platbu.</p>
            
            <div class="payment-details">
                <h3>Detaily platby</h3>
                <ul>
                    <li><strong>Číslo faktury:</strong> #{invoice_number}</li>
                    <li><strong>Částka:</strong> {payment_amount} {currency}</li>
                    <li><strong>Datum platby:</strong> {payment_date}</li>
                    <li><strong>Způsob platby:</strong> {payment_method}</li>
                    <li><strong>Transakční ID:</strong> {transaction_id}</li>
                </ul>
            </div>
            
            <p>Faktura je nyní označena jako zaplacená. Děkujeme za rychlou úhradu!</p>
            
            <p>Pro zobrazení faktury a stažení potvrzení klikněte na tlačítko níže:</p>
            
            <p style="text-align: center;">
                <a href="{invoice_url}" class="button">Zobrazit fakturu</a>
            </p>
            
            <p>Pokud máte jakékoli otázky ohledně této platby, neváhejte nás kontaktovat.</p>
            
            <p>Děkujeme za vaši důvěru a pokračující spolupráci.</p>
            
            <p>S pozdravem,<br>
            Tým {company_name}</p>
        </div>
        <div class="footer">
            <p>&copy; {current_year} {company_name}. Všechna práva vyhrazena.</p>
        </div>
    </div>
</body>
</html>',
            'body_text' => 'Vážený/á {client_name},

S radostí vám potvrzujeme, že jsme přijali vaši platbu.

Detaily platby:
- Číslo faktury: #{invoice_number}
- Částka: {payment_amount} {currency}
- Datum platby: {payment_date}
- Způsob platby: {payment_method}
- Transakční ID: {transaction_id}

Faktura je nyní označena jako zaplacená. Děkujeme za rychlou úhradu!

Pro zobrazení faktury navštivte:
{invoice_url}

Pokud máte jakékoli otázky ohledně této platby, neváhejte nás kontaktovat.

Děkujeme za vaši důvěru a pokračující spolupráci.

S pozdravem,
Tým {company_name}

© {current_year} {company_name}. Všechna práva vyhrazena.',
            'variables' => 'client_name, invoice_number, payment_amount, currency, payment_date, payment_method, transaction_id, invoice_url, company_name, current_year',
            'active' => 1
        ]
    ];
}

/**
 * Install default templates
 */
function install_default_email_templates() {
    $templates = get_default_email_templates();
    
    foreach ($templates as $template) {
        // Check if template already exists
        $existing = get_query_val('mod_email_templates', 'id', ['name' => $template['name']]);
        
        if (!$existing) {
            // Insert new template
            $sql = "INSERT INTO mod_email_templates (name, subject, body_html, body_text, variables, active) 
                    VALUES (
                        '" . mysql_real_escape_string($template['name']) . "',
                        '" . mysql_real_escape_string($template['subject']) . "',
                        '" . mysql_real_escape_string($template['body_html']) . "',
                        '" . mysql_real_escape_string($template['body_text']) . "',
                        '" . mysql_real_escape_string($template['variables']) . "',
                        " . intval($template['active']) . "
                    )";
            
            full_query($sql);
        }
    }
}

/**
 * Get template by name
 */
function get_email_template($templateName) {
    $result = full_query("SELECT * FROM mod_email_templates WHERE name = '" . mysql_real_escape_string($templateName) . "' AND active = 1");
    
    if (mysql_num_rows($result) > 0) {
        return mysql_fetch_assoc($result);
    }
    
    return null;
}

/**
 * Update email template
 */
function update_email_template($templateName, $data) {
    $updates = [];
    
    if (isset($data['subject'])) {
        $updates[] = "subject = '" . mysql_real_escape_string($data['subject']) . "'";
    }
    
    if (isset($data['body_html'])) {
        $updates[] = "body_html = '" . mysql_real_escape_string($data['body_html']) . "'";
    }
    
    if (isset($data['body_text'])) {
        $updates[] = "body_text = '" . mysql_real_escape_string($data['body_text']) . "'";
    }
    
    if (isset($data['variables'])) {
        $updates[] = "variables = '" . mysql_real_escape_string($data['variables']) . "'";
    }
    
    if (isset($data['active'])) {
        $updates[] = "active = " . intval($data['active']);
    }
    
    if (!empty($updates)) {
        $sql = "UPDATE mod_email_templates SET " . implode(', ', $updates) . " WHERE name = '" . mysql_real_escape_string($templateName) . "'";
        return full_query($sql);
    }
    
    return false;
}

/**
 * Get all email templates
 */
function get_all_email_templates() {
    $templates = [];
    $result = full_query("SELECT * FROM mod_email_templates ORDER BY name");
    
    while ($row = mysql_fetch_assoc($result)) {
        $templates[] = $row;
    }
    
    return $templates;
}

/**
 * Create custom email template
 */
function create_email_template($name, $subject, $bodyHtml, $bodyText = '', $variables = '', $active = 1) {
    // Check if template already exists
    $existing = get_query_val('mod_email_templates', 'id', ['name' => $name]);
    
    if ($existing) {
        return ['success' => false, 'message' => 'Template with this name already exists'];
    }
    
    $sql = "INSERT INTO mod_email_templates (name, subject, body_html, body_text, variables, active) 
            VALUES (
                '" . mysql_real_escape_string($name) . "',
                '" . mysql_real_escape_string($subject) . "',
                '" . mysql_real_escape_string($bodyHtml) . "',
                '" . mysql_real_escape_string($bodyText) . "',
                '" . mysql_real_escape_string($variables) . "',
                " . intval($active) . "
            )";
    
    if (full_query($sql)) {
        return ['success' => true, 'template_id' => mysql_insert_id()];
    } else {
        return ['success' => false, 'message' => 'Failed to create template'];
    }
}

/**
 * Delete email template
 */
function delete_email_template($templateName) {
    $sql = "DELETE FROM mod_email_templates WHERE name = '" . mysql_real_escape_string($templateName) . "'";
    return full_query($sql);
}
?>
