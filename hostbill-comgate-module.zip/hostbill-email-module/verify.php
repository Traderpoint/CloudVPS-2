<?php
/**
 * Email Verification Handler
 * 
 * Handles email verification for HostBill Email Module
 * Processes verification tokens and redirects users to return URLs
 * 
 * @version 1.0.0
 */

// Include HostBill configuration
require_once '../../../configuration.php';
require_once '../../../includes/functions.php';

/**
 * Process email verification
 */
function processEmailVerification() {
    try {
        // Get token from URL
        $token = isset($_GET['token']) ? $_GET['token'] : null;
        
        if (!$token) {
            showVerificationResult('error', 'Chybějící ověřovací token', 'Token pro ověření emailové adresy nebyl nalezen.');
            return;
        }
        
        // Log verification attempt
        logActivity('Email verification attempt with token: ' . substr($token, 0, 8) . '...');
        
        // Find verification record
        $sql = "SELECT * FROM mod_email_verification WHERE token = '" . mysql_real_escape_string($token) . "'";
        $result = full_query($sql);
        
        if (mysql_num_rows($result) == 0) {
            logActivity('Email verification failed: Invalid token');
            showVerificationResult('error', 'Neplatný token', 'Ověřovací token není platný nebo již byl použit.');
            return;
        }
        
        $verification = mysql_fetch_assoc($result);
        
        // Check if already verified
        if ($verification['verified']) {
            logActivity('Email verification: Already verified for client ' . $verification['client_id']);
            showVerificationResult('info', 'Email již ověřen', 'Tato emailová adresa již byla dříve ověřena.', $verification['return_url']);
            return;
        }
        
        // Check if expired
        if (strtotime($verification['expires_at']) < time()) {
            logActivity('Email verification failed: Token expired for client ' . $verification['client_id']);
            showVerificationResult('error', 'Token vypršel', 'Ověřovací token již vypršel. Požádejte o nový ověřovací email.');
            return;
        }
        
        // Mark as verified
        $sql = "UPDATE mod_email_verification SET 
                verified = 1, 
                verified_at = NOW() 
                WHERE id = " . intval($verification['id']);
        
        if (!full_query($sql)) {
            logActivity('Email verification failed: Database update error for client ' . $verification['client_id']);
            showVerificationResult('error', 'Chyba databáze', 'Došlo k chybě při ověřování emailové adresy. Zkuste to prosím znovu.');
            return;
        }
        
        // Update client email verification status
        $sql = "UPDATE tblclients SET 
                emailverified = 1 
                WHERE id = " . intval($verification['client_id']);
        full_query($sql);
        
        // Get client details
        $client = localAPI('GetClientsDetails', ['clientid' => $verification['client_id']]);
        
        // Log successful verification
        logActivity('Email verification successful for client ' . $verification['client_id'] . ' (' . $verification['email'] . ')');
        
        // Send welcome email if configured
        sendWelcomeEmailIfEnabled($verification['client_id'], $verification['email']);
        
        // Show success message
        $clientName = '';
        if ($client['result'] === 'success') {
            $clientName = $client['firstname'] . ' ' . $client['lastname'];
        }
        
        showVerificationResult('success', 'Email úspěšně ověřen', 
            'Děkujeme ' . $clientName . '! Vaše emailová adresa byla úspěšně ověřena.', 
            $verification['return_url']);
        
    } catch (Exception $e) {
        logActivity('Email verification exception: ' . $e->getMessage());
        showVerificationResult('error', 'Systémová chyba', 'Došlo k neočekávané chybě. Kontaktujte prosím podporu.');
    }
}

/**
 * Send welcome email if enabled
 */
function sendWelcomeEmailIfEnabled($clientId, $email) {
    try {
        // Check if welcome email is enabled
        $welcomeEnabled = get_query_val('mod_email_config', 'value', ['setting' => 'auto_welcome_email']);
        
        if ($welcomeEnabled === 'yes') {
            // Load email client
            require_once 'email-client.php';
            
            // Get module configuration
            $config = getModuleConfiguration('email');
            
            if ($config) {
                $emailClient = new EmailClient($config);
                
                // Get client details
                $client = localAPI('GetClientsDetails', ['clientid' => $clientId]);
                
                if ($client['result'] === 'success') {
                    // Prepare template variables
                    $variables = [
                        'client_name' => $client['firstname'] . ' ' . $client['lastname'],
                        'client_email' => $email
                    ];
                    
                    // Send welcome email
                    $result = $emailClient->sendTemplateEmail('welcome_email', $email, $variables);
                    
                    if ($result['success']) {
                        logActivity('Welcome email sent to verified client: ' . $email);
                    } else {
                        logActivity('Failed to send welcome email: ' . $result['message']);
                    }
                }
            }
        }
        
    } catch (Exception $e) {
        logActivity('Welcome email sending failed: ' . $e->getMessage());
    }
}

/**
 * Get module configuration
 */
function getModuleConfiguration($moduleName) {
    $config = [];
    
    $result = full_query("SELECT setting, value FROM tblconfiguration WHERE setting LIKE 'addon_{$moduleName}_%'");
    
    while ($row = mysql_fetch_assoc($result)) {
        $key = str_replace('addon_' . $moduleName . '_', '', $row['setting']);
        $config[$key] = $row['value'];
    }
    
    return !empty($config) ? $config : null;
}

/**
 * Show verification result page
 */
function showVerificationResult($type, $title, $message, $returnUrl = null) {
    $statusClass = '';
    $icon = '';
    
    switch ($type) {
        case 'success':
            $statusClass = 'alert-success';
            $icon = '✅';
            break;
        case 'error':
            $statusClass = 'alert-danger';
            $icon = '❌';
            break;
        case 'info':
            $statusClass = 'alert-info';
            $icon = 'ℹ️';
            break;
        default:
            $statusClass = 'alert-warning';
            $icon = '⚠️';
    }
    
    // Get company name
    $companyName = get_query_val('tblconfiguration', 'value', ['setting' => 'CompanyName']) ?: 'HostBill';
    $companyUrl = App::getUrl();
    
    // Determine redirect URL
    $redirectUrl = $returnUrl ?: $companyUrl . '/clientarea.php';
    
    echo '<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ověření emailové adresy - ' . htmlspecialchars($companyName) . '</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        }
        .verification-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }
        .verification-header {
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        .verification-body {
            padding: 2rem;
        }
        .verification-footer {
            background: #f8f9fa;
            padding: 1rem 2rem;
            text-align: center;
            border-top: 1px solid #dee2e6;
        }
        .status-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        .btn-custom {
            background: linear-gradient(45deg, #007bff, #0056b3);
            border: none;
            padding: 12px 30px;
            border-radius: 25px;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
            transition: transform 0.2s;
        }
        .btn-custom:hover {
            transform: translateY(-2px);
            color: white;
            text-decoration: none;
        }
        .countdown {
            font-weight: bold;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="verification-container">
                    <div class="verification-header">
                        <h1>' . htmlspecialchars($companyName) . '</h1>
                        <h2>Ověření emailové adresy</h2>
                    </div>
                    <div class="verification-body text-center">
                        <div class="status-icon">' . $icon . '</div>
                        <div class="alert ' . $statusClass . '" role="alert">
                            <h4 class="alert-heading">' . htmlspecialchars($title) . '</h4>
                            <p class="mb-0">' . htmlspecialchars($message) . '</p>
                        </div>
                        
                        <div class="mt-4">
                            <a href="' . htmlspecialchars($redirectUrl) . '" class="btn-custom">
                                ' . ($type === 'success' ? 'Pokračovat do zákaznického účtu' : 'Zpět na hlavní stránku') . '
                            </a>
                        </div>
                        
                        <div class="mt-3">
                            <small class="text-muted">
                                Budete automaticky přesměrováni za <span class="countdown" id="countdown">10</span> sekund.
                            </small>
                        </div>
                    </div>
                    <div class="verification-footer">
                        <small class="text-muted">
                            &copy; ' . date('Y') . ' ' . htmlspecialchars($companyName) . '. Všechna práva vyhrazena.
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Auto redirect countdown
        let countdown = 10;
        const countdownElement = document.getElementById("countdown");
        
        const timer = setInterval(function() {
            countdown--;
            countdownElement.textContent = countdown;
            
            if (countdown <= 0) {
                clearInterval(timer);
                window.location.href = "' . htmlspecialchars($redirectUrl) . '";
            }
        }, 1000);
        
        // Allow manual redirect
        document.addEventListener("click", function(e) {
            if (e.target.classList.contains("btn-custom")) {
                clearInterval(timer);
            }
        });
    </script>
</body>
</html>';
}

/**
 * Resend verification email
 */
function resendVerificationEmail() {
    try {
        $email = isset($_POST['email']) ? $_POST['email'] : null;
        $returnUrl = isset($_POST['return_url']) ? $_POST['return_url'] : null;
        
        if (!$email) {
            echo json_encode(['success' => false, 'message' => 'Email address is required']);
            return;
        }
        
        // Find client by email
        $clientId = get_query_val('tblclients', 'id', ['email' => $email]);
        
        if (!$clientId) {
            echo json_encode(['success' => false, 'message' => 'Client not found']);
            return;
        }
        
        // Check if already verified
        $verified = get_query_val('tblclients', 'emailverified', ['id' => $clientId]);
        
        if ($verified) {
            echo json_encode(['success' => false, 'message' => 'Email already verified']);
            return;
        }
        
        // Delete old verification records
        full_query("DELETE FROM mod_email_verification WHERE client_id = " . intval($clientId) . " AND email = '" . mysql_real_escape_string($email) . "'");
        
        // Load email client
        require_once 'email-client.php';
        $config = getModuleConfiguration('email');
        
        if (!$config) {
            echo json_encode(['success' => false, 'message' => 'Email module not configured']);
            return;
        }
        
        $emailClient = new EmailClient($config);
        
        // Send new verification email
        $result = $emailClient->sendVerificationEmail($clientId, $email, $returnUrl);
        
        echo json_encode($result);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// Determine action
if (isset($_POST['action']) && $_POST['action'] === 'resend') {
    header('Content-Type: application/json');
    resendVerificationEmail();
} else {
    processEmailVerification();
}
?>
