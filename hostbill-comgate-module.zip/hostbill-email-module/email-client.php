<?php
/**
 * Email Client
 * 
 * Advanced email client for HostBill with SMTP support, queue processing, and delivery tracking
 * Supports multiple email providers and advanced features
 * 
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

class EmailClient {
    
    private $config;
    private $smtp;
    
    /**
     * Constructor
     */
    public function __construct($config) {
        $this->config = $config;
    }
    
    /**
     * Send email directly
     */
    public function sendEmail($emailData) {
        try {
            // Initialize SMTP connection
            if (!$this->initSMTP()) {
                return ['success' => false, 'message' => 'Failed to initialize SMTP connection'];
            }
            
            // Prepare email
            $this->smtp->isSMTP();
            $this->smtp->Host = $this->config['smtp_host'];
            $this->smtp->Port = $this->config['smtp_port'];
            $this->smtp->SMTPAuth = true;
            $this->smtp->Username = $this->config['smtp_username'];
            $this->smtp->Password = $this->config['smtp_password'];
            
            // Set encryption
            if ($this->config['smtp_security'] === 'tls') {
                $this->smtp->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } elseif ($this->config['smtp_security'] === 'ssl') {
                $this->smtp->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            }
            
            // Set sender
            $this->smtp->setFrom(
                $emailData['from_email'] ?? $this->config['from_email'],
                $emailData['from_name'] ?? $this->config['from_name']
            );
            
            // Set reply-to
            if (!empty($emailData['reply_to']) || !empty($this->config['reply_to'])) {
                $this->smtp->addReplyTo($emailData['reply_to'] ?? $this->config['reply_to']);
            }
            
            // Set recipient
            $this->smtp->addAddress($emailData['to_email'], $emailData['to_name'] ?? '');
            
            // Set subject and body
            $this->smtp->Subject = $emailData['subject'];
            $this->smtp->isHTML(true);
            $this->smtp->Body = $emailData['body_html'] ?? '';
            $this->smtp->AltBody = $emailData['body_text'] ?? strip_tags($emailData['body_html'] ?? '');
            
            // Add attachments
            if (!empty($emailData['attachments'])) {
                foreach ($emailData['attachments'] as $attachment) {
                    if (is_array($attachment)) {
                        $this->smtp->addAttachment($attachment['path'], $attachment['name'] ?? '');
                    } else {
                        $this->smtp->addAttachment($attachment);
                    }
                }
            }
            
            // Send email
            if ($this->smtp->send()) {
                // Log successful send
                $this->logEmail($emailData, 'sent');
                
                if ($this->config['debug_mode'] === 'yes') {
                    logActivity('Email sent successfully to: ' . $emailData['to_email']);
                }
                
                return ['success' => true, 'message' => 'Email sent successfully'];
            } else {
                // Log failed send
                $this->logEmail($emailData, 'failed', $this->smtp->ErrorInfo);
                
                return ['success' => false, 'message' => $this->smtp->ErrorInfo];
            }
            
        } catch (Exception $e) {
            // Log exception
            $this->logEmail($emailData, 'failed', $e->getMessage());
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Process email queue
     */
    public function processQueue($params) {
        try {
            $batchSize = intval($params['queue_batch_size'] ?? 10);
            $processed = 0;
            $errors = [];
            
            // Get pending emails from queue
            $sql = "SELECT * FROM mod_email_queue 
                    WHERE status = 'pending' 
                    AND (scheduled_at IS NULL OR scheduled_at <= NOW())
                    AND attempts < max_attempts
                    ORDER BY priority ASC, created_at ASC 
                    LIMIT " . $batchSize;
            
            $result = full_query($sql);
            
            while ($email = mysql_fetch_assoc($result)) {
                // Update status to sending
                full_query("UPDATE mod_email_queue SET status = 'sending', attempts = attempts + 1 WHERE id = " . $email['id']);
                
                // Prepare email data
                $emailData = [
                    'to_email' => $email['to_email'],
                    'to_name' => $email['to_name'],
                    'from_email' => $email['from_email'],
                    'from_name' => $email['from_name'],
                    'reply_to' => $email['reply_to'],
                    'subject' => $email['subject'],
                    'body_html' => $email['body_html'],
                    'body_text' => $email['body_text'],
                    'attachments' => json_decode($email['attachments'], true) ?: []
                ];
                
                // Send email
                $sendResult = $this->sendEmail($emailData);
                
                if ($sendResult['success']) {
                    // Mark as sent
                    full_query("UPDATE mod_email_queue SET status = 'sent', sent_at = NOW() WHERE id = " . $email['id']);
                    $processed++;
                } else {
                    // Mark as failed or retry
                    if ($email['attempts'] >= $email['max_attempts']) {
                        full_query("UPDATE mod_email_queue SET status = 'failed', error_message = '" . 
                                 mysql_real_escape_string($sendResult['message']) . "' WHERE id = " . $email['id']);
                    } else {
                        full_query("UPDATE mod_email_queue SET status = 'pending', error_message = '" . 
                                 mysql_real_escape_string($sendResult['message']) . "' WHERE id = " . $email['id']);
                    }
                    
                    $errors[] = 'Email ID ' . $email['id'] . ': ' . $sendResult['message'];
                }
                
                // Small delay to prevent overwhelming SMTP server
                usleep(100000); // 0.1 second
            }
            
            return [
                'success' => true,
                'processed' => $processed,
                'errors' => $errors,
                'message' => "Processed {$processed} emails" . (count($errors) > 0 ? ' with ' . count($errors) . ' errors' : '')
            ];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Test SMTP connection
     */
    public function testConnection() {
        try {
            if (!$this->initSMTP()) {
                return ['success' => false, 'message' => 'Failed to initialize SMTP connection'];
            }
            
            // Configure SMTP
            $this->smtp->isSMTP();
            $this->smtp->Host = $this->config['smtp_host'];
            $this->smtp->Port = $this->config['smtp_port'];
            $this->smtp->SMTPAuth = true;
            $this->smtp->Username = $this->config['smtp_username'];
            $this->smtp->Password = $this->config['smtp_password'];
            
            // Set encryption
            if ($this->config['smtp_security'] === 'tls') {
                $this->smtp->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } elseif ($this->config['smtp_security'] === 'ssl') {
                $this->smtp->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            }
            
            // Test connection
            if ($this->smtp->smtpConnect()) {
                $this->smtp->smtpClose();
                return [
                    'success' => true,
                    'message' => 'SMTP connection successful',
                    'server_info' => $this->config['smtp_host'] . ':' . $this->config['smtp_port']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'SMTP connection failed: ' . $this->smtp->ErrorInfo
                ];
            }
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Send template email
     */
    public function sendTemplateEmail($templateName, $recipientEmail, $variables = [], $returnUrl = null) {
        try {
            // Load template
            $template = $this->loadTemplate($templateName);
            if (!$template) {
                return ['success' => false, 'message' => 'Template not found: ' . $templateName];
            }
            
            // Replace variables in template
            $subject = $this->replaceVariables($template['subject'], $variables);
            $bodyHtml = $this->replaceVariables($template['body_html'], $variables);
            $bodyText = $this->replaceVariables($template['body_text'], $variables);
            
            // Prepare email data
            $emailData = [
                'to_email' => $recipientEmail,
                'subject' => $subject,
                'body_html' => $bodyHtml,
                'body_text' => $bodyText,
                'template_name' => $templateName
            ];
            
            // Add return URL to variables if provided
            if ($returnUrl) {
                $emailData['body_html'] = str_replace('{return_url}', $returnUrl, $emailData['body_html']);
                $emailData['body_text'] = str_replace('{return_url}', $returnUrl, $emailData['body_text']);
            }
            
            // Send email
            if ($this->config['email_queue'] === 'yes') {
                return email_queue($emailData);
            } else {
                return $this->sendEmail($emailData);
            }
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Send verification email
     */
    public function sendVerificationEmail($clientId, $email, $returnUrl = null) {
        try {
            // Create verification token
            $verification = email_create_verification($clientId, $email, $returnUrl);
            if (!$verification['success']) {
                return $verification;
            }
            
            // Get client details
            $client = localAPI('GetClientsDetails', ['clientid' => $clientId]);
            if ($client['result'] !== 'success') {
                return ['success' => false, 'message' => 'Client not found'];
            }
            
            // Prepare template variables
            $variables = [
                'client_name' => $client['firstname'] . ' ' . $client['lastname'],
                'client_email' => $email,
                'verification_url' => $verification['verification_url'],
                'company_name' => get_query_val('tblconfiguration', 'value', ['setting' => 'CompanyName']),
                'return_url' => $returnUrl ?: App::getUrl()
            ];
            
            // Send verification email
            return $this->sendTemplateEmail('email_verification', $email, $variables, $returnUrl);
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Initialize SMTP connection
     */
    private function initSMTP() {
        try {
            // Check if PHPMailer is available
            if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
                // Try to load PHPMailer from HostBill
                if (file_exists(ROOTDIR . '/includes/phpmailer/PHPMailer.php')) {
                    require_once ROOTDIR . '/includes/phpmailer/PHPMailer.php';
                    require_once ROOTDIR . '/includes/phpmailer/SMTP.php';
                    require_once ROOTDIR . '/includes/phpmailer/Exception.php';
                } else {
                    throw new Exception('PHPMailer not found');
                }
            }
            
            $this->smtp = new PHPMailer\PHPMailer\PHPMailer(true);
            
            // Enable debug mode if configured
            if ($this->config['debug_mode'] === 'yes') {
                $this->smtp->SMTPDebug = 2;
                $this->smtp->Debugoutput = function($str, $level) {
                    logActivity('SMTP Debug: ' . trim($str));
                };
            }
            
            return true;
            
        } catch (Exception $e) {
            logActivity('Failed to initialize SMTP: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Load email template
     */
    private function loadTemplate($templateName) {
        $result = full_query("SELECT * FROM mod_email_templates WHERE name = '" . mysql_real_escape_string($templateName) . "' AND active = 1");
        
        if (mysql_num_rows($result) > 0) {
            return mysql_fetch_assoc($result);
        }
        
        return null;
    }
    
    /**
     * Replace variables in template
     */
    private function replaceVariables($content, $variables) {
        foreach ($variables as $key => $value) {
            $content = str_replace('{' . $key . '}', $value, $content);
        }
        
        // Replace common HostBill variables
        $content = str_replace('{company_name}', get_query_val('tblconfiguration', 'value', ['setting' => 'CompanyName']), $content);
        $content = str_replace('{company_url}', App::getUrl(), $content);
        $content = str_replace('{current_date}', date('Y-m-d'), $content);
        $content = str_replace('{current_year}', date('Y'), $content);
        
        return $content;
    }
    
    /**
     * Log email activity
     */
    private function logEmail($emailData, $status, $errorMessage = null) {
        try {
            // Get client ID if possible
            $clientId = null;
            if (!empty($emailData['to_email'])) {
                $clientId = get_query_val('tblclients', 'id', ['email' => $emailData['to_email']]);
            }
            
            $sql = "INSERT INTO mod_email_log (client_id, to_email, subject, template_name, status, error_message) 
                    VALUES (
                        " . ($clientId ? intval($clientId) : 'NULL') . ",
                        '" . mysql_real_escape_string($emailData['to_email']) . "',
                        '" . mysql_real_escape_string($emailData['subject']) . "',
                        " . (!empty($emailData['template_name']) ? "'" . mysql_real_escape_string($emailData['template_name']) . "'" : 'NULL') . ",
                        '" . mysql_real_escape_string($status) . "',
                        " . ($errorMessage ? "'" . mysql_real_escape_string($errorMessage) . "'" : 'NULL') . "
                    )";
            
            full_query($sql);
            
        } catch (Exception $e) {
            // Don't throw exception for logging errors
            logActivity('Failed to log email: ' . $e->getMessage());
        }
    }
    
    /**
     * Get email statistics
     */
    public function getStatistics($days = 30) {
        try {
            $stats = [];
            
            // Total emails sent
            $result = full_query("SELECT COUNT(*) as count FROM mod_email_log WHERE sent_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)");
            $row = mysql_fetch_assoc($result);
            $stats['total_sent'] = $row['count'];
            
            // Successful emails
            $result = full_query("SELECT COUNT(*) as count FROM mod_email_log WHERE status = 'sent' AND sent_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)");
            $row = mysql_fetch_assoc($result);
            $stats['successful'] = $row['count'];
            
            // Failed emails
            $result = full_query("SELECT COUNT(*) as count FROM mod_email_log WHERE status = 'failed' AND sent_at >= DATE_SUB(NOW(), INTERVAL {$days} DAY)");
            $row = mysql_fetch_assoc($result);
            $stats['failed'] = $row['count'];
            
            // Queue size
            $result = full_query("SELECT COUNT(*) as count FROM mod_email_queue WHERE status = 'pending'");
            $row = mysql_fetch_assoc($result);
            $stats['queue_size'] = $row['count'];
            
            // Success rate
            $stats['success_rate'] = $stats['total_sent'] > 0 ? round(($stats['successful'] / $stats['total_sent']) * 100, 2) : 0;
            
            return $stats;
            
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
}
?>
