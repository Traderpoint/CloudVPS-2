<?php
/**
 * Email Module Test Suite
 * 
 * Comprehensive testing suite for HostBill Advanced Email Manager
 * Tests all functionality including SMTP, templates, verification, and queue processing
 * 
 * @version 1.0.0
 */

// Prevent direct access
if (php_sapi_name() !== 'cli') {
    die('This script can only be run from command line');
}

// Include required files
require_once 'email-client.php';
require_once 'email-templates.php';

/**
 * Main test runner
 */
function run_email_tests() {
    echo "🧪 HostBill Advanced Email Manager - Test Suite\n";
    echo "═══════════════════════════════════════════════\n";
    
    $tests = [
        'Module Configuration' => test_module_configuration(),
        'Email Client Initialization' => test_email_client_initialization(),
        'Email Templates' => test_email_templates(),
        'SMTP Connection' => test_smtp_connection(),
        'Email Queue' => test_email_queue(),
        'Email Verification' => test_email_verification(),
        'Template Processing' => test_template_processing(),
        'Hook System' => test_hook_system(),
        'Database Operations' => test_database_operations(),
        'Security Features' => test_security_features()
    ];
    
    $passed = 0;
    $total = count($tests);
    
    foreach ($tests as $testName => $result) {
        echo "\n" . str_pad($testName, 40, '.') . ' ';
        
        if ($result['success']) {
            echo "✅ PASSED\n";
            if (!empty($result['details'])) {
                echo "   " . $result['details'] . "\n";
            }
            $passed++;
        } else {
            echo "❌ FAILED\n";
            echo "   Error: " . $result['error'] . "\n";
        }
    }
    
    echo "\n" . str_repeat('═', 55) . "\n";
    echo "📊 Test Results: " . $passed . "/" . $total . " tests passed\n";
    
    if ($passed === $total) {
        echo "🎉 All tests passed! Module is ready for production.\n";
        return true;
    } else {
        echo "⚠️ Some tests failed. Please review and fix issues.\n";
        return false;
    }
}

/**
 * Test module configuration
 */
function test_module_configuration() {
    try {
        // Test if main module file exists and is readable
        if (!file_exists('email.php') || !is_readable('email.php')) {
            return ['success' => false, 'error' => 'Main module file not found or not readable'];
        }
        
        // Test configuration function
        include_once 'email.php';
        
        if (!function_exists('email_config')) {
            return ['success' => false, 'error' => 'Configuration function not found'];
        }
        
        $config = email_config();
        
        // Validate configuration structure
        $requiredFields = ['name', 'description', 'version', 'fields'];
        foreach ($requiredFields as $field) {
            if (!isset($config[$field])) {
                return ['success' => false, 'error' => 'Missing configuration field: ' . $field];
            }
        }
        
        // Validate required configuration fields
        $requiredConfigFields = ['smtp_host', 'smtp_username', 'smtp_password', 'from_email', 'email_verification'];
        foreach ($requiredConfigFields as $field) {
            if (!isset($config['fields'][$field])) {
                return ['success' => false, 'error' => 'Missing required config field: ' . $field];
            }
        }
        
        return [
            'success' => true,
            'details' => 'Configuration valid with ' . count($config['fields']) . ' fields'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test email client initialization
 */
function test_email_client_initialization() {
    try {
        $testConfig = [
            'smtp_host' => 'smtp.gmail.com',
            'smtp_port' => '587',
            'smtp_security' => 'tls',
            'smtp_username' => 'test@example.com',
            'smtp_password' => 'test_password',
            'from_email' => 'test@example.com',
            'from_name' => 'Test Sender',
            'debug_mode' => 'no'
        ];
        
        $client = new EmailClient($testConfig);
        
        if (!$client instanceof EmailClient) {
            return ['success' => false, 'error' => 'Failed to create EmailClient instance'];
        }
        
        return [
            'success' => true,
            'details' => 'EmailClient initialized successfully'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test email templates
 */
function test_email_templates() {
    try {
        // Test default templates
        $templates = get_default_email_templates();
        
        if (empty($templates)) {
            return ['success' => false, 'error' => 'No default templates found'];
        }
        
        // Validate template structure
        $requiredTemplates = ['email_verification', 'welcome_email', 'invoice_created', 'payment_received'];
        foreach ($requiredTemplates as $templateName) {
            if (!isset($templates[$templateName])) {
                return ['success' => false, 'error' => 'Missing required template: ' . $templateName];
            }
            
            $template = $templates[$templateName];
            $requiredFields = ['name', 'subject', 'body_html', 'body_text', 'variables'];
            foreach ($requiredFields as $field) {
                if (!isset($template[$field])) {
                    return ['success' => false, 'error' => 'Missing template field: ' . $field . ' in ' . $templateName];
                }
            }
        }
        
        return [
            'success' => true,
            'details' => count($templates) . ' templates validated'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test SMTP connection (mock test)
 */
function test_smtp_connection() {
    try {
        $testConfig = [
            'smtp_host' => 'invalid.smtp.server',
            'smtp_port' => '587',
            'smtp_security' => 'tls',
            'smtp_username' => 'invalid@example.com',
            'smtp_password' => 'invalid_password',
            'debug_mode' => 'no'
        ];
        
        $client = new EmailClient($testConfig);
        
        // Test connection (should fail with invalid credentials)
        $result = $client->testConnection();
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid response structure'];
        }
        
        // Should fail with invalid credentials
        if ($result['success']) {
            return ['success' => false, 'error' => 'Should fail with invalid credentials'];
        }
        
        return [
            'success' => true,
            'details' => 'SMTP connection test handled correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test email queue functionality
 */
function test_email_queue() {
    try {
        // Test queue data structure
        $emailData = [
            'to_email' => 'test@example.com',
            'to_name' => 'Test User',
            'from_email' => 'sender@example.com',
            'from_name' => 'Test Sender',
            'subject' => 'Test Email',
            'body_html' => '<p>Test HTML content</p>',
            'body_text' => 'Test text content',
            'priority' => 5
        ];
        
        // Validate required fields
        $requiredFields = ['to_email', 'subject'];
        foreach ($requiredFields as $field) {
            if (!isset($emailData[$field])) {
                return ['success' => false, 'error' => 'Missing required queue field: ' . $field];
            }
        }
        
        // Test queue processing logic
        $testConfig = [
            'queue_batch_size' => '5',
            'smtp_host' => 'test.smtp.com',
            'smtp_username' => 'test@example.com',
            'smtp_password' => 'test_password'
        ];
        
        $client = new EmailClient($testConfig);
        
        // Test process queue (should handle gracefully with no database)
        $result = $client->processQueue($testConfig);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid queue processing response'];
        }
        
        return [
            'success' => true,
            'details' => 'Email queue functionality validated'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test email verification
 */
function test_email_verification() {
    try {
        // Test verification token generation
        $token = bin2hex(random_bytes(32));
        
        if (strlen($token) !== 64) {
            return ['success' => false, 'error' => 'Invalid token length'];
        }
        
        // Test verification URL generation
        $verificationUrl = 'https://example.com/modules/addons/email/verify.php?token=' . $token;
        
        if (!filter_var($verificationUrl, FILTER_VALIDATE_URL)) {
            return ['success' => false, 'error' => 'Invalid verification URL'];
        }
        
        // Test expiry calculation
        $expiryHours = 24;
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . $expiryHours . ' hours'));
        
        if (strtotime($expiresAt) <= time()) {
            return ['success' => false, 'error' => 'Invalid expiry calculation'];
        }
        
        return [
            'success' => true,
            'details' => 'Email verification logic validated'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test template processing
 */
function test_template_processing() {
    try {
        // Test variable replacement
        $template = 'Hello {client_name}, your email is {client_email}. Company: {company_name}';
        $variables = [
            'client_name' => 'John Doe',
            'client_email' => 'john@example.com',
            'company_name' => 'Test Company'
        ];
        
        $processed = $template;
        foreach ($variables as $key => $value) {
            $processed = str_replace('{' . $key . '}', $value, $processed);
        }
        
        $expected = 'Hello John Doe, your email is john@example.com. Company: Test Company';
        
        if ($processed !== $expected) {
            return ['success' => false, 'error' => 'Template variable replacement failed'];
        }
        
        // Test HTML template processing
        $htmlTemplate = '<p>Hello {client_name}</p><p>Your verification link: <a href="{verification_url}">Click here</a></p>';
        $htmlVariables = [
            'client_name' => 'Jane Doe',
            'verification_url' => 'https://example.com/verify?token=abc123'
        ];
        
        $processedHtml = $htmlTemplate;
        foreach ($htmlVariables as $key => $value) {
            $processedHtml = str_replace('{' . $key . '}', $value, $processedHtml);
        }
        
        if (!strpos($processedHtml, 'Jane Doe') || !strpos($processedHtml, 'abc123')) {
            return ['success' => false, 'error' => 'HTML template processing failed'];
        }
        
        return [
            'success' => true,
            'details' => 'Template processing validated'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test hook system
 */
function test_hook_system() {
    try {
        // Test if hooks file exists
        if (!file_exists('hooks.php') || !is_readable('hooks.php')) {
            return ['success' => false, 'error' => 'Hooks file not found or not readable'];
        }
        
        include_once 'hooks.php';
        
        // Test hook functions
        $hookFunctions = [
            'register_all_email_hooks',
            'email_hook_client_add',
            'email_hook_invoice_created',
            'email_hook_payment_received',
            'email_hook_invoice_status_change',
            'email_hook_client_edit'
        ];
        
        foreach ($hookFunctions as $function) {
            if (!function_exists($function)) {
                return ['success' => false, 'error' => 'Missing hook function: ' . $function];
            }
        }
        
        return [
            'success' => true,
            'details' => count($hookFunctions) . ' hook functions validated'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test database operations
 */
function test_database_operations() {
    try {
        // Test SQL query structure (without executing)
        $testQueries = [
            "INSERT INTO mod_email_queue (to_email, subject, body_html) VALUES ('test@example.com', 'Test', '<p>Test</p>')",
            "SELECT * FROM mod_email_verification WHERE token = 'test_token'",
            "UPDATE mod_email_verification SET verified = 1 WHERE id = 1",
            "DELETE FROM mod_email_log WHERE sent_at < DATE_SUB(NOW(), INTERVAL 90 DAY)"
        ];
        
        foreach ($testQueries as $query) {
            // Basic SQL syntax validation
            if (!preg_match('/^(SELECT|INSERT|UPDATE|DELETE)\s+/i', $query)) {
                return ['success' => false, 'error' => 'Invalid SQL query structure'];
            }
        }
        
        // Test table structure definitions
        $requiredTables = [
            'mod_email_queue',
            'mod_email_verification',
            'mod_email_templates',
            'mod_email_log',
            'mod_email_config'
        ];
        
        foreach ($requiredTables as $table) {
            if (strlen($table) < 5 || !preg_match('/^mod_email_/', $table)) {
                return ['success' => false, 'error' => 'Invalid table name: ' . $table];
            }
        }
        
        return [
            'success' => true,
            'details' => 'Database operations validated'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test security features
 */
function test_security_features() {
    try {
        // Test file access protection
        $protectedFiles = ['email.php', 'email-client.php', 'admin.php', 'hooks.php'];
        
        foreach ($protectedFiles as $file) {
            if (!file_exists($file)) {
                continue;
            }
            
            $content = file_get_contents($file);
            
            // Check for HostBill protection
            if (strpos($content, "if (!defined('HOSTBILL'))") === false) {
                return ['success' => false, 'error' => 'Missing HostBill protection in ' . $file];
            }
        }
        
        // Test verification file protection
        if (file_exists('verify.php')) {
            $content = file_get_contents('verify.php');
            
            // Should include HostBill configuration
            if (strpos($content, 'configuration.php') === false) {
                return ['success' => false, 'error' => 'Verify file missing HostBill configuration'];
            }
        }
        
        // Test token generation security
        $token1 = bin2hex(random_bytes(32));
        $token2 = bin2hex(random_bytes(32));
        
        if ($token1 === $token2) {
            return ['success' => false, 'error' => 'Token generation not random'];
        }
        
        return [
            'success' => true,
            'details' => 'Security features implemented correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test live SMTP connection (requires valid credentials)
 */
function test_live_smtp($host, $username, $password, $port = 587, $security = 'tls') {
    try {
        $testConfig = [
            'smtp_host' => $host,
            'smtp_port' => $port,
            'smtp_security' => $security,
            'smtp_username' => $username,
            'smtp_password' => $password,
            'from_email' => $username,
            'from_name' => 'Test Sender'
        ];
        
        $client = new EmailClient($testConfig);
        
        $result = $client->testConnection();
        
        if ($result['success']) {
            echo "✅ Live SMTP connection test: PASSED\n";
            echo "   Server: " . $result['server_info'] . "\n";
            return true;
        } else {
            echo "❌ Live SMTP connection test: FAILED\n";
            echo "   Error: " . $result['message'] . "\n";
            return false;
        }
        
    } catch (Exception $e) {
        echo "❌ Live SMTP connection test: ERROR\n";
        echo "   Exception: " . $e->getMessage() . "\n";
        return false;
    }
}

// Command line interface
if (php_sapi_name() === 'cli') {
    $action = isset($argv[1]) ? $argv[1] : 'test';
    
    switch ($action) {
        case 'test':
            run_email_tests();
            break;
        case 'smtp':
            if (!isset($argv[2]) || !isset($argv[3]) || !isset($argv[4])) {
                echo "Usage: php test-module.php smtp <host> <username> <password> [port] [security]\n";
                exit(1);
            }
            $port = isset($argv[5]) ? $argv[5] : 587;
            $security = isset($argv[6]) ? $argv[6] : 'tls';
            test_live_smtp($argv[2], $argv[3], $argv[4], $port, $security);
            break;
        case 'help':
        default:
            echo "HostBill Advanced Email Manager Test Suite\n";
            echo "Usage: php test-module.php [action]\n";
            echo "Actions:\n";
            echo "  test                           - Run all tests\n";
            echo "  smtp <host> <user> <pass>      - Test live SMTP connection\n";
            echo "  help                           - Show this help message\n";
            break;
    }
}
?>
