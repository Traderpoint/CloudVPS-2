<?php
/**
 * HostBill Email Module
 * 
 * Comprehensive email management module for HostBill
 * Handles automated email sending, email verification, and customer communication
 * 
 * @version 1.0.0
 * @author HostBill Email Module
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Module configuration
 */
function email_config() {
    return [
        'name' => 'Advanced Email Manager',
        'description' => 'Comprehensive email management with verification and automated sending',
        'version' => '1.0.0',
        'author' => 'HostBill Email Module',
        'fields' => [
            'smtp_host' => [
                'name' => 'SMTP Host',
                'description' => 'SMTP server hostname (e.g., smtp.gmail.com)',
                'type' => 'text',
                'required' => true
            ],
            'smtp_port' => [
                'name' => 'SMTP Port',
                'description' => 'SMTP server port (587 for TLS, 465 for SSL, 25 for plain)',
                'type' => 'text',
                'default' => '587'
            ],
            'smtp_security' => [
                'name' => 'SMTP Security',
                'description' => 'Encryption method for SMTP connection',
                'type' => 'dropdown',
                'options' => [
                    'tls' => 'TLS (recommended)',
                    'ssl' => 'SSL',
                    'none' => 'None (not recommended)'
                ],
                'default' => 'tls'
            ],
            'smtp_username' => [
                'name' => 'SMTP Username',
                'description' => 'SMTP authentication username (usually email address)',
                'type' => 'text',
                'required' => true
            ],
            'smtp_password' => [
                'name' => 'SMTP Password',
                'description' => 'SMTP authentication password',
                'type' => 'password',
                'required' => true
            ],
            'from_email' => [
                'name' => 'From Email',
                'description' => 'Default sender email address',
                'type' => 'text',
                'required' => true
            ],
            'from_name' => [
                'name' => 'From Name',
                'description' => 'Default sender name',
                'type' => 'text',
                'required' => true
            ],
            'reply_to' => [
                'name' => 'Reply-To Email',
                'description' => 'Reply-to email address (optional)',
                'type' => 'text'
            ],
            'email_verification' => [
                'name' => 'Email Verification',
                'description' => 'Enable email verification for new clients',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'verification_expiry' => [
                'name' => 'Verification Link Expiry',
                'description' => 'Hours until verification link expires',
                'type' => 'text',
                'default' => '24'
            ],
            'auto_welcome_email' => [
                'name' => 'Auto Welcome Email',
                'description' => 'Send welcome email to new clients',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'auto_invoice_email' => [
                'name' => 'Auto Invoice Email',
                'description' => 'Send email when invoice is created',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'auto_payment_email' => [
                'name' => 'Auto Payment Email',
                'description' => 'Send email when payment is received',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'email_queue' => [
                'name' => 'Email Queue',
                'description' => 'Use email queue for better performance',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'queue_batch_size' => [
                'name' => 'Queue Batch Size',
                'description' => 'Number of emails to process per batch',
                'type' => 'text',
                'default' => '10'
            ],
            'debug_mode' => [
                'name' => 'Debug Mode',
                'description' => 'Enable detailed logging for troubleshooting',
                'type' => 'yesno',
                'default' => 'no'
            ]
        ]
    ];
}

/**
 * Module activation
 */
function email_activate() {
    // Create necessary database tables
    create_email_tables();
    
    // Register hooks
    register_email_hooks();
    
    // Log activation
    logActivity('Advanced Email Manager activated');
    
    return [
        'status' => 'success',
        'description' => 'Advanced Email Manager activated successfully. Configure SMTP settings to start sending emails.'
    ];
}

/**
 * Module deactivation
 */
function email_deactivate() {
    // Unregister hooks
    unregister_email_hooks();
    
    // Log deactivation
    logActivity('Advanced Email Manager deactivated');
    
    return [
        'status' => 'success',
        'description' => 'Advanced Email Manager deactivated successfully'
    ];
}

/**
 * Create database tables
 */
function create_email_tables() {
    // Email queue table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_queue` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `to_email` varchar(255) NOT NULL,
        `to_name` varchar(255) DEFAULT NULL,
        `from_email` varchar(255) NOT NULL,
        `from_name` varchar(255) DEFAULT NULL,
        `reply_to` varchar(255) DEFAULT NULL,
        `subject` varchar(500) NOT NULL,
        `body_html` longtext,
        `body_text` longtext,
        `attachments` text,
        `priority` tinyint(1) NOT NULL DEFAULT 5,
        `status` enum('pending','sending','sent','failed') NOT NULL DEFAULT 'pending',
        `attempts` tinyint(1) NOT NULL DEFAULT 0,
        `max_attempts` tinyint(1) NOT NULL DEFAULT 3,
        `error_message` text,
        `scheduled_at` timestamp NULL DEFAULT NULL,
        `sent_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `status` (`status`),
        KEY `priority` (`priority`),
        KEY `scheduled_at` (`scheduled_at`),
        KEY `created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    full_query($sql);
    
    // Email verification table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_verification` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `client_id` int(11) NOT NULL,
        `email` varchar(255) NOT NULL,
        `token` varchar(64) NOT NULL,
        `return_url` text,
        `verified` tinyint(1) NOT NULL DEFAULT 0,
        `expires_at` timestamp NOT NULL,
        `verified_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `token` (`token`),
        KEY `client_id` (`client_id`),
        KEY `email` (`email`),
        KEY `verified` (`verified`),
        KEY `expires_at` (`expires_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    full_query($sql);
    
    // Email templates table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_templates` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `subject` varchar(500) NOT NULL,
        `body_html` longtext,
        `body_text` longtext,
        `variables` text,
        `active` tinyint(1) NOT NULL DEFAULT 1,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `name` (`name`),
        KEY `active` (`active`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    full_query($sql);
    
    // Email log table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_email_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `client_id` int(11) DEFAULT NULL,
        `to_email` varchar(255) NOT NULL,
        `subject` varchar(500) NOT NULL,
        `template_name` varchar(100) DEFAULT NULL,
        `status` enum('sent','failed','bounced','opened','clicked') NOT NULL,
        `error_message` text,
        `sent_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `client_id` (`client_id`),
        KEY `to_email` (`to_email`),
        KEY `status` (`status`),
        KEY `sent_at` (`sent_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    full_query($sql);
}

/**
 * Register email hooks
 */
function register_email_hooks() {
    require_once dirname(__FILE__) . '/hooks.php';
    register_all_email_hooks();
}

/**
 * Unregister email hooks
 */
function unregister_email_hooks() {
    // Remove hooks from database
    full_query("DELETE FROM tblhooks WHERE hook IN ('ClientAdd', 'InvoiceCreated', 'AfterModuleCreate')");
}

/**
 * Send email function
 */
function email_send($params) {
    try {
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($params);
        
        return $emailClient->sendEmail($params);
        
    } catch (Exception $e) {
        logActivity('Email sending failed: ' . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Queue email function
 */
function email_queue($emailData) {
    try {
        $sql = "INSERT INTO mod_email_queue (
            to_email, to_name, from_email, from_name, reply_to,
            subject, body_html, body_text, attachments, priority, scheduled_at
        ) VALUES (
            '" . mysql_real_escape_string($emailData['to_email']) . "',
            '" . mysql_real_escape_string($emailData['to_name'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['from_email']) . "',
            '" . mysql_real_escape_string($emailData['from_name'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['reply_to'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['subject']) . "',
            '" . mysql_real_escape_string($emailData['body_html'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['body_text'] ?? '') . "',
            '" . mysql_real_escape_string(json_encode($emailData['attachments'] ?? [])) . "',
            " . intval($emailData['priority'] ?? 5) . ",
            " . ($emailData['scheduled_at'] ? "'" . mysql_real_escape_string($emailData['scheduled_at']) . "'" : 'NULL') . "
        )";
        
        if (full_query($sql)) {
            return ['success' => true, 'queue_id' => mysql_insert_id()];
        } else {
            return ['success' => false, 'message' => 'Failed to queue email'];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Process email queue
 */
function email_process_queue($params) {
    try {
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($params);
        
        return $emailClient->processQueue($params);
        
    } catch (Exception $e) {
        logActivity('Email queue processing failed: ' . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Create email verification
 */
function email_create_verification($clientId, $email, $returnUrl = null) {
    try {
        // Generate unique token
        $token = bin2hex(random_bytes(32));
        
        // Set expiry time
        $expiryHours = get_query_val('mod_email_config', 'value', ['setting' => 'verification_expiry']) ?: 24;
        $expiresAt = date('Y-m-d H:i:s', strtotime('+' . $expiryHours . ' hours'));
        
        // Insert verification record
        $sql = "INSERT INTO mod_email_verification (client_id, email, token, return_url, expires_at) 
                VALUES (
                    " . intval($clientId) . ",
                    '" . mysql_real_escape_string($email) . "',
                    '" . mysql_real_escape_string($token) . "',
                    " . ($returnUrl ? "'" . mysql_real_escape_string($returnUrl) . "'" : 'NULL') . ",
                    '" . mysql_real_escape_string($expiresAt) . "'
                )";
        
        if (full_query($sql)) {
            return [
                'success' => true,
                'token' => $token,
                'verification_url' => App::getUrl() . '/modules/addons/email/verify.php?token=' . $token
            ];
        } else {
            return ['success' => false, 'message' => 'Failed to create verification'];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Admin area output
 */
function email_output($params) {
    // Include admin interface
    require_once dirname(__FILE__) . '/admin.php';
    return email_admin_dashboard($params);
}

/**
 * Test SMTP connection
 */
function email_test_connection($params) {
    try {
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($params);
        
        return $emailClient->testConnection();
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Module information for HostBill
 */
function email_info() {
    return [
        'name' => 'Advanced Email Manager',
        'version' => '1.0.0',
        'description' => 'Comprehensive email management with verification and automated sending',
        'author' => 'HostBill Email Module',
        'type' => 'addon'
    ];
}
?>
