<?php
/**
 * Email Module Hooks
 * 
 * Automatic email sending hooks for HostBill Email Module
 * Handles client registration, invoice creation, and payment notifications
 * 
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Register all email hooks
 */
function register_all_email_hooks() {
    // Client registration hook
    add_hook('ClientAdd', 1, 'email_hook_client_add');
    
    // Invoice creation hook
    add_hook('InvoiceCreated', 1, 'email_hook_invoice_created');
    
    // Payment received hook
    add_hook('AfterModuleCreate', 1, 'email_hook_payment_received');
    
    // Invoice status change hook
    add_hook('InvoiceChangeStatus', 1, 'email_hook_invoice_status_change');
    
    // Client email change hook
    add_hook('ClientEdit', 1, 'email_hook_client_edit');
}

/**
 * Hook: Client registration
 */
function email_hook_client_add($vars) {
    try {
        // Get module configuration
        $config = get_email_module_config();
        if (!$config) {
            return;
        }
        
        // Check if email verification is enabled
        if ($config['email_verification'] !== 'yes') {
            return;
        }
        
        $clientId = $vars['userid'];
        $email = $vars['email'];
        $returnUrl = isset($vars['return_url']) ? $vars['return_url'] : null;
        
        // Log client registration
        logActivity('Email Module: New client registered - ID: ' . $clientId . ', Email: ' . $email);
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Send verification email
        $result = $emailClient->sendVerificationEmail($clientId, $email, $returnUrl);
        
        if ($result['success']) {
            logActivity('Email Module: Verification email sent to new client: ' . $email);
            
            // Mark client as unverified
            full_query("UPDATE tblclients SET emailverified = 0 WHERE id = " . intval($clientId));
        } else {
            logActivity('Email Module: Failed to send verification email: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logActivity('Email Module: Client add hook error: ' . $e->getMessage());
    }
}

/**
 * Hook: Invoice created
 */
function email_hook_invoice_created($vars) {
    try {
        // Get module configuration
        $config = get_email_module_config();
        if (!$config || $config['auto_invoice_email'] !== 'yes') {
            return;
        }
        
        $invoiceId = $vars['invoiceid'];
        
        // Get invoice details
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        if ($invoice['result'] !== 'success') {
            return;
        }
        
        // Get client details
        $client = localAPI('GetClientsDetails', ['clientid' => $invoice['userid']]);
        if ($client['result'] !== 'success') {
            return;
        }
        
        // Check if client email is verified (if verification is enabled)
        if ($config['email_verification'] === 'yes' && !$client['emailverified']) {
            logActivity('Email Module: Skipping invoice email - client email not verified: ' . $client['email']);
            return;
        }
        
        // Log invoice creation
        logActivity('Email Module: Invoice created - ID: ' . $invoiceId . ', Client: ' . $client['email']);
        
        // Prepare template variables
        $variables = [
            'client_name' => $client['firstname'] . ' ' . $client['lastname'],
            'invoice_number' => $invoice['invoicenum'],
            'invoice_date' => $invoice['date'],
            'due_date' => $invoice['duedate'],
            'total_amount' => $invoice['total'],
            'currency' => $invoice['currency'],
            'invoice_status' => $invoice['status'],
            'invoice_url' => App::getUrl() . '/viewinvoice.php?id=' . $invoiceId
        ];
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Send invoice email
        $result = $emailClient->sendTemplateEmail('invoice_created', $client['email'], $variables);
        
        if ($result['success']) {
            logActivity('Email Module: Invoice email sent for invoice ' . $invoiceId . ' to ' . $client['email']);
        } else {
            logActivity('Email Module: Failed to send invoice email: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logActivity('Email Module: Invoice created hook error: ' . $e->getMessage());
    }
}

/**
 * Hook: Payment received
 */
function email_hook_payment_received($vars) {
    try {
        // Check if this is a payment transaction
        if (!isset($vars['invoiceid']) || !isset($vars['transid'])) {
            return;
        }
        
        // Get module configuration
        $config = get_email_module_config();
        if (!$config || $config['auto_payment_email'] !== 'yes') {
            return;
        }
        
        $invoiceId = $vars['invoiceid'];
        $transactionId = $vars['transid'];
        
        // Get invoice details
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        if ($invoice['result'] !== 'success') {
            return;
        }
        
        // Only send email for paid invoices
        if ($invoice['status'] !== 'Paid') {
            return;
        }
        
        // Get client details
        $client = localAPI('GetClientsDetails', ['clientid' => $invoice['userid']]);
        if ($client['result'] !== 'success') {
            return;
        }
        
        // Check if client email is verified (if verification is enabled)
        if ($config['email_verification'] === 'yes' && !$client['emailverified']) {
            logActivity('Email Module: Skipping payment email - client email not verified: ' . $client['email']);
            return;
        }
        
        // Log payment received
        logActivity('Email Module: Payment received - Invoice: ' . $invoiceId . ', Transaction: ' . $transactionId . ', Client: ' . $client['email']);
        
        // Get payment details
        $paymentAmount = $vars['amount'] ?? $invoice['total'];
        $paymentMethod = $vars['gateway'] ?? 'Unknown';
        $paymentDate = date('Y-m-d H:i:s');
        
        // Prepare template variables
        $variables = [
            'client_name' => $client['firstname'] . ' ' . $client['lastname'],
            'invoice_number' => $invoice['invoicenum'],
            'payment_amount' => $paymentAmount,
            'currency' => $invoice['currency'],
            'payment_date' => $paymentDate,
            'payment_method' => $paymentMethod,
            'transaction_id' => $transactionId,
            'invoice_url' => App::getUrl() . '/viewinvoice.php?id=' . $invoiceId
        ];
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Send payment confirmation email
        $result = $emailClient->sendTemplateEmail('payment_received', $client['email'], $variables);
        
        if ($result['success']) {
            logActivity('Email Module: Payment confirmation email sent for invoice ' . $invoiceId . ' to ' . $client['email']);
        } else {
            logActivity('Email Module: Failed to send payment confirmation email: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logActivity('Email Module: Payment received hook error: ' . $e->getMessage());
    }
}

/**
 * Hook: Invoice status change
 */
function email_hook_invoice_status_change($vars) {
    try {
        // Get module configuration
        $config = get_email_module_config();
        if (!$config) {
            return;
        }
        
        $invoiceId = $vars['invoiceid'];
        $oldStatus = $vars['oldstatus'];
        $newStatus = $vars['newstatus'];
        
        // Only process specific status changes
        $notifyStatuses = ['Paid', 'Cancelled', 'Overdue'];
        if (!in_array($newStatus, $notifyStatuses)) {
            return;
        }
        
        // Get invoice details
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        if ($invoice['result'] !== 'success') {
            return;
        }
        
        // Get client details
        $client = localAPI('GetClientsDetails', ['clientid' => $invoice['userid']]);
        if ($client['result'] !== 'success') {
            return;
        }
        
        // Check if client email is verified (if verification is enabled)
        if ($config['email_verification'] === 'yes' && !$client['emailverified']) {
            return;
        }
        
        // Log status change
        logActivity('Email Module: Invoice status changed - ID: ' . $invoiceId . ', From: ' . $oldStatus . ', To: ' . $newStatus);
        
        // Determine template based on new status
        $templateName = null;
        switch ($newStatus) {
            case 'Paid':
                if ($config['auto_payment_email'] === 'yes') {
                    $templateName = 'payment_received';
                }
                break;
            case 'Cancelled':
                $templateName = 'invoice_cancelled';
                break;
            case 'Overdue':
                $templateName = 'invoice_overdue';
                break;
        }
        
        if (!$templateName) {
            return;
        }
        
        // Prepare template variables
        $variables = [
            'client_name' => $client['firstname'] . ' ' . $client['lastname'],
            'invoice_number' => $invoice['invoicenum'],
            'invoice_date' => $invoice['date'],
            'due_date' => $invoice['duedate'],
            'total_amount' => $invoice['total'],
            'currency' => $invoice['currency'],
            'invoice_status' => $newStatus,
            'old_status' => $oldStatus,
            'invoice_url' => App::getUrl() . '/viewinvoice.php?id=' . $invoiceId
        ];
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Send status change email
        $result = $emailClient->sendTemplateEmail($templateName, $client['email'], $variables);
        
        if ($result['success']) {
            logActivity('Email Module: Status change email sent for invoice ' . $invoiceId . ' to ' . $client['email']);
        } else {
            logActivity('Email Module: Failed to send status change email: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logActivity('Email Module: Invoice status change hook error: ' . $e->getMessage());
    }
}

/**
 * Hook: Client email change
 */
function email_hook_client_edit($vars) {
    try {
        // Check if email was changed
        if (!isset($vars['olddata']['email']) || !isset($vars['email'])) {
            return;
        }
        
        $oldEmail = $vars['olddata']['email'];
        $newEmail = $vars['email'];
        
        // Skip if email didn't change
        if ($oldEmail === $newEmail) {
            return;
        }
        
        // Get module configuration
        $config = get_email_module_config();
        if (!$config || $config['email_verification'] !== 'yes') {
            return;
        }
        
        $clientId = $vars['userid'];
        
        // Log email change
        logActivity('Email Module: Client email changed - ID: ' . $clientId . ', From: ' . $oldEmail . ', To: ' . $newEmail);
        
        // Mark new email as unverified
        full_query("UPDATE tblclients SET emailverified = 0 WHERE id = " . intval($clientId));
        
        // Delete old verification records
        full_query("DELETE FROM mod_email_verification WHERE client_id = " . intval($clientId));
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Send verification email to new address
        $result = $emailClient->sendVerificationEmail($clientId, $newEmail);
        
        if ($result['success']) {
            logActivity('Email Module: Verification email sent to new address: ' . $newEmail);
        } else {
            logActivity('Email Module: Failed to send verification email to new address: ' . $result['message']);
        }
        
    } catch (Exception $e) {
        logActivity('Email Module: Client edit hook error: ' . $e->getMessage());
    }
}

/**
 * Get email module configuration
 */
function get_email_module_config() {
    static $config = null;
    
    if ($config === null) {
        $config = [];
        
        $result = full_query("SELECT setting, value FROM tblconfiguration WHERE setting LIKE 'addon_email_%'");
        
        while ($row = mysql_fetch_assoc($result)) {
            $key = str_replace('addon_email_', '', $row['setting']);
            $config[$key] = $row['value'];
        }
        
        // Return null if no configuration found
        if (empty($config)) {
            $config = false;
        }
    }
    
    return $config;
}

/**
 * Queue email for later processing
 */
function queue_email_for_processing($emailData) {
    try {
        $sql = "INSERT INTO mod_email_queue (
            to_email, to_name, from_email, from_name, reply_to,
            subject, body_html, body_text, priority
        ) VALUES (
            '" . mysql_real_escape_string($emailData['to_email']) . "',
            '" . mysql_real_escape_string($emailData['to_name'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['from_email']) . "',
            '" . mysql_real_escape_string($emailData['from_name'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['reply_to'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['subject']) . "',
            '" . mysql_real_escape_string($emailData['body_html'] ?? '') . "',
            '" . mysql_real_escape_string($emailData['body_text'] ?? '') . "',
            " . intval($emailData['priority'] ?? 5) . "
        )";
        
        return full_query($sql);
        
    } catch (Exception $e) {
        logActivity('Email Module: Failed to queue email: ' . $e->getMessage());
        return false;
    }
}

/**
 * Process email queue (can be called via cron)
 */
function process_email_queue() {
    try {
        // Get module configuration
        $config = get_email_module_config();
        if (!$config) {
            return ['success' => false, 'message' => 'Email module not configured'];
        }
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Process queue
        return $emailClient->processQueue($config);
        
    } catch (Exception $e) {
        logActivity('Email Module: Queue processing error: ' . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Clean up old verification records
 */
function cleanup_expired_verifications() {
    try {
        // Delete expired verification records (older than 7 days)
        $sql = "DELETE FROM mod_email_verification WHERE expires_at < DATE_SUB(NOW(), INTERVAL 7 DAY)";
        full_query($sql);
        
        // Delete old email logs (older than 90 days)
        $sql = "DELETE FROM mod_email_log WHERE sent_at < DATE_SUB(NOW(), INTERVAL 90 DAY)";
        full_query($sql);
        
        // Delete old queue entries (older than 30 days)
        $sql = "DELETE FROM mod_email_queue WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY) AND status IN ('sent', 'failed')";
        full_query($sql);
        
        logActivity('Email Module: Cleanup completed');
        
    } catch (Exception $e) {
        logActivity('Email Module: Cleanup error: ' . $e->getMessage());
    }
}

/**
 * Send custom email
 */
function send_custom_email($toEmail, $subject, $bodyHtml, $bodyText = '', $templateVariables = []) {
    try {
        // Get module configuration
        $config = get_email_module_config();
        if (!$config) {
            return ['success' => false, 'message' => 'Email module not configured'];
        }
        
        // Load email client
        require_once dirname(__FILE__) . '/email-client.php';
        $emailClient = new EmailClient($config);
        
        // Replace variables in content
        foreach ($templateVariables as $key => $value) {
            $subject = str_replace('{' . $key . '}', $value, $subject);
            $bodyHtml = str_replace('{' . $key . '}', $value, $bodyHtml);
            $bodyText = str_replace('{' . $key . '}', $value, $bodyText);
        }
        
        // Prepare email data
        $emailData = [
            'to_email' => $toEmail,
            'subject' => $subject,
            'body_html' => $bodyHtml,
            'body_text' => $bodyText
        ];
        
        // Send email
        if ($config['email_queue'] === 'yes') {
            return email_queue($emailData);
        } else {
            return $emailClient->sendEmail($emailData);
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}
?>
