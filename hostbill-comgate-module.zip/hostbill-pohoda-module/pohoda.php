<?php
/**
 * HostBill Pohoda Integration Module
 * Direct integration with Pohoda mServer API for automatic invoice synchronization
 * 
 * @package HostBill
 * @subpackage Modules
 * @author CloudVPS Team
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Pohoda Module Configuration
 */
function pohoda_config() {
    return [
        'name' => 'Pohoda Integration',
        'description' => 'Automatic synchronization with Pohoda accounting software via mServer API',
        'version' => '1.0.0',
        'author' => 'CloudVPS Team',
        'fields' => [
            'mserver_url' => [
                'name' => 'mServer URL',
                'description' => 'Pohoda mServer URL (default: http://127.0.0.1:444)',
                'type' => 'text',
                'default' => 'http://127.0.0.1:444'
            ],
            'mserver_username' => [
                'name' => 'mServer Username',
                'description' => 'Pohoda API username',
                'type' => 'text',
                'required' => true
            ],
            'mserver_password' => [
                'name' => 'mServer Password',
                'description' => 'Pohoda API password',
                'type' => 'password',
                'required' => true
            ],
            'data_file' => [
                'name' => 'Data File',
                'description' => 'Pohoda database file name (e.g., StwPh_12345678_2024.mdb)',
                'type' => 'text',
                'required' => true
            ],
            'auto_sync_invoices' => [
                'name' => 'Auto Sync Invoices',
                'description' => 'Automatically sync invoices when created',
                'type' => 'yesno',
                'default' => 'on'
            ],
            'auto_sync_payments' => [
                'name' => 'Auto Sync Payments',
                'description' => 'Automatically sync payments when received',
                'type' => 'yesno',
                'default' => 'on'
            ],
            'sync_customer_data' => [
                'name' => 'Sync Customer Data',
                'description' => 'Include customer details in Pohoda invoices',
                'type' => 'yesno',
                'default' => 'on'
            ],
            'debug_mode' => [
                'name' => 'Debug Mode',
                'description' => 'Enable detailed logging for troubleshooting',
                'type' => 'yesno',
                'default' => 'off'
            ],
            'test_connection' => [
                'name' => 'Test Connection',
                'description' => 'Test connection to Pohoda mServer',
                'type' => 'button',
                'onclick' => 'testPohodaConnection()'
            ]
        ]
    ];
}

/**
 * Module activation
 */
function pohoda_activate($vars) {
    // Create log table for Pohoda sync
    $query = "CREATE TABLE IF NOT EXISTS `mod_pohoda_sync_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `invoice_id` int(11) NOT NULL,
        `action` varchar(50) NOT NULL,
        `status` enum('success','error','pending') NOT NULL DEFAULT 'pending',
        `pohoda_invoice_id` varchar(100) DEFAULT NULL,
        `error_message` text,
        `xml_request` longtext,
        `xml_response` longtext,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `invoice_id` (`invoice_id`),
        KEY `status` (`status`),
        KEY `created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    full_query($query);
    
    // Create configuration table
    $query = "CREATE TABLE IF NOT EXISTS `mod_pohoda_config` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting_name` varchar(100) NOT NULL,
        `setting_value` text,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting_name` (`setting_name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    full_query($query);
    
    logActivity('Pohoda Integration Module activated successfully');
    return ['status' => 'success', 'description' => 'Pohoda Integration Module activated'];
}

/**
 * Module deactivation
 */
function pohoda_deactivate($vars) {
    logActivity('Pohoda Integration Module deactivated');
    return ['status' => 'success', 'description' => 'Pohoda Integration Module deactivated'];
}

/**
 * Module upgrade
 */
function pohoda_upgrade($vars) {
    $version = $vars['version'];
    logActivity("Pohoda Integration Module upgraded to version {$version}");
    return ['status' => 'success', 'description' => 'Module upgraded successfully'];
}

/**
 * Admin area output
 */
function pohoda_output($vars) {
    $modulelink = $vars['modulelink'];
    $version = $vars['version'];
    
    // Handle actions
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'test_connection':
                return pohoda_test_connection($vars);
            case 'sync_invoice':
                return pohoda_sync_invoice($_POST['invoice_id'], $vars);
            case 'view_logs':
                return pohoda_view_logs($vars);
        }
    }
    
    // Get statistics
    $stats = pohoda_get_statistics();
    
    // Admin interface HTML
    $output = '
    <div class="pohoda-admin-panel">
        <h2>Pohoda Integration Status</h2>
        
        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Connection Status</h3>
                    </div>
                    <div class="panel-body">
                        <p><strong>mServer URL:</strong> ' . htmlspecialchars($vars['mserver_url']) . '</p>
                        <p><strong>Data File:</strong> ' . htmlspecialchars($vars['data_file']) . '</p>
                        <p><strong>Username:</strong> ' . htmlspecialchars($vars['mserver_username']) . '</p>
                        <p><strong>Auto Sync:</strong> ' . ($vars['auto_sync_invoices'] == 'on' ? 'Enabled' : 'Disabled') . '</p>
                        
                        <form method="post">
                            <input type="hidden" name="action" value="test_connection">
                            <button type="submit" class="btn btn-primary">Test Connection</button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Sync Statistics</h3>
                    </div>
                    <div class="panel-body">
                        <p><strong>Total Synced:</strong> ' . $stats['total_synced'] . '</p>
                        <p><strong>Successful:</strong> ' . $stats['successful'] . '</p>
                        <p><strong>Failed:</strong> ' . $stats['failed'] . '</p>
                        <p><strong>Last Sync:</strong> ' . ($stats['last_sync'] ?: 'Never') . '</p>
                        
                        <form method="post">
                            <input type="hidden" name="action" value="view_logs">
                            <button type="submit" class="btn btn-info">View Logs</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Manual Sync</h3>
            </div>
            <div class="panel-body">
                <form method="post" class="form-inline">
                    <input type="hidden" name="action" value="sync_invoice">
                    <div class="form-group">
                        <label for="invoice_id">Invoice ID:</label>
                        <input type="number" name="invoice_id" class="form-control" placeholder="Enter invoice ID" required>
                    </div>
                    <button type="submit" class="btn btn-success">Sync Invoice</button>
                </form>
            </div>
        </div>
    </div>
    
    <style>
    .pohoda-admin-panel .panel { margin-bottom: 20px; }
    .pohoda-admin-panel .form-inline .form-group { margin-right: 10px; }
    </style>
    ';
    
    return $output;
}

/**
 * Get sync statistics
 */
function pohoda_get_statistics() {
    $total = select_query('mod_pohoda_sync_log', 'COUNT(*) as count', [])['count'] ?? 0;
    $successful = select_query('mod_pohoda_sync_log', 'COUNT(*) as count', ['status' => 'success'])['count'] ?? 0;
    $failed = select_query('mod_pohoda_sync_log', 'COUNT(*) as count', ['status' => 'error'])['count'] ?? 0;
    
    $lastSync = select_query('mod_pohoda_sync_log', 'created_at', [], 'created_at', 'DESC', '', 1);
    $lastSyncDate = $lastSync ? date('Y-m-d H:i:s', strtotime($lastSync['created_at'])) : null;
    
    return [
        'total_synced' => $total,
        'successful' => $successful,
        'failed' => $failed,
        'last_sync' => $lastSyncDate
    ];
}

/**
 * Test connection to Pohoda mServer
 */
function pohoda_test_connection($vars) {
    try {
        $client = new PohodaClient($vars);
        $result = $client->testConnection();
        
        if ($result['success']) {
            return '<div class="alert alert-success">✅ Connection to Pohoda mServer successful!</div>';
        } else {
            return '<div class="alert alert-danger">❌ Connection failed: ' . htmlspecialchars($result['error']) . '</div>';
        }
    } catch (Exception $e) {
        return '<div class="alert alert-danger">❌ Connection test failed: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}

/**
 * Manual invoice sync
 */
function pohoda_sync_invoice($invoiceId, $vars) {
    try {
        $client = new PohodaClient($vars);
        $result = $client->syncInvoice($invoiceId);
        
        if ($result['success']) {
            return '<div class="alert alert-success">✅ Invoice ' . $invoiceId . ' synced successfully!</div>';
        } else {
            return '<div class="alert alert-danger">❌ Sync failed: ' . htmlspecialchars($result['error']) . '</div>';
        }
    } catch (Exception $e) {
        return '<div class="alert alert-danger">❌ Sync failed: ' . htmlspecialchars($e->getMessage()) . '</div>';
    }
}

/**
 * View sync logs
 */
function pohoda_view_logs($vars) {
    $logs = select_query('mod_pohoda_sync_log', '*', [], 'created_at', 'DESC', '', 50);
    
    $output = '<div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Recent Sync Logs (Last 50)</h3>
        </div>
        <div class="panel-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Invoice ID</th>
                        <th>Action</th>
                        <th>Status</th>
                        <th>Pohoda ID</th>
                        <th>Error</th>
                    </tr>
                </thead>
                <tbody>';
    
    foreach ($logs as $log) {
        $statusClass = $log['status'] == 'success' ? 'success' : ($log['status'] == 'error' ? 'danger' : 'warning');
        $output .= '<tr class="' . $statusClass . '">
            <td>' . date('Y-m-d H:i', strtotime($log['created_at'])) . '</td>
            <td>' . $log['invoice_id'] . '</td>
            <td>' . $log['action'] . '</td>
            <td><span class="label label-' . $statusClass . '">' . strtoupper($log['status']) . '</span></td>
            <td>' . ($log['pohoda_invoice_id'] ?: '-') . '</td>
            <td>' . ($log['error_message'] ? htmlspecialchars(substr($log['error_message'], 0, 100)) : '-') . '</td>
        </tr>';
    }
    
    $output .= '</tbody></table></div></div>';
    
    return $output;
}

// Include Pohoda client class
require_once __DIR__ . '/pohoda-client.php';

/**
 * Hook: After invoice is created
 */
add_hook('AfterInvoiceCreated', 1, function($vars) {
    $moduleConfig = getModuleConfig('pohoda');
    
    if ($moduleConfig && $moduleConfig['auto_sync_invoices'] == 'on') {
        pohoda_sync_invoice_async($vars['invoiceid'], $moduleConfig);
    }
});

/**
 * Hook: After payment is received
 */
add_hook('AfterInvoicePaymentReceived', 1, function($vars) {
    $moduleConfig = getModuleConfig('pohoda');
    
    if ($moduleConfig && $moduleConfig['auto_sync_payments'] == 'on') {
        pohoda_sync_payment_async($vars['invoiceid'], $vars, $moduleConfig);
    }
});

/**
 * Hook: After invoice status change
 */
add_hook('AfterInvoiceStatusChange', 1, function($vars) {
    $moduleConfig = getModuleConfig('pohoda');
    
    if ($moduleConfig && $vars['status'] == 'Paid') {
        pohoda_sync_payment_async($vars['invoiceid'], $vars, $moduleConfig);
    }
});

/**
 * Async invoice sync (background processing)
 */
function pohoda_sync_invoice_async($invoiceId, $moduleConfig) {
    try {
        // Log sync attempt
        insert_query('mod_pohoda_sync_log', [
            'invoice_id' => $invoiceId,
            'action' => 'invoice_created',
            'status' => 'pending'
        ]);
        
        $client = new PohodaClient($moduleConfig);
        $result = $client->syncInvoice($invoiceId);
        
        // Update log with result
        $logId = mysql_insert_id();
        update_query('mod_pohoda_sync_log', [
            'status' => $result['success'] ? 'success' : 'error',
            'pohoda_invoice_id' => $result['pohoda_invoice_id'] ?? null,
            'error_message' => $result['error'] ?? null,
            'xml_request' => $result['xml_request'] ?? null,
            'xml_response' => $result['xml_response'] ?? null
        ], ['id' => $logId]);
        
        if ($result['success']) {
            logActivity("Pohoda: Invoice {$invoiceId} synced successfully");
        } else {
            logActivity("Pohoda: Failed to sync invoice {$invoiceId}: " . $result['error']);
        }
        
    } catch (Exception $e) {
        logActivity("Pohoda: Exception during invoice {$invoiceId} sync: " . $e->getMessage());
        
        // Update log with error
        if (isset($logId)) {
            update_query('mod_pohoda_sync_log', [
                'status' => 'error',
                'error_message' => $e->getMessage()
            ], ['id' => $logId]);
        }
    }
}

/**
 * Async payment sync (background processing)
 */
function pohoda_sync_payment_async($invoiceId, $paymentVars, $moduleConfig) {
    try {
        // Log sync attempt
        insert_query('mod_pohoda_sync_log', [
            'invoice_id' => $invoiceId,
            'action' => 'payment_received',
            'status' => 'pending'
        ]);
        
        $client = new PohodaClient($moduleConfig);
        $result = $client->syncInvoiceWithPayment($invoiceId, $paymentVars);
        
        // Update log with result
        $logId = mysql_insert_id();
        update_query('mod_pohoda_sync_log', [
            'status' => $result['success'] ? 'success' : 'error',
            'pohoda_invoice_id' => $result['pohoda_invoice_id'] ?? null,
            'error_message' => $result['error'] ?? null,
            'xml_request' => $result['xml_request'] ?? null,
            'xml_response' => $result['xml_response'] ?? null
        ], ['id' => $logId]);
        
        if ($result['success']) {
            logActivity("Pohoda: Payment for invoice {$invoiceId} synced successfully");
        } else {
            logActivity("Pohoda: Failed to sync payment for invoice {$invoiceId}: " . $result['error']);
        }
        
    } catch (Exception $e) {
        logActivity("Pohoda: Exception during payment sync for invoice {$invoiceId}: " . $e->getMessage());
        
        // Update log with error
        if (isset($logId)) {
            update_query('mod_pohoda_sync_log', [
                'status' => 'error',
                'error_message' => $e->getMessage()
            ], ['id' => $logId]);
        }
    }
}

/**
 * Get module configuration helper
 */
function getModuleConfig($moduleName) {
    $result = select_query('tbladdonmodules', '*', ['module' => $moduleName, 'setting' => 'enabled', 'value' => 'on']);
    
    if (!$result) {
        return null;
    }
    
    // Get all module settings
    $settings = select_query('tbladdonmodules', '*', ['module' => $moduleName]);
    $config = [];
    
    foreach ($settings as $setting) {
        $config[$setting['setting']] = $setting['value'];
    }
    
    return $config;
}

/**
 * AJAX handler for admin interface
 */
if (isset($_GET['ajax']) && $_GET['ajax'] == 'pohoda') {
    header('Content-Type: application/json');
    
    $action = $_POST['action'] ?? $_GET['action'];
    $moduleConfig = getModuleConfig('pohoda');
    
    switch ($action) {
        case 'test_connection':
            try {
                $client = new PohodaClient($moduleConfig);
                $result = $client->testConnection();
                echo json_encode($result);
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
            break;
            
        case 'get_stats':
            echo json_encode(pohoda_get_statistics());
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Unknown action']);
    }
    
    exit;
}

?>

<script>
function testPohodaConnection() {
    $.post('?ajax=pohoda', {action: 'test_connection'}, function(data) {
        if (data.success) {
            alert('✅ Connection successful!');
        } else {
            alert('❌ Connection failed: ' + data.error);
        }
    }, 'json');
}
</script>
