<?php
/**
 * HostBill Pohoda Integration Hooks
 * Automatic synchronization hooks for invoice and payment events
 * 
 * @package HostBill
 * @subpackage Pohoda
 * @author CloudVPS Team
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Hook: After invoice is created
 * Automatically sync new invoices to Pohoda
 */
add_hook('InvoiceCreated', 1, function($vars) {
    try {
        $moduleConfig = getModuleConfiguration('pohoda');
        
        if (!$moduleConfig || $moduleConfig['auto_sync_invoices'] != 'on') {
            return;
        }
        
        $invoiceId = $vars['invoiceid'];
        
        logActivity("Pohoda Hook: Invoice {$invoiceId} created - starting sync");
        
        // Background sync to avoid blocking invoice creation
        pohoda_background_sync_invoice($invoiceId, $moduleConfig);
        
    } catch (Exception $e) {
        logActivity("Pohoda Hook Error (InvoiceCreated): " . $e->getMessage());
    }
});

/**
 * Hook: After payment is received
 * Automatically sync payments to Pohoda
 */
add_hook('AfterModuleCreate', 1, function($vars) {
    // This hook is triggered after successful payment
    try {
        $moduleConfig = getModuleConfiguration('pohoda');
        
        if (!$moduleConfig || $moduleConfig['auto_sync_payments'] != 'on') {
            return;
        }
        
        $invoiceId = $vars['invoiceid'] ?? null;
        
        if ($invoiceId) {
            logActivity("Pohoda Hook: Payment received for invoice {$invoiceId} - starting sync");
            
            // Prepare payment data
            $paymentData = [
                'transaction_id' => $vars['transid'] ?? 'HB-' . time(),
                'method' => $vars['paymentmethod'] ?? 'manual',
                'amount' => $vars['amount'] ?? 0,
                'currency' => 'CZK',
                'date' => date('Y-m-d'),
                'notes' => "HostBill payment: " . ($vars['transid'] ?? 'Manual')
            ];
            
            // Background sync with payment
            pohoda_background_sync_payment($invoiceId, $paymentData, $moduleConfig);
        }
        
    } catch (Exception $e) {
        logActivity("Pohoda Hook Error (AfterModuleCreate): " . $e->getMessage());
    }
});

/**
 * Hook: Invoice status changed to Paid
 * Sync when invoice is manually marked as paid
 */
add_hook('InvoiceChangeStatus', 1, function($vars) {
    try {
        $moduleConfig = getModuleConfiguration('pohoda');
        
        if (!$moduleConfig || $moduleConfig['auto_sync_payments'] != 'on') {
            return;
        }
        
        $invoiceId = $vars['invoiceid'];
        $newStatus = $vars['status'];
        
        if ($newStatus == 'Paid') {
            logActivity("Pohoda Hook: Invoice {$invoiceId} marked as paid - starting sync");
            
            // Get payment information
            $paymentInfo = select_query('tblaccounts', '*', [
                'invoiceid' => $invoiceId,
                'amountin' => ['>', 0]
            ], 'id', 'DESC', '', 1);
            
            $paymentData = null;
            if ($paymentInfo) {
                $paymentData = [
                    'transaction_id' => $paymentInfo['transid'] ?? 'HB-MANUAL-' . time(),
                    'method' => $paymentInfo['gateway'] ?? 'manual',
                    'amount' => $paymentInfo['amountin'],
                    'currency' => 'CZK',
                    'date' => date('Y-m-d', strtotime($paymentInfo['date'])),
                    'notes' => "HostBill payment: " . ($paymentInfo['description'] ?? 'Manual payment')
                ];
            }
            
            // Background sync with payment
            pohoda_background_sync_payment($invoiceId, $paymentData, $moduleConfig);
        }
        
    } catch (Exception $e) {
        logActivity("Pohoda Hook Error (InvoiceChangeStatus): " . $e->getMessage());
    }
});

/**
 * Background invoice sync (non-blocking)
 */
function pohoda_background_sync_invoice($invoiceId, $moduleConfig) {
    try {
        // Log sync attempt
        insert_query('mod_pohoda_sync_log', [
            'invoice_id' => $invoiceId,
            'action' => 'invoice_created',
            'status' => 'pending'
        ]);
        
        $logId = mysql_insert_id();
        
        // Create Pohoda client
        require_once __DIR__ . '/pohoda-client.php';
        $client = new PohodaClient($moduleConfig);
        
        // Sync invoice
        $result = $client->syncInvoice($invoiceId);
        
        // Update log
        update_query('mod_pohoda_sync_log', [
            'status' => $result['success'] ? 'success' : 'error',
            'pohoda_invoice_id' => $result['pohoda_invoice_id'] ?? null,
            'error_message' => $result['error'] ?? null,
            'xml_request' => $result['xml_request'] ?? null,
            'xml_response' => $result['xml_response'] ?? null
        ], ['id' => $logId]);
        
        if ($result['success']) {
            logActivity("Pohoda: Invoice {$invoiceId} synced successfully via HostBill hook");
        } else {
            logActivity("Pohoda: Failed to sync invoice {$invoiceId} via HostBill hook: " . $result['error']);
        }
        
    } catch (Exception $e) {
        logActivity("Pohoda: Exception during background invoice sync {$invoiceId}: " . $e->getMessage());
        
        if (isset($logId)) {
            update_query('mod_pohoda_sync_log', [
                'status' => 'error',
                'error_message' => $e->getMessage()
            ], ['id' => $logId]);
        }
    }
}

/**
 * Background payment sync (non-blocking)
 */
function pohoda_background_sync_payment($invoiceId, $paymentData, $moduleConfig) {
    try {
        // Log sync attempt
        insert_query('mod_pohoda_sync_log', [
            'invoice_id' => $invoiceId,
            'action' => 'payment_received',
            'status' => 'pending'
        ]);
        
        $logId = mysql_insert_id();
        
        // Create Pohoda client
        require_once __DIR__ . '/pohoda-client.php';
        $client = new PohodaClient($moduleConfig);
        
        // Sync invoice with payment
        $result = $client->syncInvoiceWithPayment($invoiceId, $paymentData);
        
        // Update log
        update_query('mod_pohoda_sync_log', [
            'status' => $result['success'] ? 'success' : 'error',
            'pohoda_invoice_id' => $result['pohoda_invoice_id'] ?? null,
            'error_message' => $result['error'] ?? null,
            'xml_request' => $result['xml_request'] ?? null,
            'xml_response' => $result['xml_response'] ?? null
        ], ['id' => $logId]);
        
        if ($result['success']) {
            logActivity("Pohoda: Payment for invoice {$invoiceId} synced successfully via HostBill hook");
        } else {
            logActivity("Pohoda: Failed to sync payment for invoice {$invoiceId} via HostBill hook: " . $result['error']);
        }
        
    } catch (Exception $e) {
        logActivity("Pohoda: Exception during background payment sync {$invoiceId}: " . $e->getMessage());
        
        if (isset($logId)) {
            update_query('mod_pohoda_sync_log', [
                'status' => 'error',
                'error_message' => $e->getMessage()
            ], ['id' => $logId]);
        }
    }
}

/**
 * Get module configuration from HostBill
 */
function getModuleConfiguration($moduleName) {
    $settings = select_query('tbladdonmodules', '*', ['module' => $moduleName]);
    
    if (!$settings) {
        return null;
    }
    
    $config = [];
    foreach ($settings as $setting) {
        $config[$setting['setting']] = $setting['value'];
    }
    
    // Check if module is enabled
    if (($config['enabled'] ?? 'off') != 'on') {
        return null;
    }
    
    return $config;
}

/**
 * Manual sync functions for admin interface
 */

/**
 * Manually sync specific invoice
 */
function pohoda_manual_sync_invoice($invoiceId) {
    $moduleConfig = getModuleConfiguration('pohoda');
    
    if (!$moduleConfig) {
        return ['success' => false, 'error' => 'Pohoda module not configured'];
    }
    
    try {
        require_once __DIR__ . '/pohoda-client.php';
        $client = new PohodaClient($moduleConfig);
        
        $result = $client->syncInvoice($invoiceId);
        
        // Log the manual sync
        insert_query('mod_pohoda_sync_log', [
            'invoice_id' => $invoiceId,
            'action' => 'manual_sync',
            'status' => $result['success'] ? 'success' : 'error',
            'pohoda_invoice_id' => $result['pohoda_invoice_id'] ?? null,
            'error_message' => $result['error'] ?? null,
            'xml_request' => $result['xml_request'] ?? null,
            'xml_response' => $result['xml_response'] ?? null
        ]);
        
        return $result;
        
    } catch (Exception $e) {
        insert_query('mod_pohoda_sync_log', [
            'invoice_id' => $invoiceId,
            'action' => 'manual_sync',
            'status' => 'error',
            'error_message' => $e->getMessage()
        ]);
        
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Bulk sync all unpaid invoices
 */
function pohoda_bulk_sync_invoices($limit = 50) {
    $moduleConfig = getModuleConfiguration('pohoda');
    
    if (!$moduleConfig) {
        return ['success' => false, 'error' => 'Pohoda module not configured'];
    }
    
    try {
        // Get unpaid invoices
        $invoices = select_query('tblinvoices', 'id', [
            'status' => 'Unpaid'
        ], 'id', 'DESC', '', $limit);
        
        $results = [];
        $successCount = 0;
        $errorCount = 0;
        
        foreach ($invoices as $invoice) {
            $result = pohoda_manual_sync_invoice($invoice['id']);
            $results[] = $result;
            
            if ($result['success']) {
                $successCount++;
            } else {
                $errorCount++;
            }
        }
        
        logActivity("Pohoda: Bulk sync completed - {$successCount} successful, {$errorCount} failed");
        
        return [
            'success' => true,
            'message' => "Bulk sync completed: {$successCount} successful, {$errorCount} failed",
            'results' => $results,
            'stats' => [
                'total' => count($invoices),
                'successful' => $successCount,
                'failed' => $errorCount
            ]
        ];
        
    } catch (Exception $e) {
        logActivity("Pohoda: Bulk sync failed: " . $e->getMessage());
        
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

?>
