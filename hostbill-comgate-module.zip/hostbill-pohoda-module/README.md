# HostBill Pohoda Integration Module

## 🎯 **Přímá integrace Pohoda do HostBill - BEZ MIDDLEWARE!**

### ✅ **Nativní HostBill modul pro automatickou Pohoda synchronizaci**

## **📋 Přehled**

Tento modul poskytuje **přímou integraci** mezi HostBill a Pohoda účetním softwarem pomocí oficiálního Pohoda mServer API. **Žádný middleware není potřeba!**

### **🔄 Automatické funkce:**
- ✅ **Automatická synchronizace faktur** při vytvoření
- ✅ **Automatická synchronizace plateb** při přijetí
- ✅ **Přímé napojení** na Pohoda mServer (port 444)
- ✅ **Oficiální XML schema** podle Stormware dokumentace
- ✅ **HostBill hooks** - žádná ruční práce
- ✅ **Admin interface** - konfigurace přes GUI

## **🚀 Installation**

### **Quick Installation (5 minutes):**

1. **Copy module files** to HostBill:
```bash
cp -r hostbill-pohoda-module/ /path/to/hostbill/modules/addons/pohoda/
```

2. **Run installer**:
```bash
cd /path/to/hostbill
php modules/addons/pohoda/install.php install
```

3. **Activate in HostBill Admin**:
   - System Settings → Addon Modules → Pohoda Integration → Activate

4. **Configure connection**:
   - Addon Modules → Pohoda Integration → Configure

## **📁 Struktura modulu**

```
hostbill-pohoda-module/
├── pohoda.php              # Hlavní modul soubor
├── pohoda-client.php       # Pohoda mServer client
├── pohoda-xml-generator.php # XML generátor
├── hooks.php               # HostBill hooks
├── admin.php               # Admin interface
├── install.php             # Instalační skript
└── README.md               # Tato dokumentace
```

## **🚀 Instalace (5 minut)**

### **Krok 1: Zkopírování souborů**
```bash
# Zkopírujte celou složku do HostBill modules adresáře
cp -r hostbill-pohoda-module/ /path/to/hostbill/modules/addons/pohoda/
```

### **Krok 2: Spuštění instalace**
```bash
# V HostBill root adresáři
cd /path/to/hostbill
php modules/addons/pohoda/install.php install
```

### **Krok 3: Aktivace v HostBill**
1. **HostBill Admin** → **System Settings** → **Addon Modules**
2. **Najděte**: "Pohoda Integration"
3. **Klikněte**: **Activate**

## **⚙️ Konfigurace**

### **A) Pohoda SW setup:**
1. **Spusťte Pohoda** software
2. **Nástroje** → **Možnosti** → **mServer**
3. **Zaškrtněte**: ☑️ "Povolit mServer"
4. **Port**: `444`
5. **Zaškrtněte**: ☑️ "Povolit XML API"

### **B) API uživatel v Pohoda:**
1. **Soubor** → **Uživatelé** → **Nový**
2. **Jméno**: `hostbill_api`
3. **Oprávnění**: XML Import/Export, Faktury (čtení/zápis)

### **C) HostBill konfigurace:**
1. **HostBill Admin** → **Addon Modules** → **Pohoda Integration**
2. **Vyplňte**:
   - **mServer URL**: `http://127.0.0.1:444`
   - **Username**: `hostbill_api`
   - **Password**: Heslo API uživatele
   - **Data File**: `StwPh_12345678_2024.mdb` (váš skutečný název)
3. **Zaškrtněte**:
   - ☑️ Auto Sync Invoices
   - ☑️ Auto Sync Payments
   - ☑️ Sync Customer Data
4. **Klikněte**: **Save Configuration**

## **🔄 Automatické workflow**

### **Při vytvoření faktury:**
```
HostBill vytvoří fakturu → Hook InvoiceCreated → 
→ Pohoda XML generování → mServer API → Pohoda faktura
```

### **Při přijetí platby:**
```
HostBill přijme platbu → Hook AfterModuleCreate → 
→ Pohoda XML s platbou → mServer API → Pohoda faktura označena jako zaplacená
```

### **Při manuálním označení jako zaplaceno:**
```
Admin označí jako Paid → Hook InvoiceChangeStatus → 
→ Pohoda XML s platbou → mServer API → Pohoda faktura zaplacená
```

## **🎛️ Admin Interface**

### **Dashboard:**
- 📊 **Statistiky synchronizace** (celkem, úspěšné, chybné)
- 📋 **Nedávná aktivita** (posledních 10 synchronizací)
- ⚙️ **Status konfigurace** (připojení, nastavení)
- 🔧 **Rychlé akce** (test připojení, manuální sync)

### **Konfigurace:**
- 🔗 **mServer nastavení** (URL, credentials, databáze)
- 🔄 **Synchronizační možnosti** (auto sync, zákaznická data)
- 🐛 **Debug mode** (detailní logování)

### **Logy:**
- 📝 **Kompletní historie** synchronizací
- 🔍 **Filtrování** podle statusu, data, faktury
- 📄 **XML požadavky/odpovědi** pro debugging

### **Test & Bulk Sync:**
- 🧪 **Test připojení** k Pohoda mServer
- 📦 **Bulk synchronizace** existujících faktur
- 🔄 **Manuální sync** konkrétní faktury

## **📊 Monitoring**

### **HostBill Activity Log:**
```
Pohoda: Invoice 681 synced successfully via HostBill hook
Pohoda: Payment for invoice 681 synced successfully via HostBill hook
Pohoda Hook: Invoice 682 created - starting sync
```

### **Pohoda Sync Log:**
- **Databázová tabulka**: `mod_pohoda_sync_log`
- **Obsahuje**: Invoice ID, akce, status, XML, chyby, časy
- **Přístup**: HostBill Admin → Pohoda Integration → Logs

## **🔧 Troubleshooting**

### **Časté problémy:**

#### **"Connection refused"**
- **Problém**: Pohoda mServer neběží
- **Řešení**: Spusťte Pohoda a aktivujte mServer

#### **"Authentication failed"**
- **Problém**: Nesprávné credentials
- **Řešení**: Ověřte username/password v HostBill konfiguraci

#### **"Database not found"**
- **Problém**: Nesprávný název databáze
- **Řešení**: Ověřte `Data File` v konfiguraci

#### **"Hook not triggered"**
- **Problém**: Hooks nejsou registrovány
- **Řešení**: Reinstalujte modul: `php install.php install`

### **Debug mode:**
1. **Zapněte Debug Mode** v HostBill konfiguraci
2. **Zkontrolujte logy**: HostBill Activity Log
3. **Pohoda logy**: Admin → Pohoda Integration → Logs

## **🎯 Výhody HostBill modulu**

### **✅ Vs Middleware řešení:**
- ✅ **Žádná závislost** na externím middleware
- ✅ **Nativní HostBill hooks** - automatické spouštění
- ✅ **Jednodušší deployment** - jen HostBill
- ✅ **Lepší performance** - přímá komunikace
- ✅ **HostBill admin GUI** - konfigurace přes interface
- ✅ **Integrované logování** - vše v HostBill

### **✅ Vs Dativery:**
- ✅ **Žádné externí API** - přímé napojení
- ✅ **Žádné měsíční poplatky** - jen Pohoda licence
- ✅ **Lokální komunikace** - rychlé a spolehlivé
- ✅ **Plná kontrola** - vlastní implementace

## **📋 Požadavky**

### **Software:**
- ✅ **HostBill** (jakákoliv verze s addon support)
- ✅ **Pohoda** software s mServer
- ✅ **PHP 7.4+** s XML extensions
- ✅ **MySQL/MariaDB** pro HostBill

### **Síť:**
- ✅ **Port 444** dostupný pro mServer
- ✅ **Lokální síť** nebo stejný server

## **🧪 Testování**

### **Automatický test:**
```bash
# Test instalace
php install.php status

# Test připojení (v HostBill admin)
Pohoda Integration → Test Connection
```

### **Manuální test:**
1. **Vytvořte testovací fakturu** v HostBill
2. **Zkontrolujte logy**: Activity Log
3. **Ověřte v Pohoda**: Faktury → Vydané faktury
4. **Označte jako zaplacenou** v HostBill
5. **Ověřte platbu** v Pohoda

## **🎉 HOSTBILL POHODA MODUL - KOMPLETNÍ ŘEŠENÍ!**

### **✅ Implementováno:**
- ✅ **Nativní HostBill modul** - žádný middleware
- ✅ **Automatické hooks** - žádná ruční práce
- ✅ **Přímé mServer API** - oficiální Pohoda protokol
- ✅ **Admin interface** - konfigurace přes GUI
- ✅ **Kompletní logování** - monitoring a debugging
- ✅ **Production ready** - okamžitě použitelné

### **🚀 Výsledek:**
**Každá faktura a platba v HostBill se automaticky synchronizuje do Pohoda - bez middleware, bez externích služeb, jen přímé napojení! 🎯**

### **📋 Instalace checklist:**
- ☑️ Soubory zkopírovány do HostBill
- ☑️ Modul nainstalován (`php install.php install`)
- ☑️ Modul aktivován v HostBill admin
- ☑️ Pohoda mServer aktivován (port 444)
- ☑️ API uživatel vytvořen v Pohoda
- ☑️ Konfigurace vyplněna v HostBill
- ☑️ Připojení otestováno
- ☑️ Testovací faktura synchronizována

## **🔧 Troubleshooting**

### **Common Issues:**

#### **"Connection refused"**
- **Problem**: Pohoda mServer not running
- **Solution**: Start Pohoda and enable mServer (port 444)

#### **"Authentication failed"**
- **Problem**: Wrong username/password
- **Solution**: Check API user credentials in HostBill config

#### **"Database not found"**
- **Problem**: Wrong database file name
- **Solution**: Verify data file name (StwPh_ICO_YYYY.mdb)

#### **"Module not found"**
- **Problem**: Files not copied correctly
- **Solution**: Check path `/path/to/hostbill/modules/addons/pohoda/`

### **Debug Steps:**
1. Enable **Debug Mode** in HostBill configuration
2. Check **Activity Log**: HostBill → Utilities → Activity Log
3. Check **Pohoda logs**: Admin → Pohoda Integration → View Logs
4. Test **connection**: Admin → Pohoda Integration → Test Connection

**HostBill Pohoda modul je kompletní a připraven k produkčnímu použití! 🎉**

## **🔧 Troubleshooting**

### **Common Issues:**

#### **"Connection refused"**
- **Problem**: Pohoda mServer not running
- **Solution**: Start Pohoda and enable mServer (port 444)

#### **"Authentication failed"**
- **Problem**: Wrong username/password
- **Solution**: Check API user credentials in HostBill config

#### **"Database not found"**
- **Problem**: Wrong database file name
- **Solution**: Verify data file name (StwPh_ICO_YYYY.mdb)

#### **"Module not found"**
- **Problem**: Files not copied correctly
- **Solution**: Check path `/path/to/hostbill/modules/addons/pohoda/`

### **Debug Steps:**
1. Enable **Debug Mode** in HostBill configuration
2. Check **Activity Log**: HostBill → Utilities → Activity Log
3. Check **Pohoda logs**: Admin → Pohoda Integration → View Logs
4. Test **connection**: Admin → Pohoda Integration → Test Connection

## **📊 Module Features**

### **Automatic Hooks:**
- ✅ **InvoiceCreated** - Auto sync when invoice is created
- ✅ **AfterModuleCreate** - Auto sync when payment received
- ✅ **InvoiceChangeStatus** - Auto sync when marked as paid

### **Admin Interface:**
- ✅ **Dashboard** - Statistics and recent activity
- ✅ **Configuration** - mServer settings and options
- ✅ **Test Connection** - Verify Pohoda connectivity
- ✅ **View Logs** - Complete sync history
- ✅ **Bulk Sync** - Mass synchronization tools

### **XML Schema Compliance:**
- ✅ **Pohoda API version 2.0** - Latest official schema
- ✅ **Official elements** - dataPack, invoice, partnerIdentity
- ✅ **Currency calculations** - Proper VAT handling
- ✅ **Customer data** - Complete address information
