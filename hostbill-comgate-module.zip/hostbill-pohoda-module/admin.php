<?php
/**
 * HostBill Pohoda Integration Admin Interface
 * Advanced configuration and management interface
 * 
 * @package HostBill
 * @subpackage Pohoda
 * @author CloudVPS Team
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Admin page handler
 */
function pohoda_admin_page() {
    global $smarty;
    
    $action = $_GET['action'] ?? 'dashboard';
    $moduleConfig = getModuleConfiguration('pohoda');
    
    switch ($action) {
        case 'dashboard':
            return pohoda_admin_dashboard($moduleConfig);
            
        case 'configuration':
            return pohoda_admin_configuration($moduleConfig);
            
        case 'logs':
            return pohoda_admin_logs();
            
        case 'test':
            return pohoda_admin_test($moduleConfig);
            
        case 'bulk_sync':
            return pohoda_admin_bulk_sync($moduleConfig);
            
        default:
            return pohoda_admin_dashboard($moduleConfig);
    }
}

/**
 * Admin dashboard
 */
function pohoda_admin_dashboard($moduleConfig) {
    $stats = pohoda_get_statistics();
    $recentLogs = select_query('mod_pohoda_sync_log', '*', [], 'created_at', 'DESC', '', 10);
    
    $html = '
    <div class="pohoda-admin-dashboard">
        <div class="row">
            <div class="col-md-12">
                <h1>Pohoda Integration Dashboard</h1>
                <p class="lead">Automatic synchronization with Pohoda accounting software</p>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-3">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title">Total Synced</h3>
                    </div>
                    <div class="panel-body text-center">
                        <h2>' . $stats['total_synced'] . '</h2>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <h3 class="panel-title">Successful</h3>
                    </div>
                    <div class="panel-body text-center">
                        <h2>' . $stats['successful'] . '</h2>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="panel panel-danger">
                    <div class="panel-heading">
                        <h3 class="panel-title">Failed</h3>
                    </div>
                    <div class="panel-body text-center">
                        <h2>' . $stats['failed'] . '</h2>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title">Success Rate</h3>
                    </div>
                    <div class="panel-body text-center">
                        <h2>' . ($stats['total_synced'] > 0 ? round(($stats['successful'] / $stats['total_synced']) * 100, 1) : 0) . '%</h2>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Configuration Status</h3>
                    </div>
                    <div class="panel-body">
                        <table class="table table-condensed">
                            <tr>
                                <td><strong>Module Status:</strong></td>
                                <td><span class="label label-' . ($moduleConfig ? 'success' : 'danger') . '">' . ($moduleConfig ? 'ENABLED' : 'DISABLED') . '</span></td>
                            </tr>
                            <tr>
                                <td><strong>mServer URL:</strong></td>
                                <td>' . htmlspecialchars($moduleConfig['mserver_url'] ?? 'Not configured') . '</td>
                            </tr>
                            <tr>
                                <td><strong>Data File:</strong></td>
                                <td>' . htmlspecialchars($moduleConfig['data_file'] ?? 'Not configured') . '</td>
                            </tr>
                            <tr>
                                <td><strong>Auto Sync Invoices:</strong></td>
                                <td><span class="label label-' . (($moduleConfig['auto_sync_invoices'] ?? 'off') == 'on' ? 'success' : 'warning') . '">' . strtoupper($moduleConfig['auto_sync_invoices'] ?? 'OFF') . '</span></td>
                            </tr>
                            <tr>
                                <td><strong>Auto Sync Payments:</strong></td>
                                <td><span class="label label-' . (($moduleConfig['auto_sync_payments'] ?? 'off') == 'on' ? 'success' : 'warning') . '">' . strtoupper($moduleConfig['auto_sync_payments'] ?? 'OFF') . '</span></td>
                            </tr>
                            <tr>
                                <td><strong>Last Sync:</strong></td>
                                <td>' . ($stats['last_sync'] ?: 'Never') . '</td>
                            </tr>
                        </table>
                        
                        <div class="btn-group">
                            <a href="?action=configuration" class="btn btn-primary">Configure</a>
                            <a href="?action=test" class="btn btn-info">Test Connection</a>
                            <a href="?action=bulk_sync" class="btn btn-warning">Bulk Sync</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Recent Activity</h3>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-condensed">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Invoice</th>
                                        <th>Action</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>';
    
    foreach ($recentLogs as $log) {
        $statusClass = $log['status'] == 'success' ? 'success' : ($log['status'] == 'error' ? 'danger' : 'warning');
        $html .= '<tr>
            <td>' . date('H:i', strtotime($log['created_at'])) . '</td>
            <td>' . $log['invoice_id'] . '</td>
            <td>' . $log['action'] . '</td>
            <td><span class="label label-' . $statusClass . '">' . strtoupper($log['status']) . '</span></td>
        </tr>';
    }
    
    $html .= '
                                </tbody>
                            </table>
                        </div>
                        <a href="?action=logs" class="btn btn-default btn-sm">View All Logs</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Quick Actions</h3>
                    </div>
                    <div class="panel-body">
                        <form method="post" class="form-inline" style="margin-bottom: 15px;">
                            <div class="form-group">
                                <label for="invoice_id">Manual Sync Invoice:</label>
                                <input type="number" name="invoice_id" class="form-control" placeholder="Invoice ID" required>
                            </div>
                            <button type="submit" name="action" value="sync_invoice" class="btn btn-success">Sync Now</button>
                        </form>
                        
                        <div class="btn-group">
                            <button type="button" class="btn btn-info" onclick="testConnection()">Test Connection</button>
                            <button type="button" class="btn btn-warning" onclick="syncRecentInvoices()">Sync Recent Invoices</button>
                            <button type="button" class="btn btn-default" onclick="refreshStats()">Refresh Stats</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function testConnection() {
        $.post("?ajax=pohoda", {action: "test_connection"}, function(data) {
            if (data.success) {
                alert("✅ Connection successful!");
            } else {
                alert("❌ Connection failed: " + data.error);
            }
        }, "json");
    }
    
    function syncRecentInvoices() {
        if (confirm("Sync last 10 unpaid invoices to Pohoda?")) {
            $.post("?ajax=pohoda", {action: "bulk_sync", limit: 10}, function(data) {
                if (data.success) {
                    alert("✅ Bulk sync completed: " + data.message);
                    location.reload();
                } else {
                    alert("❌ Bulk sync failed: " + data.error);
                }
            }, "json");
        }
    }
    
    function refreshStats() {
        location.reload();
    }
    </script>
    
    <style>
    .pohoda-admin-dashboard .panel { margin-bottom: 20px; }
    .pohoda-admin-dashboard .form-inline .form-group { margin-right: 10px; }
    .pohoda-admin-dashboard h2 { margin: 0; font-size: 36px; }
    </style>
    ';
    
    return $html;
}

/**
 * Configuration page
 */
function pohoda_admin_configuration($moduleConfig) {
    // Handle form submission
    if ($_POST['save_config']) {
        $newConfig = [
            'mserver_url' => $_POST['mserver_url'],
            'mserver_username' => $_POST['mserver_username'],
            'mserver_password' => $_POST['mserver_password'],
            'data_file' => $_POST['data_file'],
            'auto_sync_invoices' => $_POST['auto_sync_invoices'] ?? 'off',
            'auto_sync_payments' => $_POST['auto_sync_payments'] ?? 'off',
            'sync_customer_data' => $_POST['sync_customer_data'] ?? 'off',
            'debug_mode' => $_POST['debug_mode'] ?? 'off'
        ];
        
        // Save configuration
        foreach ($newConfig as $key => $value) {
            update_query('tbladdonmodules', ['value' => $value], [
                'module' => 'pohoda',
                'setting' => $key
            ]);
        }
        
        logActivity('Pohoda: Configuration updated');
        $moduleConfig = $newConfig;
        
        $successMessage = '<div class="alert alert-success">✅ Configuration saved successfully!</div>';
    }
    
    $html = '
    <div class="pohoda-admin-config">
        <h1>Pohoda Integration Configuration</h1>
        
        ' . ($successMessage ?? '') . '
        
        <form method="post">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">mServer Connection</h3>
                </div>
                <div class="panel-body">
                    <div class="form-group">
                        <label for="mserver_url">mServer URL:</label>
                        <input type="text" name="mserver_url" class="form-control" 
                               value="' . htmlspecialchars($moduleConfig['mserver_url'] ?? 'http://127.0.0.1:444') . '"
                               placeholder="http://127.0.0.1:444">
                        <small class="help-block">Pohoda mServer URL (default port 444)</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="mserver_username">Username:</label>
                        <input type="text" name="mserver_username" class="form-control" 
                               value="' . htmlspecialchars($moduleConfig['mserver_username'] ?? '') . '"
                               placeholder="pohoda_api_user">
                        <small class="help-block">Pohoda API username</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="mserver_password">Password:</label>
                        <input type="password" name="mserver_password" class="form-control" 
                               value="' . htmlspecialchars($moduleConfig['mserver_password'] ?? '') . '"
                               placeholder="API user password">
                        <small class="help-block">Pohoda API password</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="data_file">Data File:</label>
                        <input type="text" name="data_file" class="form-control" 
                               value="' . htmlspecialchars($moduleConfig['data_file'] ?? '') . '"
                               placeholder="StwPh_12345678_2024.mdb">
                        <small class="help-block">Pohoda database file name (format: StwPh_ICO_YYYY.mdb)</small>
                    </div>
                </div>
            </div>
            
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Synchronization Settings</h3>
                </div>
                <div class="panel-body">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="auto_sync_invoices" value="on" 
                                   ' . (($moduleConfig['auto_sync_invoices'] ?? 'off') == 'on' ? 'checked' : '') . '>
                            Auto Sync Invoices
                        </label>
                        <small class="help-block">Automatically sync invoices when created</small>
                    </div>
                    
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="auto_sync_payments" value="on" 
                                   ' . (($moduleConfig['auto_sync_payments'] ?? 'off') == 'on' ? 'checked' : '') . '>
                            Auto Sync Payments
                        </label>
                        <small class="help-block">Automatically sync payments when received</small>
                    </div>
                    
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="sync_customer_data" value="on" 
                                   ' . (($moduleConfig['sync_customer_data'] ?? 'off') == 'on' ? 'checked' : '') . '>
                            Sync Customer Data
                        </label>
                        <small class="help-block">Include customer details in Pohoda invoices</small>
                    </div>
                    
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="debug_mode" value="on" 
                                   ' . (($moduleConfig['debug_mode'] ?? 'off') == 'on' ? 'checked' : '') . '>
                            Debug Mode
                        </label>
                        <small class="help-block">Enable detailed logging for troubleshooting</small>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <button type="submit" name="save_config" class="btn btn-primary btn-lg">Save Configuration</button>
                <a href="?action=test" class="btn btn-info">Test Connection</a>
                <a href="?action=dashboard" class="btn btn-default">Back to Dashboard</a>
            </div>
        </form>
    </div>
    ';
    
    return $html;
}

/**
 * Test connection page
 */
function pohoda_admin_test($moduleConfig) {
    $testResult = null;
    
    if ($_POST['test_connection']) {
        try {
            require_once __DIR__ . '/pohoda-client.php';
            $client = new PohodaClient($moduleConfig);
            $testResult = $client->testConnection();
        } catch (Exception $e) {
            $testResult = ['success' => false, 'error' => $e->getMessage()];
        }
    }
    
    $html = '
    <div class="pohoda-admin-test">
        <h1>Pohoda Connection Test</h1>
        
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title">Current Configuration</h3>
            </div>
            <div class="panel-body">
                <table class="table table-condensed">
                    <tr>
                        <td><strong>mServer URL:</strong></td>
                        <td>' . htmlspecialchars($moduleConfig['mserver_url'] ?? 'Not configured') . '</td>
                    </tr>
                    <tr>
                        <td><strong>Username:</strong></td>
                        <td>' . htmlspecialchars($moduleConfig['mserver_username'] ?? 'Not configured') . '</td>
                    </tr>
                    <tr>
                        <td><strong>Data File:</strong></td>
                        <td>' . htmlspecialchars($moduleConfig['data_file'] ?? 'Not configured') . '</td>
                    </tr>
                    <tr>
                        <td><strong>Has Password:</strong></td>
                        <td>' . (!empty($moduleConfig['mserver_password']) ? 'YES' : 'NO') . '</td>
                    </tr>
                </table>
            </div>
        </div>';
    
    if ($testResult) {
        $alertClass = $testResult['success'] ? 'alert-success' : 'alert-danger';
        $icon = $testResult['success'] ? '✅' : '❌';
        
        $html .= '
        <div class="alert ' . $alertClass . '">
            <h4>' . $icon . ' Connection Test Result</h4>
            <p><strong>Status:</strong> ' . ($testResult['success'] ? 'SUCCESS' : 'FAILED') . '</p>';
        
        if ($testResult['success']) {
            $html .= '<p><strong>Message:</strong> ' . htmlspecialchars($testResult['message']) . '</p>';
        } else {
            $html .= '<p><strong>Error:</strong> ' . htmlspecialchars($testResult['error']) . '</p>';
        }
        
        $html .= '</div>';
    }
    
    $html .= '
        <form method="post">
            <button type="submit" name="test_connection" class="btn btn-primary btn-lg">Test Connection Now</button>
            <a href="?action=dashboard" class="btn btn-default">Back to Dashboard</a>
        </form>
        
        <div class="panel panel-info" style="margin-top: 20px;">
            <div class="panel-heading">
                <h3 class="panel-title">Setup Requirements</h3>
            </div>
            <div class="panel-body">
                <h4>For successful connection you need:</h4>
                <ul>
                    <li>✅ <strong>Pohoda software running</strong> with mServer enabled</li>
                    <li>✅ <strong>mServer port 444</strong> accessible (default)</li>
                    <li>✅ <strong>XML API enabled</strong> in Pohoda mServer settings</li>
                    <li>✅ <strong>API user created</strong> in Pohoda with XML permissions</li>
                    <li>✅ <strong>Correct database file name</strong> (StwPh_ICO_YYYY.mdb)</li>
                </ul>
                
                <h4>Common issues:</h4>
                <ul>
                    <li>❌ <strong>"Connection refused"</strong> → Pohoda not running or mServer disabled</li>
                    <li>❌ <strong>"Authentication failed"</strong> → Wrong username/password</li>
                    <li>❌ <strong>"Database not found"</strong> → Wrong data file name</li>
                </ul>
            </div>
        </div>
    </div>
    ';
    
    return $html;
}

/**
 * Bulk sync page
 */
function pohoda_admin_bulk_sync($moduleConfig) {
    $syncResult = null;
    
    if ($_POST['bulk_sync']) {
        $limit = intval($_POST['limit'] ?? 50);
        $syncResult = pohoda_bulk_sync_invoices($limit);
    }
    
    $html = '
    <div class="pohoda-admin-bulk">
        <h1>Pohoda Bulk Synchronization</h1>
        
        <div class="alert alert-warning">
            <strong>Warning:</strong> Bulk sync will process multiple invoices at once. 
            Make sure Pohoda is running and properly configured before proceeding.
        </div>';
    
    if ($syncResult) {
        $alertClass = $syncResult['success'] ? 'alert-success' : 'alert-danger';
        $icon = $syncResult['success'] ? '✅' : '❌';
        
        $html .= '
        <div class="alert ' . $alertClass . '">
            <h4>' . $icon . ' Bulk Sync Result</h4>
            <p>' . htmlspecialchars($syncResult['message']) . '</p>';
        
        if ($syncResult['success'] && isset($syncResult['stats'])) {
            $stats = $syncResult['stats'];
            $html .= '
            <ul>
                <li><strong>Total Processed:</strong> ' . $stats['total'] . '</li>
                <li><strong>Successful:</strong> ' . $stats['successful'] . '</li>
                <li><strong>Failed:</strong> ' . $stats['failed'] . '</li>
            </ul>';
        }
        
        $html .= '</div>';
    }
    
    $html .= '
        <form method="post">
            <div class="form-group">
                <label for="limit">Number of invoices to sync:</label>
                <select name="limit" class="form-control" style="width: 200px;">
                    <option value="10">10 invoices</option>
                    <option value="25">25 invoices</option>
                    <option value="50" selected>50 invoices</option>
                    <option value="100">100 invoices</option>
                </select>
                <small class="help-block">Will sync the most recent unpaid invoices</small>
            </div>
            
            <button type="submit" name="bulk_sync" class="btn btn-warning btn-lg" 
                    onclick="return confirm(\'Are you sure you want to sync multiple invoices to Pohoda?\')">
                Start Bulk Sync
            </button>
            <a href="?action=dashboard" class="btn btn-default">Back to Dashboard</a>
        </form>
    </div>
    ';
    
    return $html;
}

?>
