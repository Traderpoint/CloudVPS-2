<?php
/**
 * Pohoda XML Generator for HostBill
 * Generates XML according to official Pohoda schema
 * 
 * @package HostBill
 * @subpackage Pohoda
 * @author CloudVPS Team
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

class PohodaXMLGenerator {
    
    /**
     * Generate invoice XML for Pohoda
     * Uses official Pohoda API version="2.0" schema
     */
    public function generateInvoiceXML($invoiceData, $paymentData = null) {
        try {
            $xml = new DOMDocument('1.0', 'UTF-8');
            $xml->formatOutput = true;
            
            // Root element with Pohoda API version="2.0"
            $dataPack = $xml->createElement('dataPack');
            $dataPack->setAttribute('version', '2.0'); // Pohoda API version="2.0" compliance
            $dataPack->setAttribute('application', 'HostBill Pohoda Module');
            $dataPack->setAttribute('note', 'HostBill automatic invoice sync');
            $xml->appendChild($dataPack);
            
            // Data pack item
            $dataPackItem = $xml->createElement('dataPackItem');
            $dataPackItem->setAttribute('version', '2.0');
            $dataPackItem->setAttribute('id', 'HOSTBILL-' . $invoiceData['id']);
            $dataPack->appendChild($dataPackItem);
            
            // Invoice element with Pohoda API version 2.0
            $invoice = $xml->createElement('invoice');
            $invoice->setAttribute('version', '2.0'); // Pohoda API version 2.0
            $dataPackItem->appendChild($invoice);
            
            // Invoice header
            $invoiceHeader = $this->generateInvoiceHeader($xml, $invoiceData, $paymentData);
            $invoice->appendChild($invoiceHeader);
            
            // Invoice detail (items)
            $invoiceDetail = $this->generateInvoiceDetail($xml, $invoiceData);
            $invoice->appendChild($invoiceDetail);
            
            // Invoice summary
            $invoiceSummary = $this->generateInvoiceSummary($xml, $invoiceData);
            $invoice->appendChild($invoiceSummary);
            
            return $xml->saveXML();
            
        } catch (Exception $e) {
            throw new Exception('Failed to generate Pohoda XML: ' . $e->getMessage());
        }
    }
    
    /**
     * Generate invoice header
     */
    private function generateInvoiceHeader($xml, $invoiceData, $paymentData = null) {
        $header = $xml->createElement('invoiceHeader');
        
        // Basic invoice info
        $header->appendChild($xml->createElement('invoiceType', 'issuedInvoice'));
        
        // Invoice number
        $number = $xml->createElement('number');
        $number->appendChild($xml->createElement('numberRequested', $invoiceData['id']));
        $header->appendChild($number);
        
        $header->appendChild($xml->createElement('symVar', $invoiceData['id']));
        $header->appendChild($xml->createElement('date', $this->formatDate($invoiceData['date'])));
        $header->appendChild($xml->createElement('dateTax', $this->formatDate($invoiceData['date'])));
        $header->appendChild($xml->createElement('dateAccounting', $this->formatDate($invoiceData['date'])));
        $header->appendChild($xml->createElement('dateDue', $this->formatDate($invoiceData['duedate'])));
        
        // Customer information
        $partnerIdentity = $this->generatePartnerIdentity($xml, $invoiceData);
        $header->appendChild($partnerIdentity);
        
        // Payment type
        $paymentType = $this->generatePaymentType($xml, $paymentData);
        $header->appendChild($paymentType);
        
        // Text and notes
        $text = "HostBill faktura {$invoiceData['id']}";
        if ($paymentData) {
            $text .= " - Platba: {$paymentData['transaction_id']}";
        }
        $header->appendChild($xml->createElement('text', $text));
        
        $note = $this->generateNote($invoiceData, $paymentData);
        $header->appendChild($xml->createElement('note', $note));
        
        $intNote = "HostBill automatická synchronizace - Invoice ID: {$invoiceData['id']}";
        if ($paymentData) {
            $intNote .= ", Transaction: {$paymentData['transaction_id']}";
        }
        $header->appendChild($xml->createElement('intNote', $intNote));
        
        // Mark as paid if payment data provided
        if ($paymentData) {
            $liquidation = $xml->createElement('liquidation');
            $liquidation->appendChild($xml->createElement('amountHome', $paymentData['amount']));
            $liquidation->appendChild($xml->createElement('dateLiquidation', $this->formatDate($paymentData['date'])));
            $header->appendChild($liquidation);
        }
        
        return $header;
    }
    
    /**
     * Generate partner identity (customer info)
     */
    private function generatePartnerIdentity($xml, $invoiceData) {
        $partnerIdentity = $xml->createElement('partnerIdentity');
        $address = $xml->createElement('address');
        
        // Customer name
        $customerName = $this->getCustomerName($invoiceData);
        $address->appendChild($xml->createElement('name', $customerName));
        
        if (!empty($invoiceData['companyname'])) {
            $address->appendChild($xml->createElement('company', $invoiceData['companyname']));
        }
        
        if (!empty($invoiceData['tax_id'])) {
            $address->appendChild($xml->createElement('ico', $invoiceData['tax_id']));
        }
        
        if (!empty($invoiceData['vat_id'])) {
            $address->appendChild($xml->createElement('dic', $invoiceData['vat_id']));
        }
        
        $address->appendChild($xml->createElement('street', $invoiceData['address1'] ?? ''));
        $address->appendChild($xml->createElement('city', $invoiceData['city'] ?? ''));
        $address->appendChild($xml->createElement('zip', $invoiceData['postcode'] ?? ''));
        $address->appendChild($xml->createElement('country', $this->getCountryCode($invoiceData['country'] ?? '')));
        $address->appendChild($xml->createElement('email', $invoiceData['email'] ?? ''));
        $address->appendChild($xml->createElement('phone', $invoiceData['phonenumber'] ?? ''));
        
        $partnerIdentity->appendChild($address);
        return $partnerIdentity;
    }
    
    /**
     * Generate payment type
     */
    private function generatePaymentType($xml, $paymentData = null) {
        $paymentType = $xml->createElement('paymentType');
        
        if ($paymentData) {
            $method = $this->mapPaymentMethod($paymentData['method']);
            $paymentType->appendChild($xml->createElement('paymentMethod', $method));
            $paymentType->appendChild($xml->createElement('ids', $paymentData['transaction_id']));
        } else {
            $paymentType->appendChild($xml->createElement('paymentMethod', 'příkazem'));
        }
        
        return $paymentType;
    }
    
    /**
     * Generate invoice detail (items)
     */
    private function generateInvoiceDetail($xml, $invoiceData) {
        $invoiceDetail = $xml->createElement('invoiceDetail');
        
        if (!empty($invoiceData['items']) && is_array($invoiceData['items'])) {
            foreach ($invoiceData['items'] as $item) {
                $invoiceItem = $this->generateInvoiceItem($xml, $item, $invoiceData['id']);
                $invoiceDetail->appendChild($invoiceItem);
            }
        } else {
            // Single item for total amount
            $invoiceItem = $this->generateSingleInvoiceItem($xml, $invoiceData);
            $invoiceDetail->appendChild($invoiceItem);
        }
        
        return $invoiceDetail;
    }
    
    /**
     * Generate single invoice item
     */
    private function generateInvoiceItem($xml, $item, $invoiceId) {
        $invoiceItem = $xml->createElement('invoiceItem');
        
        $invoiceItem->appendChild($xml->createElement('text', $item['description'] ?? "HostBill služba {$item['id']}"));
        $invoiceItem->appendChild($xml->createElement('quantity', $item['qty'] ?? 1));
        $invoiceItem->appendChild($xml->createElement('unit', 'ks'));
        $invoiceItem->appendChild($xml->createElement('payVAT', 'false'));
        $invoiceItem->appendChild($xml->createElement('rateVAT', 'high'));
        
        // Currency calculations
        $amount = floatval($item['amount'] ?? 0);
        $priceWithoutVAT = $amount / 1.21;
        $vatAmount = $amount - $priceWithoutVAT;
        $quantity = floatval($item['qty'] ?? 1);
        $unitPrice = $priceWithoutVAT / $quantity;
        
        $homeCurrency = $xml->createElement('homeCurrency');
        $homeCurrency->appendChild($xml->createElement('unitPrice', number_format($unitPrice, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('price', number_format($priceWithoutVAT, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('priceVAT', number_format($vatAmount, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('priceSum', number_format($amount, 2, '.', '')));
        $invoiceItem->appendChild($homeCurrency);
        
        $invoiceItem->appendChild($xml->createElement('code', 'HOSTBILL-' . $item['id']));
        
        // Stock item
        $stockItem = $xml->createElement('stockItem');
        $stockItemInner = $xml->createElement('stockItem');
        $stockItemInner->appendChild($xml->createElement('ids', 'HOSTBILL-' . $item['id']));
        $stockItemInner->appendChild($xml->createElement('name', $item['description'] ?? "HostBill služba {$item['id']}"));
        $stockItem->appendChild($stockItemInner);
        $invoiceItem->appendChild($stockItem);
        
        $invoiceItem->appendChild($xml->createElement('note', "HostBill item {$item['id']}"));
        
        return $invoiceItem;
    }
    
    /**
     * Generate single invoice item for total amount
     */
    private function generateSingleInvoiceItem($xml, $invoiceData) {
        $invoiceItem = $xml->createElement('invoiceItem');
        
        $totalAmount = floatval($invoiceData['total']);
        $priceWithoutVAT = $totalAmount / 1.21;
        $vatAmount = $totalAmount - $priceWithoutVAT;
        
        $invoiceItem->appendChild($xml->createElement('text', "HostBill služby - Faktura {$invoiceData['id']}"));
        $invoiceItem->appendChild($xml->createElement('quantity', '1'));
        $invoiceItem->appendChild($xml->createElement('unit', 'ks'));
        $invoiceItem->appendChild($xml->createElement('payVAT', 'false'));
        $invoiceItem->appendChild($xml->createElement('rateVAT', 'high'));
        
        $homeCurrency = $xml->createElement('homeCurrency');
        $homeCurrency->appendChild($xml->createElement('unitPrice', number_format($priceWithoutVAT, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('price', number_format($priceWithoutVAT, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('priceVAT', number_format($vatAmount, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('priceSum', number_format($totalAmount, 2, '.', '')));
        $invoiceItem->appendChild($homeCurrency);
        
        $invoiceItem->appendChild($xml->createElement('code', 'HOSTBILL-' . $invoiceData['id']));
        
        // Stock item
        $stockItem = $xml->createElement('stockItem');
        $stockItemInner = $xml->createElement('stockItem');
        $stockItemInner->appendChild($xml->createElement('ids', 'HOSTBILL-' . $invoiceData['id']));
        $stockItemInner->appendChild($xml->createElement('name', "HostBill služby - Faktura {$invoiceData['id']}"));
        $stockItem->appendChild($stockItemInner);
        $invoiceItem->appendChild($stockItem);
        
        $invoiceItem->appendChild($xml->createElement('note', "HostBill invoice {$invoiceData['id']}"));
        
        return $invoiceItem;
    }
    
    /**
     * Generate invoice summary
     */
    private function generateInvoiceSummary($xml, $invoiceData) {
        $summary = $xml->createElement('invoiceSummary');
        
        $summary->appendChild($xml->createElement('roundingDocument', 'none'));
        $summary->appendChild($xml->createElement('roundingVAT', 'none'));
        $summary->appendChild($xml->createElement('calculateVAT', 'false'));
        
        $totalAmount = floatval($invoiceData['total']);
        $priceWithoutVAT = $totalAmount / 1.21;
        $vatAmount = $totalAmount - $priceWithoutVAT;
        
        $homeCurrency = $xml->createElement('homeCurrency');
        $homeCurrency->appendChild($xml->createElement('priceNone', number_format($priceWithoutVAT, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('priceLow', '0'));
        $homeCurrency->appendChild($xml->createElement('priceHigh', number_format($vatAmount, 2, '.', '')));
        $homeCurrency->appendChild($xml->createElement('priceHighSum', number_format($totalAmount, 2, '.', '')));
        $summary->appendChild($homeCurrency);
        
        return $summary;
    }
    
    /**
     * Helper methods
     */
    private function getCustomerName($invoiceData) {
        if (!empty($invoiceData['companyname'])) {
            return $invoiceData['companyname'];
        }
        
        $name = trim(($invoiceData['firstname'] ?? '') . ' ' . ($invoiceData['lastname'] ?? ''));
        return $name ?: "Zákazník {$invoiceData['id']}";
    }
    
    private function mapPaymentMethod($method) {
        $mapping = [
            'comgate' => 'kartou',
            'payu' => 'kartou',
            'banktransfer' => 'příkazem',
            'creditcard' => 'kartou',
            'manual' => 'hotově',
            'paypal' => 'kartou',
            'stripe' => 'kartou'
        ];
        
        return $mapping[strtolower($method)] ?? 'příkazem';
    }
    
    private function getCountryCode($country) {
        if (empty($country)) return 'CZ';
        
        $mapping = [
            'Czech Republic' => 'CZ',
            'Slovakia' => 'SK',
            'Česká republika' => 'CZ',
            'Slovensko' => 'SK'
        ];
        
        return $mapping[$country] ?? strtoupper(substr($country, 0, 2));
    }
    
    private function formatDate($date) {
        if (empty($date)) {
            return date('Y-m-d');
        }
        
        if (is_numeric($date)) {
            return date('Y-m-d', $date);
        }
        
        return date('Y-m-d', strtotime($date));
    }
    
    private function generateNote($invoiceData, $paymentData) {
        $note = "HostBill faktura {$invoiceData['id']}";
        
        if ($paymentData) {
            $note .= "\nPlatba: {$paymentData['transaction_id']} přes {$paymentData['method']}";
            $note .= "\nČástka: {$paymentData['amount']} {$paymentData['currency']}";
        }
        
        if (!empty($invoiceData['notes'])) {
            $note .= "\nPoznámky: {$invoiceData['notes']}";
        }
        
        return $note;
    }
}

?>
