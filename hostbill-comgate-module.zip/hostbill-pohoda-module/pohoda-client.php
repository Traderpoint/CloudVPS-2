<?php
/**
 * Pohoda Client for HostBill
 * Direct communication with Pohoda mServer API
 * 
 * @package HostBill
 * @subpackage Pohoda
 * @author CloudVPS Team
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

class PohodaClient {
    
    private $mServerUrl;
    private $username;
    private $password;
    private $dataFile;
    private $debugMode;
    
    /**
     * Constructor
     */
    public function __construct($config) {
        $this->mServerUrl = $config['mserver_url'] ?? 'http://127.0.0.1:444';
        $this->username = $config['mserver_username'] ?? '';
        $this->password = $config['mserver_password'] ?? '';
        $this->dataFile = $config['data_file'] ?? '';
        $this->debugMode = ($config['debug_mode'] ?? 'off') == 'on';
        
        if ($this->debugMode) {
            logActivity('Pohoda Client initialized', [
                'mServerUrl' => $this->mServerUrl,
                'dataFile' => $this->dataFile,
                'username' => $this->username
            ]);
        }
    }
    
    /**
     * Test connection to Pohoda mServer
     */
    public function testConnection() {
        try {
            $testXml = $this->generateTestXML();
            $result = $this->sendToMServer($testXml);
            
            return [
                'success' => true,
                'message' => 'Connection to Pohoda mServer successful',
                'mServerUrl' => $this->mServerUrl,
                'dataFile' => $this->dataFile
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'mServerUrl' => $this->mServerUrl
            ];
        }
    }
    
    /**
     * Sync invoice to Pohoda
     */
    public function syncInvoice($invoiceId) {
        try {
            // Get invoice data from HostBill
            $invoiceData = $this->getInvoiceData($invoiceId);
            
            if (!$invoiceData) {
                throw new Exception("Invoice {$invoiceId} not found");
            }
            
            // Generate Pohoda XML
            $xml = $this->generateInvoiceXML($invoiceData);
            
            // Send to Pohoda mServer
            $response = $this->sendToMServer($xml);
            
            if ($this->debugMode) {
                logActivity("Pohoda: Invoice {$invoiceId} sync successful", [
                    'pohodaInvoiceId' => $invoiceId,
                    'customer' => $invoiceData['firstname'] . ' ' . $invoiceData['lastname'],
                    'total' => $invoiceData['total']
                ]);
            }
            
            return [
                'success' => true,
                'pohoda_invoice_id' => $invoiceId,
                'message' => 'Invoice synced successfully',
                'xml_request' => $xml,
                'xml_response' => $response
            ];
            
        } catch (Exception $e) {
            if ($this->debugMode) {
                logActivity("Pohoda: Invoice {$invoiceId} sync failed: " . $e->getMessage());
            }
            
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'invoice_id' => $invoiceId
            ];
        }
    }
    
    /**
     * Sync invoice with payment information
     */
    public function syncInvoiceWithPayment($invoiceId, $paymentVars) {
        try {
            // Get invoice data from HostBill
            $invoiceData = $this->getInvoiceData($invoiceId);
            
            if (!$invoiceData) {
                throw new Exception("Invoice {$invoiceId} not found");
            }
            
            // Prepare payment data
            $paymentData = [
                'transaction_id' => $paymentVars['transid'] ?? 'HB-' . time(),
                'method' => $paymentVars['gateway'] ?? 'manual',
                'amount' => $paymentVars['amount'] ?? $invoiceData['total'],
                'currency' => $paymentVars['currency'] ?? 'CZK',
                'date' => date('Y-m-d'),
                'notes' => "HostBill payment: " . ($paymentVars['transid'] ?? 'Manual')
            ];
            
            // Generate Pohoda XML with payment
            $xml = $this->generateInvoiceXML($invoiceData, $paymentData);
            
            // Send to Pohoda mServer
            $response = $this->sendToMServer($xml);
            
            if ($this->debugMode) {
                logActivity("Pohoda: Invoice {$invoiceId} with payment sync successful", [
                    'transactionId' => $paymentData['transaction_id'],
                    'amount' => $paymentData['amount'],
                    'method' => $paymentData['method']
                ]);
            }
            
            return [
                'success' => true,
                'pohoda_invoice_id' => $invoiceId,
                'transaction_id' => $paymentData['transaction_id'],
                'message' => 'Invoice with payment synced successfully',
                'xml_request' => $xml,
                'xml_response' => $response
            ];
            
        } catch (Exception $e) {
            if ($this->debugMode) {
                logActivity("Pohoda: Invoice {$invoiceId} payment sync failed: " . $e->getMessage());
            }
            
            return [
                'success' => false,
                'error' => $e->getMessage(),
                'invoice_id' => $invoiceId
            ];
        }
    }
    
    /**
     * Get invoice data from HostBill database
     */
    private function getInvoiceData($invoiceId) {
        // Get invoice basic data
        $invoice = select_query('tblinvoices', '*', ['id' => $invoiceId]);
        
        if (!$invoice) {
            return null;
        }
        
        // Get customer data
        $client = select_query('tblclients', '*', ['id' => $invoice['userid']]);
        
        // Get invoice items
        $items = select_query('tblinvoiceitems', '*', ['invoiceid' => $invoiceId]);
        
        // Merge data
        $invoiceData = array_merge($invoice, $client, [
            'items' => $items
        ]);
        
        return $invoiceData;
    }
    
    /**
     * Generate Pohoda XML for invoice
     */
    private function generateInvoiceXML($invoiceData, $paymentData = null) {
        $xmlGenerator = new PohodaXMLGenerator();
        return $xmlGenerator->generateInvoiceXML($invoiceData, $paymentData);
    }
    
    /**
     * Generate test XML
     */
    private function generateTestXML() {
        return '<?xml version="1.0" encoding="UTF-8"?>
<dataPack version="2.0" application="HostBill Pohoda Module">
  <dataPackItem version="2.0" id="TEST">
    <invoice version="2.0">
      <invoiceHeader>
        <invoiceType>issuedInvoice</invoiceType>
        <text>HostBill connection test</text>
      </invoiceHeader>
    </invoice>
  </dataPackItem>
</dataPack>';
    }
    
    /**
     * Send XML to Pohoda mServer
     */
    private function sendToMServer($xml) {
        $url = $this->mServerUrl . '/xml';
        
        // Prepare HTTP request
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => [
                    'Content-Type: application/xml; charset=UTF-8',
                    'Authorization: Basic ' . base64_encode($this->username . ':' . $this->password),
                    'STW-Application: HostBill',
                    'STW-Instance: ' . $this->dataFile
                ],
                'content' => $xml,
                'timeout' => 30
            ]
        ]);
        
        if ($this->debugMode) {
            logActivity('Pohoda: Sending XML to mServer', [
                'url' => $url,
                'dataFile' => $this->dataFile,
                'xmlLength' => strlen($xml)
            ]);
        }
        
        // Send request
        $response = file_get_contents($url, false, $context);
        
        if ($response === false) {
            throw new Exception('Failed to connect to Pohoda mServer at ' . $url);
        }
        
        if ($this->debugMode) {
            logActivity('Pohoda: mServer response received', [
                'responseLength' => strlen($response)
            ]);
        }
        
        // Parse response
        $responseData = $this->parsePohodaResponse($response);
        
        if (!$responseData['success']) {
            throw new Exception('Pohoda mServer error: ' . $responseData['error']);
        }
        
        return $response;
    }
    
    /**
     * Parse Pohoda XML response
     */
    private function parsePohodaResponse($xmlResponse) {
        try {
            // Simple parsing - check for success indicators
            $success = strpos($xmlResponse, '<state>ok</state>') !== false ||
                      strpos($xmlResponse, 'success') !== false ||
                      strpos($xmlResponse, 'error') === false;
            
            return [
                'success' => $success,
                'raw_xml' => $xmlResponse,
                'error' => $success ? null : 'Unknown error in Pohoda response'
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => 'Failed to parse Pohoda response: ' . $e->getMessage(),
                'raw_xml' => $xmlResponse
            ];
        }
    }
}

// Include XML generator
require_once __DIR__ . '/pohoda-xml-generator.php';

?>
