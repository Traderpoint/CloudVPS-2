<?php
/**
 * HostBill Pohoda Integration Module Installer
 * Installation and setup script for Pohoda module
 * 
 * @package HostBill
 * @subpackage Pohoda
 * @author CloudVPS Team
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Install Pohoda module
 */
function install_pohoda_module() {
    try {
        echo "🚀 Installing HostBill Pohoda Integration Module...\n";
        
        // Step 1: Create database tables
        echo "1️⃣ Creating database tables...\n";
        create_pohoda_tables();
        echo "✅ Database tables created successfully\n";
        
        // Step 2: Register module in HostBill
        echo "2️⃣ Registering module in HostBill...\n";
        register_pohoda_module();
        echo "✅ Module registered successfully\n";
        
        // Step 3: Set default configuration
        echo "3️⃣ Setting default configuration...\n";
        set_default_pohoda_config();
        echo "✅ Default configuration set\n";
        
        // Step 4: Register hooks
        echo "4️⃣ Registering hooks...\n";
        register_pohoda_hooks();
        echo "✅ Hooks registered successfully\n";
        
        echo "\n🎉 HostBill Pohoda Integration Module installed successfully!\n";
        echo "\n📋 Next steps:\n";
        echo "   1. Configure Pohoda mServer settings in HostBill admin\n";
        echo "   2. Test connection to Pohoda\n";
        echo "   3. Enable automatic synchronization\n";
        echo "\n🔗 Access: HostBill Admin → Modules → Pohoda Integration\n";
        
        return true;
        
    } catch (Exception $e) {
        echo "❌ Installation failed: " . $e->getMessage() . "\n";
        return false;
    }
}

/**
 * Create database tables for Pohoda module
 */
function create_pohoda_tables() {
    // Pohoda sync log table
    $query = "CREATE TABLE IF NOT EXISTS `mod_pohoda_sync_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `invoice_id` int(11) NOT NULL,
        `action` varchar(50) NOT NULL,
        `status` enum('success','error','pending') NOT NULL DEFAULT 'pending',
        `pohoda_invoice_id` varchar(100) DEFAULT NULL,
        `transaction_id` varchar(100) DEFAULT NULL,
        `error_message` text,
        `xml_request` longtext,
        `xml_response` longtext,
        `processing_time` decimal(10,3) DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `invoice_id` (`invoice_id`),
        KEY `status` (`status`),
        KEY `action` (`action`),
        KEY `created_at` (`created_at`),
        KEY `pohoda_invoice_id` (`pohoda_invoice_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Pohoda synchronization log'";
    
    full_query($query);
    
    // Pohoda configuration table
    $query = "CREATE TABLE IF NOT EXISTS `mod_pohoda_config` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting_name` varchar(100) NOT NULL,
        `setting_value` text,
        `setting_type` varchar(50) DEFAULT 'string',
        `description` text,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting_name` (`setting_name`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Pohoda module configuration'";
    
    full_query($query);
    
    // Pohoda invoice mapping table
    $query = "CREATE TABLE IF NOT EXISTS `mod_pohoda_invoice_mapping` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `hostbill_invoice_id` int(11) NOT NULL,
        `pohoda_invoice_id` varchar(100) NOT NULL,
        `pohoda_invoice_number` varchar(50) DEFAULT NULL,
        `sync_status` enum('synced','error','pending') NOT NULL DEFAULT 'pending',
        `last_sync_at` timestamp NULL DEFAULT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `hostbill_invoice_id` (`hostbill_invoice_id`),
        KEY `pohoda_invoice_id` (`pohoda_invoice_id`),
        KEY `sync_status` (`sync_status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='HostBill to Pohoda invoice mapping'";
    
    full_query($query);
}

/**
 * Register module in HostBill addon system
 */
function register_pohoda_module() {
    // Check if module already exists
    $existing = select_query('tbladdonmodules', 'id', ['module' => 'pohoda'], '', '', '', 1);
    
    if ($existing) {
        echo "   Module already registered, updating...\n";
        
        // Update existing module
        update_query('tbladdonmodules', [
            'value' => 'on'
        ], [
            'module' => 'pohoda',
            'setting' => 'enabled'
        ]);
    } else {
        echo "   Registering new module...\n";
        
        // Insert module registration
        insert_query('tbladdonmodules', [
            'module' => 'pohoda',
            'setting' => 'enabled',
            'value' => 'on'
        ]);
    }
}

/**
 * Set default configuration
 */
function set_default_pohoda_config() {
    $defaultConfig = [
        'mserver_url' => 'http://127.0.0.1:444',
        'mserver_username' => '',
        'mserver_password' => '',
        'data_file' => '',
        'auto_sync_invoices' => 'on',
        'auto_sync_payments' => 'on',
        'sync_customer_data' => 'on',
        'debug_mode' => 'off'
    ];
    
    foreach ($defaultConfig as $setting => $value) {
        // Check if setting already exists
        $existing = select_query('tbladdonmodules', 'id', [
            'module' => 'pohoda',
            'setting' => $setting
        ], '', '', '', 1);
        
        if (!$existing) {
            insert_query('tbladdonmodules', [
                'module' => 'pohoda',
                'setting' => $setting,
                'value' => $value
            ]);
        }
    }
}

/**
 * Register hooks in HostBill
 */
function register_pohoda_hooks() {
    // Include hooks file to register them
    require_once __DIR__ . '/hooks.php';
    
    echo "   Hooks registered for:\n";
    echo "   - InvoiceCreated (auto sync new invoices)\n";
    echo "   - AfterModuleCreate (auto sync payments)\n";
    echo "   - InvoiceChangeStatus (auto sync when marked paid)\n";
}

/**
 * Uninstall Pohoda module
 */
function uninstall_pohoda_module() {
    try {
        echo "🗑️ Uninstalling HostBill Pohoda Integration Module...\n";
        
        // Remove module configuration
        echo "1️⃣ Removing module configuration...\n";
        delete_query('tbladdonmodules', ['module' => 'pohoda']);
        echo "✅ Module configuration removed\n";
        
        // Ask about data removal
        echo "\n⚠️ Do you want to remove all Pohoda sync data? (y/N): ";
        $handle = fopen("php://stdin", "r");
        $line = fgets($handle);
        fclose($handle);
        
        if (trim(strtolower($line)) == 'y') {
            echo "2️⃣ Removing sync data...\n";
            full_query("DROP TABLE IF EXISTS `mod_pohoda_sync_log`");
            full_query("DROP TABLE IF EXISTS `mod_pohoda_config`");
            full_query("DROP TABLE IF EXISTS `mod_pohoda_invoice_mapping`");
            echo "✅ Sync data removed\n";
        } else {
            echo "2️⃣ Keeping sync data (tables preserved)\n";
        }
        
        echo "\n✅ HostBill Pohoda Integration Module uninstalled successfully!\n";
        
        return true;
        
    } catch (Exception $e) {
        echo "❌ Uninstallation failed: " . $e->getMessage() . "\n";
        return false;
    }
}

/**
 * CLI interface
 */
if (php_sapi_name() === 'cli') {
    $action = $argv[1] ?? 'install';
    
    switch ($action) {
        case 'install':
            install_pohoda_module();
            break;
            
        case 'uninstall':
            uninstall_pohoda_module();
            break;
            
        case 'status':
            echo "📊 HostBill Pohoda Module Status:\n";
            $config = getModuleConfiguration('pohoda');
            if ($config) {
                echo "✅ Module: ENABLED\n";
                echo "🔗 mServer URL: " . ($config['mserver_url'] ?? 'Not set') . "\n";
                echo "📁 Data File: " . ($config['data_file'] ?? 'Not set') . "\n";
                echo "👤 Username: " . ($config['mserver_username'] ?? 'Not set') . "\n";
                echo "🔄 Auto Sync Invoices: " . strtoupper($config['auto_sync_invoices'] ?? 'OFF') . "\n";
                echo "💰 Auto Sync Payments: " . strtoupper($config['auto_sync_payments'] ?? 'OFF') . "\n";
            } else {
                echo "❌ Module: DISABLED or NOT INSTALLED\n";
            }
            break;
            
        default:
            echo "Usage: php install.php [install|uninstall|status]\n";
    }
}

?>
