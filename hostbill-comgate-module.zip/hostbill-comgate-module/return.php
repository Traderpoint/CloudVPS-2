<?php
/**
 * Comgate Payment Gateway Return Handler
 * 
 * Handles customer returns from Comgate payment gateway
 * Redirects customers to appropriate pages based on payment status
 * 
 * @version 1.0.0
 */

// Include HostBill configuration
require_once '../../../configuration.php';
require_once '../../../includes/functions.php';
require_once '../../../includes/gatewayfunctions.php';

/**
 * Process customer return from Comgate
 */
function processComgateReturn() {
    try {
        // Log return
        logActivity('Comgate return received from IP: ' . $_SERVER['REMOTE_ADDR']);
        
        // Get parameters from URL
        $invoiceId = isset($_GET['invoiceid']) ? (int)$_GET['invoiceid'] : null;
        $transId = isset($_GET['transId']) ? $_GET['transId'] : null;
        $refId = isset($_GET['refId']) ? $_GET['refId'] : null;
        
        // Log return parameters
        logActivity('Comgate return parameters: invoiceId=' . $invoiceId . ', transId=' . $transId . ', refId=' . $refId);
        
        if (!$invoiceId) {
            logActivity('Comgate return: Missing invoice ID, redirecting to client area');
            header('Location: /clientarea.php?error=invalid_return');
            exit;
        }
        
        // Get invoice details
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        
        if ($invoice['result'] !== 'success') {
            logActivity('Comgate return: Invoice not found - ' . $invoiceId);
            header('Location: /clientarea.php?error=invoice_not_found');
            exit;
        }
        
        // Check if customer owns this invoice
        if (!checkInvoiceOwnership($invoiceId)) {
            logActivity('Comgate return: Access denied for invoice ' . $invoiceId);
            header('Location: /clientarea.php?error=access_denied');
            exit;
        }
        
        // Determine redirect based on payment status
        switch ($invoice['status']) {
            case 'Paid':
                // Payment successful
                logActivity('Comgate return: Payment successful for invoice ' . $invoiceId);
                header('Location: /viewinvoice.php?id=' . $invoiceId . '&paymentsuccess=true');
                break;
                
            case 'Unpaid':
                // Check if payment is pending (transaction ID in notes)
                if (strpos($invoice['notes'], 'Comgate Transaction ID:') !== false || 
                    strpos($invoice['notes'], 'Comgate payment pending') !== false) {
                    // Payment is pending
                    logActivity('Comgate return: Payment pending for invoice ' . $invoiceId);
                    header('Location: /viewinvoice.php?id=' . $invoiceId . '&paymentpending=true');
                } else {
                    // Payment failed or cancelled
                    logActivity('Comgate return: Payment failed/cancelled for invoice ' . $invoiceId);
                    header('Location: /viewinvoice.php?id=' . $invoiceId . '&paymentfailed=true');
                }
                break;
                
            default:
                // Unknown status
                logActivity('Comgate return: Unknown status for invoice ' . $invoiceId . ' - ' . $invoice['status']);
                header('Location: /viewinvoice.php?id=' . $invoiceId . '&paymentpending=true');
                break;
        }
        
        exit;
        
    } catch (Exception $e) {
        logActivity('Comgate return handler error: ' . $e->getMessage());
        header('Location: /clientarea.php?error=system_error');
        exit;
    }
}

/**
 * Check if current user owns the invoice
 */
function checkInvoiceOwnership($invoiceId) {
    try {
        // Get current user ID
        if (!isset($_SESSION['uid'])) {
            return false;
        }
        
        $userId = $_SESSION['uid'];
        
        // Get invoice owner
        $result = full_query("SELECT userid FROM tblinvoices WHERE id = " . (int)$invoiceId);
        $invoice = mysql_fetch_assoc($result);
        
        if (!$invoice) {
            return false;
        }
        
        return ($invoice['userid'] == $userId);
        
    } catch (Exception $e) {
        logActivity('Comgate ownership check error: ' . $e->getMessage());
        return false;
    }
}

/**
 * Display payment status message
 */
function displayPaymentStatus($status, $invoiceId) {
    $messages = [
        'success' => [
            'title' => 'Payment Successful',
            'message' => 'Your payment has been processed successfully.',
            'class' => 'alert-success'
        ],
        'pending' => [
            'title' => 'Payment Pending',
            'message' => 'Your payment is being processed. You will receive confirmation once it is complete.',
            'class' => 'alert-info'
        ],
        'failed' => [
            'title' => 'Payment Failed',
            'message' => 'Your payment could not be processed. Please try again or contact support.',
            'class' => 'alert-danger'
        ]
    ];
    
    $statusInfo = isset($messages[$status]) ? $messages[$status] : $messages['pending'];
    
    echo '<!DOCTYPE html>
<html>
<head>
    <title>Payment Status</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="alert ' . $statusInfo['class'] . '" role="alert">
                    <h4 class="alert-heading">' . $statusInfo['title'] . '</h4>
                    <p>' . $statusInfo['message'] . '</p>
                    <hr>
                    <p class="mb-0">
                        <a href="/viewinvoice.php?id=' . $invoiceId . '" class="btn btn-primary">View Invoice</a>
                        <a href="/clientarea.php" class="btn btn-secondary">Client Area</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>';
}

// Process the return
processComgateReturn();
?>
