<?php
/**
 * Comgate Payment Gateway Callback Handler
 * 
 * Handles push notifications from Comgate payment gateway
 * Processes payment status updates and marks invoices as paid
 * 
 * @version 1.0.0
 * @link https://help.comgate.cz/docs/api-protokol
 */

// Include HostBill configuration
require_once '../../../configuration.php';
require_once '../../../includes/functions.php';
require_once '../../../includes/gatewayfunctions.php';

// Include Comgate client
require_once 'comgate-client.php';

/**
 * Process Comgate callback
 */
function processComgateCallback() {
    try {
        // Log callback received
        logActivity('Comgate callback received from IP: ' . $_SERVER['REMOTE_ADDR']);
        
        // Get POST data
        $callbackData = $_POST;
        
        // Log received data (without sensitive information)
        $logData = $callbackData;
        unset($logData['secret']);
        logActivity('Comgate callback data: ' . json_encode($logData));
        
        // Validate required fields
        $requiredFields = ['merchant', 'test', 'price', 'curr', 'refId', 'transId', 'secret', 'status'];
        foreach ($requiredFields as $field) {
            if (!isset($callbackData[$field])) {
                logActivity('Comgate callback error: Missing field ' . $field);
                http_response_code(400);
                echo 'Missing required field: ' . $field;
                return;
            }
        }
        
        // Get gateway configuration
        $gatewayConfig = getGatewayVariables('comgate');
        if (!$gatewayConfig) {
            logActivity('Comgate callback error: Gateway not configured');
            http_response_code(500);
            echo 'Gateway not configured';
            return;
        }
        
        // Initialize Comgate client
        $client = new ComgateClient($gatewayConfig);
        
        // Validate callback
        $validation = $client->validateCallback($callbackData);
        if (!$validation['success']) {
            logActivity('Comgate callback validation failed: ' . $validation['message']);
            http_response_code(400);
            echo 'Validation failed: ' . $validation['message'];
            return;
        }
        
        // Get invoice ID from refId
        $invoiceId = $callbackData['refId'];
        
        // Check if invoice exists
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        if ($invoice['result'] !== 'success') {
            logActivity('Comgate callback error: Invoice not found - ' . $invoiceId);
            http_response_code(404);
            echo 'Invoice not found';
            return;
        }
        
        // Check if invoice is already paid
        if ($invoice['status'] === 'Paid') {
            logActivity('Comgate callback: Invoice already paid - ' . $invoiceId);
            echo 'OK - Invoice already paid';
            return;
        }
        
        // Process based on payment status
        $status = $callbackData['status'];
        $transId = $callbackData['transId'];
        $amount = $callbackData['price'] / 100; // Convert from cents
        $currency = $callbackData['curr'];
        
        switch ($status) {
            case 'PAID':
                // Payment successful - mark invoice as paid
                $result = processPayment($invoiceId, $transId, $amount, $currency, $callbackData);
                
                if ($result['success']) {
                    logActivity('Comgate payment processed successfully: ' . $transId . ' for invoice ' . $invoiceId);
                    echo 'OK';
                } else {
                    logActivity('Comgate payment processing failed: ' . $result['message']);
                    http_response_code(500);
                    echo 'Payment processing failed';
                }
                break;
                
            case 'CANCELLED':
                // Payment cancelled
                logActivity('Comgate payment cancelled: ' . $transId . ' for invoice ' . $invoiceId);
                
                // Update invoice notes
                $notes = 'Comgate payment cancelled - Transaction ID: ' . $transId;
                if (isset($callbackData['paymentErrorReason'])) {
                    $notes .= ' - Reason: ' . $callbackData['paymentErrorReason'];
                }
                
                localAPI('UpdateInvoice', [
                    'invoiceid' => $invoiceId,
                    'notes' => $notes
                ]);
                
                echo 'OK - Payment cancelled';
                break;
                
            case 'PENDING':
                // Payment pending - just log it
                logActivity('Comgate payment pending: ' . $transId . ' for invoice ' . $invoiceId);
                
                // Update invoice notes
                localAPI('UpdateInvoice', [
                    'invoiceid' => $invoiceId,
                    'notes' => 'Comgate payment pending - Transaction ID: ' . $transId
                ]);
                
                echo 'OK - Payment pending';
                break;
                
            case 'AUTHORIZED':
                // Pre-authorization successful
                logActivity('Comgate payment authorized: ' . $transId . ' for invoice ' . $invoiceId);
                
                // Update invoice notes
                localAPI('UpdateInvoice', [
                    'invoiceid' => $invoiceId,
                    'notes' => 'Comgate payment authorized - Transaction ID: ' . $transId . ' - Requires capture'
                ]);
                
                echo 'OK - Payment authorized';
                break;
                
            default:
                logActivity('Comgate callback: Unknown status ' . $status . ' for transaction ' . $transId);
                echo 'OK - Unknown status';
                break;
        }
        
    } catch (Exception $e) {
        logActivity('Comgate callback exception: ' . $e->getMessage());
        http_response_code(500);
        echo 'Internal server error';
    }
}

/**
 * Process successful payment
 */
function processPayment($invoiceId, $transId, $amount, $currency, $callbackData) {
    try {
        // Prepare payment data
        $paymentData = [
            'invoiceid' => $invoiceId,
            'transid' => $transId,
            'amount' => $amount,
            'fees' => isset($callbackData['fee']) && $callbackData['fee'] !== 'unknown' ? ($callbackData['fee'] / 100) : 0,
            'gateway' => 'comgate'
        ];
        
        // Add payment method if available
        if (isset($callbackData['method'])) {
            $paymentData['paymentmethod'] = $callbackData['method'];
        }
        
        // Add additional information to notes
        $notes = 'Comgate Payment Details:' . "\n";
        $notes .= 'Transaction ID: ' . $transId . "\n";
        $notes .= 'Amount: ' . number_format($amount, 2) . ' ' . $currency . "\n";
        
        if (isset($callbackData['method'])) {
            $notes .= 'Payment Method: ' . $callbackData['method'] . "\n";
        }
        
        if (isset($callbackData['vs'])) {
            $notes .= 'Variable Symbol: ' . $callbackData['vs'] . "\n";
        }
        
        if (isset($callbackData['fee']) && $callbackData['fee'] !== 'unknown') {
            $notes .= 'Gateway Fee: ' . number_format($callbackData['fee'] / 100, 2) . ' ' . $currency . "\n";
        }
        
        if (isset($callbackData['payerName'])) {
            $notes .= 'Payer Name: ' . $callbackData['payerName'] . "\n";
        }
        
        if (isset($callbackData['payerAcc'])) {
            $notes .= 'Payer Account: ' . $callbackData['payerAcc'] . "\n";
        }
        
        // Add payment to HostBill
        $result = localAPI('AddInvoicePayment', [
            'invoiceid' => $invoiceId,
            'transid' => $transId,
            'amount' => $amount,
            'fees' => $paymentData['fees'],
            'gateway' => 'comgate',
            'date' => date('Y-m-d H:i:s')
        ]);
        
        if ($result['result'] === 'success') {
            // Update invoice notes
            localAPI('UpdateInvoice', [
                'invoiceid' => $invoiceId,
                'notes' => $notes
            ]);
            
            // Send payment confirmation email if configured
            sendPaymentConfirmationEmail($invoiceId, $transId, $amount, $currency);
            
            return ['success' => true, 'message' => 'Payment processed successfully'];
        } else {
            return ['success' => false, 'message' => 'Failed to add payment: ' . $result['message']];
        }
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Send payment confirmation email
 */
function sendPaymentConfirmationEmail($invoiceId, $transId, $amount, $currency) {
    try {
        // Get invoice details
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        
        if ($invoice['result'] === 'success') {
            // Send payment confirmation
            localAPI('SendEmail', [
                'messagename' => 'Invoice Payment Confirmation',
                'id' => $invoiceId,
                'customvars' => [
                    'transaction_id' => $transId,
                    'payment_amount' => number_format($amount, 2) . ' ' . $currency,
                    'payment_method' => 'Comgate'
                ]
            ]);
            
            logActivity('Comgate payment confirmation email sent for invoice ' . $invoiceId);
        }
        
    } catch (Exception $e) {
        logActivity('Comgate email sending failed: ' . $e->getMessage());
    }
}

/**
 * Return handler for customer redirects
 */
function processComgateReturn() {
    try {
        // Get parameters from URL
        $invoiceId = isset($_GET['invoiceid']) ? $_GET['invoiceid'] : null;
        $transId = isset($_GET['transId']) ? $_GET['transId'] : null;
        $refId = isset($_GET['refId']) ? $_GET['refId'] : null;
        
        if (!$invoiceId) {
            // Redirect to client area
            header('Location: /clientarea.php');
            exit;
        }
        
        // Get invoice details
        $invoice = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);
        
        if ($invoice['result'] !== 'success') {
            // Redirect to client area
            header('Location: /clientarea.php');
            exit;
        }
        
        // Check payment status
        if ($invoice['status'] === 'Paid') {
            // Payment successful - redirect to success page
            header('Location: /viewinvoice.php?id=' . $invoiceId . '&paymentsuccess=true');
        } else {
            // Payment not yet confirmed - redirect to pending page
            header('Location: /viewinvoice.php?id=' . $invoiceId . '&paymentpending=true');
        }
        
        exit;
        
    } catch (Exception $e) {
        logActivity('Comgate return handler error: ' . $e->getMessage());
        header('Location: /clientarea.php');
        exit;
    }
}

// Determine which handler to use based on the request
if (basename($_SERVER['PHP_SELF']) === 'callback.php') {
    // This is a callback from Comgate
    processComgateCallback();
} else if (basename($_SERVER['PHP_SELF']) === 'return.php') {
    // This is a return from payment gateway
    processComgateReturn();
} else {
    // Invalid access
    http_response_code(404);
    echo 'Not found';
}
?>
