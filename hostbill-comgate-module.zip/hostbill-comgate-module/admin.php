<?php
/**
 * Comgate Payment Gateway Admin Interface
 * 
 * Admin dashboard for Comgate payment gateway module
 * Provides configuration, testing, and monitoring tools
 * 
 * @version 1.0.0
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Main admin dashboard
 */
function comgate_admin_dashboard($params) {
    $output = '';
    
    // Handle actions
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'test_connection':
                $output .= comgate_admin_test_connection($params);
                break;
            case 'get_methods':
                $output .= comgate_admin_get_methods($params);
                break;
            case 'view_transactions':
                $output .= comgate_admin_view_transactions($params);
                break;
        }
    }
    
    // Dashboard header
    $output .= '<div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">
                <i class="fa fa-credit-card"></i> Comgate Payment Gateway Dashboard
            </h3>
        </div>
        <div class="panel-body">';
    
    // Configuration status
    $output .= comgate_admin_config_status($params);
    
    // Quick actions
    $output .= comgate_admin_quick_actions($params);
    
    // Statistics
    $output .= comgate_admin_statistics($params);
    
    // Recent transactions
    $output .= comgate_admin_recent_transactions($params);
    
    $output .= '</div></div>';
    
    return $output;
}

/**
 * Configuration status panel
 */
function comgate_admin_config_status($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <h4 class="panel-title">Configuration Status</h4>
                </div>
                <div class="panel-body">
                    <div class="row">';
    
    // Check configuration
    $configStatus = [
        'Merchant ID' => !empty($params['merchant_id']),
        'Secret Key' => !empty($params['secret']),
        'Test Mode' => isset($params['test_mode']),
        'Payment Methods' => !empty($params['payment_methods']),
        'Callback URL' => true // Always available
    ];
    
    foreach ($configStatus as $item => $status) {
        $icon = $status ? 'fa-check text-success' : 'fa-times text-danger';
        $output .= '<div class="col-md-4">
            <i class="fa ' . $icon . '"></i> ' . $item . '
        </div>';
    }
    
    $output .= '</div>';
    
    // Callback URL info
    $callbackUrl = App::getUrl() . '/modules/gateways/comgate/callback.php';
    $output .= '<hr>
        <div class="alert alert-info">
            <strong>Callback URL:</strong><br>
            <code>' . $callbackUrl . '</code><br>
            <small>Configure this URL in your Comgate client portal under "Push notifications"</small>
        </div>';
    
    $output .= '</div></div></div></div>';
    
    return $output;
}

/**
 * Quick actions panel
 */
function comgate_admin_quick_actions($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Quick Actions</h4>
                </div>
                <div class="panel-body">
                    <div class="btn-group" role="group">';
    
    // Test connection button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="test_connection">
        <button type="submit" class="btn btn-primary">
            <i class="fa fa-plug"></i> Test Connection
        </button>
    </form>';
    
    // Get payment methods button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="get_methods">
        <button type="submit" class="btn btn-info">
            <i class="fa fa-list"></i> Get Payment Methods
        </button>
    </form>';
    
    // View transactions button
    $output .= '<form method="post" style="display: inline;">
        <input type="hidden" name="action" value="view_transactions">
        <button type="submit" class="btn btn-default">
            <i class="fa fa-history"></i> View Transactions
        </button>
    </form>';
    
    $output .= '</div></div></div></div></div>';
    
    return $output;
}

/**
 * Statistics panel
 */
function comgate_admin_statistics($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h4 class="panel-title">Statistics (Last 30 Days)</h4>
                </div>
                <div class="panel-body">
                    <div class="row">';
    
    // Get statistics from database
    $stats = comgate_get_statistics();
    
    $output .= '<div class="col-md-3 text-center">
        <h3 class="text-primary">' . $stats['total_transactions'] . '</h3>
        <p>Total Transactions</p>
    </div>
    <div class="col-md-3 text-center">
        <h3 class="text-success">' . $stats['successful_payments'] . '</h3>
        <p>Successful Payments</p>
    </div>
    <div class="col-md-3 text-center">
        <h3 class="text-warning">' . $stats['pending_payments'] . '</h3>
        <p>Pending Payments</p>
    </div>
    <div class="col-md-3 text-center">
        <h3 class="text-danger">' . $stats['failed_payments'] . '</h3>
        <p>Failed Payments</p>
    </div>';
    
    $output .= '</div></div></div></div></div>';
    
    return $output;
}

/**
 * Recent transactions panel
 */
function comgate_admin_recent_transactions($params) {
    $output = '<div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Recent Transactions</h4>
                </div>
                <div class="panel-body">';
    
    // Get recent transactions
    $transactions = comgate_get_recent_transactions();
    
    if (!empty($transactions)) {
        $output .= '<div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Invoice ID</th>
                        <th>Transaction ID</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>';
        
        foreach ($transactions as $transaction) {
            $statusClass = '';
            switch ($transaction['status']) {
                case 'Paid':
                    $statusClass = 'label-success';
                    break;
                case 'Pending':
                    $statusClass = 'label-warning';
                    break;
                case 'Cancelled':
                    $statusClass = 'label-danger';
                    break;
                default:
                    $statusClass = 'label-default';
            }
            
            $output .= '<tr>
                <td><a href="/admin/invoices.php?action=edit&id=' . $transaction['invoiceid'] . '">' . $transaction['invoiceid'] . '</a></td>
                <td><code>' . $transaction['transid'] . '</code></td>
                <td>' . $transaction['amount'] . ' ' . $transaction['currency'] . '</td>
                <td><span class="label ' . $statusClass . '">' . $transaction['status'] . '</span></td>
                <td>' . $transaction['date'] . '</td>
                <td>
                    <a href="/admin/invoices.php?action=edit&id=' . $transaction['invoiceid'] . '" class="btn btn-xs btn-default">
                        <i class="fa fa-eye"></i> View
                    </a>
                </td>
            </tr>';
        }
        
        $output .= '</tbody></table></div>';
    } else {
        $output .= '<div class="alert alert-info">No recent transactions found.</div>';
    }
    
    $output .= '</div></div></div></div>';
    
    return $output;
}

/**
 * Test connection to Comgate API
 */
function comgate_admin_test_connection($params) {
    $output = '<div class="alert alert-info">
        <h4><i class="fa fa-spinner fa-spin"></i> Testing Connection...</h4>
    </div>';
    
    try {
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        $result = $client->testConnection();
        
        if ($result['success']) {
            $output = '<div class="alert alert-success">
                <h4><i class="fa fa-check"></i> Connection Successful!</h4>
                <p>' . $result['message'] . '</p>
                <p><strong>Available payment methods:</strong> ' . $result['methods_count'] . '</p>
            </div>';
        } else {
            $output = '<div class="alert alert-danger">
                <h4><i class="fa fa-times"></i> Connection Failed!</h4>
                <p>' . $result['message'] . '</p>
            </div>';
        }
        
    } catch (Exception $e) {
        $output = '<div class="alert alert-danger">
            <h4><i class="fa fa-times"></i> Connection Error!</h4>
            <p>' . $e->getMessage() . '</p>
        </div>';
    }
    
    return $output;
}

/**
 * Get available payment methods
 */
function comgate_admin_get_methods($params) {
    $output = '';
    
    try {
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        $result = $client->getPaymentMethods([
            'merchant' => $params['merchant_id'],
            'secret' => $params['secret'],
            'type' => 'json',
            'lang' => $params['language'] ?: 'cs'
        ]);
        
        if ($result['success']) {
            $output .= '<div class="alert alert-success">
                <h4><i class="fa fa-check"></i> Payment Methods Retrieved Successfully!</h4>
            </div>';
            
            $output .= '<div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">Available Payment Methods</h4>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Group</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>';
            
            foreach ($result['methods'] as $method) {
                $output .= '<tr>
                    <td><code>' . $method['id'] . '</code></td>
                    <td>' . $method['name'] . '</td>
                    <td>' . $method['groupLabel'] . '</td>
                    <td>' . $method['description'] . '</td>
                </tr>';
            }
            
            $output .= '</tbody></table></div></div></div>';
        } else {
            $output .= '<div class="alert alert-danger">
                <h4><i class="fa fa-times"></i> Failed to Retrieve Payment Methods!</h4>
                <p>' . $result['message'] . '</p>
            </div>';
        }
        
    } catch (Exception $e) {
        $output .= '<div class="alert alert-danger">
            <h4><i class="fa fa-times"></i> Error!</h4>
            <p>' . $e->getMessage() . '</p>
        </div>';
    }
    
    return $output;
}

/**
 * Get statistics from database
 */
function comgate_get_statistics() {
    $stats = [
        'total_transactions' => 0,
        'successful_payments' => 0,
        'pending_payments' => 0,
        'failed_payments' => 0
    ];
    
    try {
        // Get total transactions with Comgate in last 30 days
        $result = full_query("SELECT COUNT(*) as count FROM tblinvoices 
            WHERE notes LIKE '%Comgate Transaction ID:%' 
            AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $row = mysql_fetch_assoc($result);
        $stats['total_transactions'] = $row['count'];
        
        // Get successful payments
        $result = full_query("SELECT COUNT(*) as count FROM tblinvoices 
            WHERE notes LIKE '%Comgate Transaction ID:%' 
            AND status = 'Paid'
            AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $row = mysql_fetch_assoc($result);
        $stats['successful_payments'] = $row['count'];
        
        // Get pending payments
        $result = full_query("SELECT COUNT(*) as count FROM tblinvoices 
            WHERE notes LIKE '%Comgate payment pending%' 
            AND status = 'Unpaid'
            AND date >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
        $row = mysql_fetch_assoc($result);
        $stats['pending_payments'] = $row['count'];
        
        // Calculate failed payments
        $stats['failed_payments'] = $stats['total_transactions'] - $stats['successful_payments'] - $stats['pending_payments'];
        
    } catch (Exception $e) {
        // Return default stats on error
    }
    
    return $stats;
}

/**
 * Get recent transactions
 */
function comgate_get_recent_transactions($limit = 10) {
    $transactions = [];
    
    try {
        $result = full_query("SELECT i.id as invoiceid, i.total as amount, i.status, i.date, 
            SUBSTRING_INDEX(SUBSTRING_INDEX(i.notes, 'Transaction ID: ', -1), '\n', 1) as transid,
            c.currency
            FROM tblinvoices i 
            LEFT JOIN tblclients c ON i.userid = c.id
            WHERE i.notes LIKE '%Comgate Transaction ID:%' 
            ORDER BY i.date DESC 
            LIMIT " . (int)$limit);
        
        while ($row = mysql_fetch_assoc($result)) {
            $transactions[] = $row;
        }
        
    } catch (Exception $e) {
        // Return empty array on error
    }
    
    return $transactions;
}
?>
