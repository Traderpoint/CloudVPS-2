<?php
/**
 * Comgate Payment Gateway Module Installer
 * 
 * Automated installation script for HostBill Comgate payment gateway module
 * Creates database tables, registers module, and sets up configuration
 * 
 * @version 1.0.0
 */

// Prevent direct access
if (php_sapi_name() !== 'cli' && !defined('HOSTBILL')) {
    die('This script can only be run from command line or HostBill admin area');
}

/**
 * Main installation function
 */
function install_comgate_module() {
    echo "🚀 Installing HostBill Comgate Payment Gateway Module...\n";
    
    try {
        // Step 1: Create database tables
        echo "1️⃣ Creating database tables...\n";
        create_comgate_tables();
        echo "✅ Database tables created successfully\n";
        
        // Step 2: Register module in HostBill
        echo "2️⃣ Registering module in HostBill...\n";
        register_comgate_module();
        echo "✅ Module registered successfully\n";
        
        // Step 3: Set default configuration
        echo "3️⃣ Setting default configuration...\n";
        set_default_comgate_config();
        echo "✅ Default configuration set\n";
        
        // Step 4: Create callback URLs
        echo "4️⃣ Setting up callback URLs...\n";
        setup_comgate_callbacks();
        echo "✅ Callback URLs configured\n";
        
        // Step 5: Set file permissions
        echo "5️⃣ Setting file permissions...\n";
        set_comgate_permissions();
        echo "✅ File permissions set\n";
        
        echo "\n🎉 HostBill Comgate Payment Gateway Module installed successfully!\n";
        echo "\n📋 Next steps:\n";
        echo "1. Configure your Comgate credentials in HostBill admin\n";
        echo "2. Set up callback URL in Comgate client portal\n";
        echo "3. Test the payment gateway\n";
        echo "4. Enable the gateway for production use\n";
        
        return true;
        
    } catch (Exception $e) {
        echo "❌ Installation failed: " . $e->getMessage() . "\n";
        return false;
    }
}

/**
 * Create database tables
 */
function create_comgate_tables() {
    // Transaction log table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_comgate_transactions` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `invoice_id` int(11) NOT NULL,
        `transaction_id` varchar(50) NOT NULL,
        `amount` decimal(10,2) NOT NULL,
        `currency` varchar(3) NOT NULL,
        `status` enum('PENDING','PAID','CANCELLED','AUTHORIZED') NOT NULL DEFAULT 'PENDING',
        `payment_method` varchar(50) DEFAULT NULL,
        `fee` decimal(10,2) DEFAULT NULL,
        `test_mode` tinyint(1) NOT NULL DEFAULT 0,
        `callback_data` text,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `transaction_id` (`transaction_id`),
        KEY `invoice_id` (`invoice_id`),
        KEY `status` (`status`),
        KEY `created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_comgate_transactions table");
    }
    
    // Configuration table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_comgate_config` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting` varchar(100) NOT NULL,
        `value` text,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting` (`setting`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_comgate_config table");
    }
    
    // Callback log table
    $sql = "CREATE TABLE IF NOT EXISTS `mod_comgate_callbacks` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `transaction_id` varchar(50) NOT NULL,
        `invoice_id` int(11) NOT NULL,
        `status` varchar(20) NOT NULL,
        `callback_data` text NOT NULL,
        `ip_address` varchar(45) NOT NULL,
        `processed` tinyint(1) NOT NULL DEFAULT 0,
        `error_message` text,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `transaction_id` (`transaction_id`),
        KEY `invoice_id` (`invoice_id`),
        KEY `processed` (`processed`),
        KEY `created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to create mod_comgate_callbacks table");
    }
}

/**
 * Register module in HostBill
 */
function register_comgate_module() {
    // Check if module is already registered
    $result = full_query("SELECT id FROM tblpaymentgateways WHERE gateway = 'comgate'");
    
    if (mysql_num_rows($result) == 0) {
        // Register the module
        $sql = "INSERT INTO tblpaymentgateways (gateway, name, type, visible) 
                VALUES ('comgate', 'Comgate Payment Gateway', 'Invoices', 1)";
        
        if (!full_query($sql)) {
            throw new Exception("Failed to register module in HostBill");
        }
    }
}

/**
 * Set default configuration
 */
function set_default_comgate_config() {
    $defaultConfig = [
        'merchant_id' => '',
        'secret' => '',
        'test_mode' => 'yes',
        'payment_methods' => 'ALL',
        'country' => 'CZ',
        'language' => 'cs',
        'auto_redirect' => 'yes',
        'embedded_mode' => 'no',
        'preauth' => 'no',
        'debug_mode' => 'no'
    ];
    
    foreach ($defaultConfig as $setting => $value) {
        $sql = "INSERT INTO mod_comgate_config (setting, value) 
                VALUES ('" . mysql_real_escape_string($setting) . "', '" . mysql_real_escape_string($value) . "')
                ON DUPLICATE KEY UPDATE value = VALUES(value)";
        
        if (!full_query($sql)) {
            throw new Exception("Failed to set default configuration for: " . $setting);
        }
    }
}

/**
 * Setup callback URLs
 */
function setup_comgate_callbacks() {
    // Get HostBill URL
    $hostbill_url = get_hostbill_url();
    
    $callback_url = $hostbill_url . '/modules/gateways/comgate/callback.php';
    $return_url = $hostbill_url . '/modules/gateways/comgate/return.php';
    
    // Store URLs in configuration
    $sql = "INSERT INTO mod_comgate_config (setting, value) 
            VALUES ('callback_url', '" . mysql_real_escape_string($callback_url) . "')
            ON DUPLICATE KEY UPDATE value = VALUES(value)";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to set callback URL");
    }
    
    $sql = "INSERT INTO mod_comgate_config (setting, value) 
            VALUES ('return_url', '" . mysql_real_escape_string($return_url) . "')
            ON DUPLICATE KEY UPDATE value = VALUES(value)";
    
    if (!full_query($sql)) {
        throw new Exception("Failed to set return URL");
    }
    
    echo "📋 Callback URL: " . $callback_url . "\n";
    echo "📋 Return URL: " . $return_url . "\n";
}

/**
 * Set file permissions
 */
function set_comgate_permissions() {
    $module_path = dirname(__FILE__);
    
    // Set directory permissions
    if (is_dir($module_path)) {
        chmod($module_path, 0755);
    }
    
    // Set file permissions
    $files = [
        'comgate.php',
        'comgate-client.php',
        'callback.php',
        'return.php',
        'admin.php',
        'install.php'
    ];
    
    foreach ($files as $file) {
        $file_path = $module_path . '/' . $file;
        if (file_exists($file_path)) {
            chmod($file_path, 0644);
        }
    }
}

/**
 * Get HostBill URL
 */
function get_hostbill_url() {
    // Try to get URL from HostBill configuration
    if (function_exists('App::getUrl')) {
        return App::getUrl();
    }
    
    // Fallback to detecting from server variables
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path = dirname(dirname(dirname($_SERVER['SCRIPT_NAME'])));
    
    return $protocol . '://' . $host . $path;
}

/**
 * Uninstall function
 */
function uninstall_comgate_module() {
    echo "🗑️ Uninstalling HostBill Comgate Payment Gateway Module...\n";
    
    try {
        // Remove database tables
        echo "1️⃣ Removing database tables...\n";
        full_query("DROP TABLE IF EXISTS mod_comgate_transactions");
        full_query("DROP TABLE IF EXISTS mod_comgate_config");
        full_query("DROP TABLE IF EXISTS mod_comgate_callbacks");
        echo "✅ Database tables removed\n";
        
        // Remove module registration
        echo "2️⃣ Removing module registration...\n";
        full_query("DELETE FROM tblpaymentgateways WHERE gateway = 'comgate'");
        echo "✅ Module registration removed\n";
        
        echo "\n🎉 HostBill Comgate Payment Gateway Module uninstalled successfully!\n";
        
        return true;
        
    } catch (Exception $e) {
        echo "❌ Uninstallation failed: " . $e->getMessage() . "\n";
        return false;
    }
}

/**
 * Test installation
 */
function test_comgate_installation() {
    echo "🧪 Testing HostBill Comgate Payment Gateway Module installation...\n";
    
    $tests = [
        'Database tables' => test_database_tables(),
        'Module registration' => test_module_registration(),
        'Configuration' => test_configuration(),
        'File permissions' => test_file_permissions(),
        'Callback URLs' => test_callback_urls()
    ];
    
    $passed = 0;
    $total = count($tests);
    
    foreach ($tests as $test => $result) {
        if ($result) {
            echo "✅ " . $test . ": PASSED\n";
            $passed++;
        } else {
            echo "❌ " . $test . ": FAILED\n";
        }
    }
    
    echo "\n📊 Test Results: " . $passed . "/" . $total . " tests passed\n";
    
    if ($passed === $total) {
        echo "🎉 All tests passed! Module is ready for use.\n";
        return true;
    } else {
        echo "⚠️ Some tests failed. Please check the installation.\n";
        return false;
    }
}

/**
 * Test database tables
 */
function test_database_tables() {
    $tables = ['mod_comgate_transactions', 'mod_comgate_config', 'mod_comgate_callbacks'];
    
    foreach ($tables as $table) {
        $result = full_query("SHOW TABLES LIKE '" . $table . "'");
        if (mysql_num_rows($result) == 0) {
            return false;
        }
    }
    
    return true;
}

/**
 * Test module registration
 */
function test_module_registration() {
    $result = full_query("SELECT id FROM tblpaymentgateways WHERE gateway = 'comgate'");
    return mysql_num_rows($result) > 0;
}

/**
 * Test configuration
 */
function test_configuration() {
    $result = full_query("SELECT COUNT(*) as count FROM mod_comgate_config");
    $row = mysql_fetch_assoc($result);
    return $row['count'] > 0;
}

/**
 * Test file permissions
 */
function test_file_permissions() {
    $module_path = dirname(__FILE__);
    return is_readable($module_path . '/comgate.php') && is_readable($module_path . '/callback.php');
}

/**
 * Test callback URLs
 */
function test_callback_urls() {
    $result = full_query("SELECT value FROM mod_comgate_config WHERE setting = 'callback_url'");
    return mysql_num_rows($result) > 0;
}

// Command line interface
if (php_sapi_name() === 'cli') {
    $action = isset($argv[1]) ? $argv[1] : 'help';
    
    switch ($action) {
        case 'install':
            install_comgate_module();
            break;
        case 'uninstall':
            uninstall_comgate_module();
            break;
        case 'test':
            test_comgate_installation();
            break;
        case 'help':
        default:
            echo "HostBill Comgate Payment Gateway Module Installer\n";
            echo "Usage: php install.php [action]\n";
            echo "Actions:\n";
            echo "  install   - Install the module\n";
            echo "  uninstall - Uninstall the module\n";
            echo "  test      - Test the installation\n";
            echo "  help      - Show this help message\n";
            break;
    }
}
?>
