<?php
/**
 * Comgate API Client
 * 
 * Official Comgate API client for communication with Comgate Payment Gateway
 * Implements all API methods according to official documentation
 * 
 * @version 1.0.0
 * @link https://help.comgate.cz/docs/api-protokol
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

class ComgateClient {
    
    private $config;
    private $apiUrl = 'https://payments.comgate.cz/v1.0/';
    private $testApiUrl = 'https://payments.comgate.cz/v1.0/';
    
    /**
     * Constructor
     */
    public function __construct($config) {
        $this->config = $config;
    }
    
    /**
     * Create payment
     */
    public function createPayment($data) {
        try {
            $response = $this->makeRequest('create', $data);
            
            if ($response && isset($response['code']) && $response['code'] == '0') {
                return [
                    'success' => true,
                    'transId' => $response['transId'],
                    'redirect' => $response['redirect'],
                    'message' => $response['message']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => isset($response['message']) ? $response['message'] : 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get payment status
     */
    public function getPaymentStatus($data) {
        try {
            $response = $this->makeRequest('status', $data);
            
            if ($response && isset($response['code']) && $response['code'] == '0') {
                return [
                    'success' => true,
                    'status' => $response['status'],
                    'transId' => $response['transId'],
                    'price' => $response['price'],
                    'curr' => $response['curr'],
                    'refId' => $response['refId'],
                    'method' => isset($response['method']) ? $response['method'] : null,
                    'email' => $response['email'],
                    'fee' => isset($response['fee']) ? $response['fee'] : null,
                    'vs' => isset($response['vs']) ? $response['vs'] : null
                ];
            } else {
                return [
                    'success' => false,
                    'message' => isset($response['message']) ? $response['message'] : 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Refund payment
     */
    public function refundPayment($data) {
        try {
            $response = $this->makeRequest('refund', $data);
            
            if ($response && isset($response['code']) && $response['code'] == '0') {
                return [
                    'success' => true,
                    'message' => $response['message']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => isset($response['message']) ? $response['message'] : 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Capture pre-authorized payment
     */
    public function capturePreauth($data) {
        try {
            $response = $this->makeRequest('capturePreauth', $data);
            
            if ($response && isset($response['code']) && $response['code'] == '0') {
                return [
                    'success' => true,
                    'message' => $response['message']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => isset($response['message']) ? $response['message'] : 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Cancel pre-authorized payment
     */
    public function cancelPreauth($data) {
        try {
            $response = $this->makeRequest('cancelPreauth', $data);
            
            if ($response && isset($response['code']) && $response['code'] == '0') {
                return [
                    'success' => true,
                    'message' => $response['message']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => isset($response['message']) ? $response['message'] : 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Get available payment methods
     */
    public function getPaymentMethods($data) {
        try {
            $response = $this->makeRequest('methods', $data);
            
            if ($response && isset($response['methods'])) {
                return [
                    'success' => true,
                    'methods' => $response['methods']
                ];
            } else if ($response && isset($response['error'])) {
                return [
                    'success' => false,
                    'message' => $response['error'][0]['message']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Create recurring payment
     */
    public function createRecurringPayment($data) {
        try {
            $response = $this->makeRequest('recurring', $data);
            
            if ($response && isset($response['code']) && $response['code'] == '0') {
                return [
                    'success' => true,
                    'transId' => $response['transId'],
                    'message' => $response['message']
                ];
            } else {
                return [
                    'success' => false,
                    'message' => isset($response['message']) ? $response['message'] : 'Unknown error'
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Make HTTP request to Comgate API
     */
    private function makeRequest($endpoint, $data) {
        $url = $this->apiUrl . $endpoint;
        
        // Prepare POST data
        $postData = http_build_query($data);
        
        // Initialize cURL
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: application/x-www-form-urlencoded',
                'User-Agent: HostBill-Comgate-Module/1.0.0'
            ]
        ]);
        
        // Execute request
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        // Check for cURL errors
        if ($error) {
            throw new Exception('cURL error: ' . $error);
        }
        
        // Check HTTP status
        if ($httpCode !== 200) {
            throw new Exception('HTTP error: ' . $httpCode);
        }
        
        // Log request/response if debug mode is enabled
        if (isset($this->config['debug_mode']) && $this->config['debug_mode'] === 'yes') {
            logActivity('Comgate API Request: ' . $endpoint . ' - ' . $postData);
            logActivity('Comgate API Response: ' . $response);
        }
        
        // Parse response based on endpoint
        if ($endpoint === 'methods' && strpos($response, '{') === 0) {
            // JSON response for methods endpoint
            return json_decode($response, true);
        } else {
            // URL-encoded response for other endpoints
            parse_str($response, $parsedResponse);
            return $parsedResponse;
        }
    }
    
    /**
     * Validate callback data
     */
    public function validateCallback($data) {
        // Required fields for callback validation
        $requiredFields = ['merchant', 'test', 'price', 'curr', 'refId', 'transId', 'secret', 'status'];
        
        foreach ($requiredFields as $field) {
            if (!isset($data[$field])) {
                return [
                    'success' => false,
                    'message' => 'Missing required field: ' . $field
                ];
            }
        }
        
        // Validate merchant ID
        if ($data['merchant'] !== $this->config['merchant_id']) {
            return [
                'success' => false,
                'message' => 'Invalid merchant ID'
            ];
        }
        
        // Validate secret
        if ($data['secret'] !== $this->config['secret']) {
            return [
                'success' => false,
                'message' => 'Invalid secret'
            ];
        }
        
        // Validate test mode
        $expectedTestMode = ($this->config['test_mode'] === 'yes') ? 'true' : 'false';
        if ($data['test'] !== $expectedTestMode) {
            return [
                'success' => false,
                'message' => 'Test mode mismatch'
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Callback validation successful'
        ];
    }
    
    /**
     * Get status description
     */
    public function getStatusDescription($status) {
        $statuses = [
            'PENDING' => 'Payment is pending - final result is not known yet',
            'PAID' => 'Payment was successfully completed',
            'CANCELLED' => 'Payment was not completed correctly and is cancelled',
            'AUTHORIZED' => 'Pre-authorization was successful'
        ];
        
        return isset($statuses[$status]) ? $statuses[$status] : 'Unknown status';
    }
    
    /**
     * Format amount from cents to currency
     */
    public function formatAmount($cents, $currency = 'CZK') {
        $amount = $cents / 100;
        
        switch ($currency) {
            case 'HUF':
                return number_format($amount, 0, ',', ' ') . ' ' . $currency;
            default:
                return number_format($amount, 2, ',', ' ') . ' ' . $currency;
        }
    }
    
    /**
     * Get test connection status
     */
    public function testConnection() {
        try {
            $result = $this->getPaymentMethods([
                'merchant' => $this->config['merchant_id'],
                'secret' => $this->config['secret'],
                'type' => 'json'
            ]);
            
            if ($result['success']) {
                return [
                    'success' => true,
                    'message' => 'Connection to Comgate API successful',
                    'methods_count' => count($result['methods'])
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Connection failed: ' . $result['message']
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Connection error: ' . $e->getMessage()
            ];
        }
    }
}
?>
