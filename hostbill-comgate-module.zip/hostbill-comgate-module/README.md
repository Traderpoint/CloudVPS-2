# HostBill Comgate Payment Gateway Module

## 🎯 **Oficiální Comgate platební brána pro HostBill**

Kompletní integrace Comgate platební brány do HostBill systému s podporou všech platebních metod včetně karet, bankovních převodů a mobilních plateb.

### ✅ **Klíčové funkce:**
- ✅ **Všechny platební metody** - karty, bankovní převody, mobilní platby
- ✅ **Automatické callback** - okamžité zpracování plateb
- ✅ **Test i produkční režim** - bezpečné testování
- ✅ **Předautorizace** - podpora pre-auth plateb
- ✅ **Refundace** - vrácení plateb přímo z HostBill
- ✅ **Admin dashboard** - kompletní správa a monitoring
- ✅ **Bezpečnost** - šifrovaná komunikace a validace
- ✅ **Logování** - detailní záznamy pro debugging

---

## **🚀 Rychlá instalace (5 minut)**

### **1. Zkopírování souborů:**
```bash
# Zkopírujte modul do HostBill
cp -r hostbill-comgate-module/ /path/to/hostbill/modules/gateways/comgate/
```

### **2. Spuštění instalace:**
```bash
cd /path/to/hostbill/modules/gateways/comgate/
php install.php install
```

### **3. Aktivace v HostBill:**
1. **Admin** → **Setup** → **Payment Gateways**
2. **Najděte**: "Comgate Payment Gateway"
3. **Klikněte**: **Activate**

### **4. Konfigurace:**
1. **Vyplňte Merchant ID** (z Comgate portálu)
2. **Vyplňte Secret Key** (z Comgate portálu)
3. **Nastavte Test Mode** na "Yes" pro testování
4. **Uložte konfiguraci**

---

## **📁 Struktura modulu**

```
hostbill-comgate-module/
├── comgate.php              # Hlavní modul soubor
├── comgate-client.php       # Comgate API client
├── callback.php             # Callback handler (push notifikace)
├── return.php               # Return handler (návrat zákazníků)
├── admin.php                # Admin interface
├── install.php              # Instalační skript
├── test-module.php          # Test suite
└── README.md                # Tato dokumentace
```

---

## **⚙️ Konfigurace**

### **A) Základní nastavení:**
- **Merchant ID**: Váš identifikátor z Comgate portálu
- **Secret Key**: Tajný klíč pro komunikaci na pozadí
- **Test Mode**: Zapnuto pro testování, vypnuto pro produkci
- **Payment Methods**: "ALL" nebo konkrétní metody (např. "CARD_CZ")

### **B) Pokročilé nastavení:**
- **Country**: Výchozí země (CZ, SK, atd.)
- **Language**: Jazyk platební brány (cs, en, sk)
- **Auto Redirect**: Automatické přesměrování na bránu
- **Embedded Mode**: Zobrazení brány v iframe
- **Pre-authorization**: Předautorizace kartových plateb
- **Debug Mode**: Detailní logování

### **C) Callback URL konfigurace:**
V Comgate portálu nastavte:
```
Push notification URL: https://your-domain.com/modules/gateways/comgate/callback.php
```

---

## **🧪 Testování**

### **Automatické testy:**
```bash
cd /path/to/hostbill/modules/gateways/comgate/
php test-module.php test
```

### **Test připojení s credentials:**
```bash
php test-module.php live YOUR_MERCHANT_ID YOUR_SECRET
```

### **Test instalace:**
```bash
php install.php test
```

---

## **📊 Admin Dashboard**

### **Přístup:**
**HostBill Admin** → **Setup** → **Payment Gateways** → **Comgate** → **Configure**

### **Funkce dashboardu:**
- ✅ **Stav konfigurace** - kontrola nastavení
- ✅ **Test připojení** - ověření API komunikace
- ✅ **Platební metody** - seznam dostupných metod
- ✅ **Statistiky** - přehled transakcí za 30 dní
- ✅ **Poslední transakce** - monitoring plateb
- ✅ **Callback URL** - informace pro Comgate portál

---

## **🔄 Workflow platby**

### **1. Zákazník klikne "Zaplatit":**
- HostBill vytvoří platbu přes Comgate API
- Zákazník je přesměrován na Comgate bránu

### **2. Zákazník zaplatí:**
- Comgate zpracuje platbu
- Zákazník je vrácen na HostBill

### **3. Callback zpracování:**
- Comgate pošle push notifikaci
- HostBill označí fakturu jako zaplacenou
- Zákazník obdrží potvrzení

---

## **🛡️ Bezpečnost**

### **Implementované funkce:**
- ✅ **HTTPS komunikace** - šifrovaný přenos dat
- ✅ **Secret key validace** - ověření callback požadavků
- ✅ **IP whitelisting** - omezení přístupu k callback
- ✅ **Merchant ID validace** - kontrola identity
- ✅ **Test mode kontrola** - oddělení test/produkce
- ✅ **SQL injection ochrana** - bezpečné databázové dotazy
- ✅ **XSS ochrana** - escapování výstupů

---

## **📋 Podporované platební metody**

### **Karty:**
- Visa, Mastercard, Maestro
- Apple Pay, Google Pay
- 3D Secure ověření

### **Bankovní převody:**
- Všechny české banky
- Slovenské banky
- SEPA převody

### **Mobilní platby:**
- SMS platby
- Premium SMS

### **Ostatní:**
- PayPal
- Bitcoiny
- Platební tlačítka

---

## **🔧 API Funkce**

### **Základní operace:**
- `createPayment()` - Vytvoření platby
- `getPaymentStatus()` - Kontrola stavu platby
- `getPaymentMethods()` - Seznam platebních metod

### **Pokročilé operace:**
- `refundPayment()` - Vrácení platby
- `capturePreauth()` - Potvrzení předautorizace
- `cancelPreauth()` - Zrušení předautorizace
- `createRecurringPayment()` - Opakované platby

### **Utility funkce:**
- `validateCallback()` - Validace callback dat
- `testConnection()` - Test API připojení
- `formatAmount()` - Formátování částek

---

## **📈 Monitoring a logování**

### **Activity Log:**
Všechny operace jsou logovány v HostBill Activity Log:
- Vytvoření platby
- Callback zpracování
- Chyby a výjimky
- API komunikace (v debug módu)

### **Databázové tabulky:**
- `mod_comgate_transactions` - transakce
- `mod_comgate_callbacks` - callback logy
- `mod_comgate_config` - konfigurace

---

## **🔍 Troubleshooting**

### **Časté problémy:**

#### **❌ "Connection failed"**
- **Problém**: Nesprávné API credentials
- **Řešení**: Zkontrolujte Merchant ID a Secret v Comgate portálu

#### **❌ "Callback not received"**
- **Problém**: Nesprávná callback URL
- **Řešení**: Nastavte správnou URL v Comgate portálu

#### **❌ "Payment not marked as paid"**
- **Problém**: Callback validace selhala
- **Řešení**: Zkontrolujte secret key a test mode

#### **❌ "Module not found"**
- **Problém**: Soubory nejsou správně zkopírovány
- **Řešení**: Zkontrolujte cestu `/modules/gateways/comgate/`

### **Debug kroky:**
1. **Zapněte Debug Mode** v konfiguraci
2. **Zkontrolujte Activity Log** v HostBill
3. **Spusťte test suite**: `php test-module.php test`
4. **Test připojení**: Admin dashboard → Test Connection

---

## **📞 Podpora**

### **Dokumentace:**
- **Comgate API**: https://help.comgate.cz/docs/api-protokol
- **HostBill**: https://hostbillapp.com/docs/

### **Při problémech:**
1. **Zkontrolujte logy**: HostBill Activity Log
2. **Spusťte testy**: `php test-module.php test`
3. **Ověřte konfiguraci**: Admin dashboard
4. **Kontaktujte podporu**: S detailními logy

---

## **🎉 Výhody HostBill Comgate modulu**

### **✅ Pro administrátory:**
- **Snadná instalace** - automatický instalační skript
- **Kompletní admin GUI** - dashboard s monitoring
- **Detailní logování** - sledování všech operací
- **Bezpečnost** - implementované best practices

### **✅ Pro zákazníky:**
- **Všechny platební metody** - karty, banky, mobily
- **Rychlé platby** - optimalizovaný workflow
- **Bezpečné platby** - 3D Secure a šifrování
- **Mobilní optimalizace** - responzivní design

### **✅ Pro vývojáře:**
- **Čistý kód** - PSR standardy
- **Kompletní dokumentace** - všechny funkce popsány
- **Test suite** - automatické testování
- **Modulární architektura** - snadné rozšíření

## **📖 Detailní instalační návod**

### **Krok 1: Příprava (2 minuty)**

#### **A) Stažení modulu:**
```bash
# Zkopírujte složku hostbill-comgate-module do HostBill
cp -r hostbill-comgate-module/ /var/www/hostbill/modules/gateways/comgate/
```

#### **B) Nastavení oprávnění (Linux):**
```bash
chown -R www-data:www-data /var/www/hostbill/modules/gateways/comgate/
chmod -R 644 /var/www/hostbill/modules/gateways/comgate/
chmod 755 /var/www/hostbill/modules/gateways/comgate/
```

### **Krok 2: Instalace (1 minuta)**

```bash
cd /var/www/hostbill/modules/gateways/comgate/
php install.php install
```

**Očekávaný výstup:**
```
🚀 Installing HostBill Comgate Payment Gateway Module...
1️⃣ Creating database tables...
✅ Database tables created successfully
2️⃣ Registering module in HostBill...
✅ Module registered successfully
3️⃣ Setting default configuration...
✅ Default configuration set
4️⃣ Setting up callback URLs...
✅ Callback URLs configured
5️⃣ Setting file permissions...
✅ File permissions set

🎉 HostBill Comgate Payment Gateway Module installed successfully!
```

### **Krok 3: Aktivace v HostBill (1 minuta)**

1. **Přihlaste se** do HostBill Admin
2. **Jděte na**: **Setup** → **Payment Gateways**
3. **Najděte**: "Comgate Payment Gateway"
4. **Klikněte**: **Activate**
5. **Ověřte**: Status "Active" se zeleným indikátorem

### **Krok 4: Konfigurace Comgate portálu (5 minut)**

#### **A) Přihlášení do Comgate:**
1. **Otevřete**: https://portal.comgate.cz/
2. **Přihlaste se** s vašimi credentials
3. **Jděte na**: **Nastavení obchodu**

#### **B) Získání credentials:**
1. **Merchant ID**: Najděte v sekci "Základní údaje"
2. **Secret Key**: Vygenerujte v sekci "API klíče"
3. **Poznamenejte si** oba údaje

#### **C) Nastavení callback URL:**
1. **Jděte na**: **Push notifikace**
2. **URL**: `https://your-domain.com/modules/gateways/comgate/callback.php`
3. **Metoda**: POST
4. **Uložte** nastavení

### **Krok 5: Konfigurace HostBill (2 minuty)**

1. **HostBill Admin** → **Setup** → **Payment Gateways**
2. **Comgate Payment Gateway** → **Configure**
3. **Vyplňte**:
   - **Merchant ID**: Z Comgate portálu
   - **Secret Key**: Z Comgate portálu
   - **Test Mode**: "Yes" pro testování
   - **Payment Methods**: "ALL"
   - **Country**: "CZ"
   - **Language**: "cs"
4. **Uložte** konfiguraci

### **Krok 6: Test a ověření (2 minuty)**

#### **A) Test připojení:**
1. **V HostBill konfiguraci** klikněte: **Test Connection**
2. **Očekávaný výsledek**: ✅ "Connection Successful!"
3. **Pokud chyba**: Zkontrolujte credentials

#### **B) Test platby:**
1. **Vytvořte testovací fakturu** v HostBill
2. **Klikněte "Pay Now"** → Vyberte Comgate
3. **Ověřte přesměrování** na Comgate bránu
4. **Proveďte testovací platbu**
5. **Zkontrolujte callback** v Activity Log

---

## **🎯 Produkční nasazení**

### **Přepnutí do produkce:**
1. **Test Mode**: Změňte na "No"
2. **Comgate portál**: Přepněte na produkční režim
3. **Test platby**: Proveďte s malou částkou
4. **Monitoring**: Sledujte Activity Log

### **Doporučení pro produkci:**
- ✅ **Backup** databáze před nasazením
- ✅ **SSL certifikát** pro callback URL
- ✅ **Monitoring** plateb prvních 24 hodin
- ✅ **Dokumentace** pro zákazníky

**HostBill Comgate modul je připraven k produkčnímu nasazení! 🚀**
