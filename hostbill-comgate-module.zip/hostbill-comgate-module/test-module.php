<?php
/**
 * Comgate Payment Gateway Module Test Suite
 * 
 * Comprehensive testing suite for HostBill Comgate payment gateway module
 * Tests all functionality including API communication, callbacks, and admin features
 * 
 * @version 1.0.0
 */

// Prevent direct access
if (php_sapi_name() !== 'cli') {
    die('This script can only be run from command line');
}

// Include required files
require_once 'comgate-client.php';

/**
 * Main test runner
 */
function run_comgate_tests() {
    echo "🧪 HostBill Comgate Payment Gateway Module - Test Suite\n";
    echo "═══════════════════════════════════════════════════════\n";
    
    $tests = [
        'Module Configuration' => test_module_configuration(),
        'API Client Initialization' => test_api_client_initialization(),
        'Payment Methods Retrieval' => test_payment_methods_retrieval(),
        'Payment Creation' => test_payment_creation(),
        'Payment Status Check' => test_payment_status_check(),
        'Callback Validation' => test_callback_validation(),
        'Refund Processing' => test_refund_processing(),
        'Pre-authorization' => test_preauthorization(),
        'Error Handling' => test_error_handling(),
        'Security Features' => test_security_features()
    ];
    
    $passed = 0;
    $total = count($tests);
    
    foreach ($tests as $testName => $result) {
        echo "\n" . str_pad($testName, 40, '.') . ' ';
        
        if ($result['success']) {
            echo "✅ PASSED\n";
            if (!empty($result['details'])) {
                echo "   " . $result['details'] . "\n";
            }
            $passed++;
        } else {
            echo "❌ FAILED\n";
            echo "   Error: " . $result['error'] . "\n";
        }
    }
    
    echo "\n" . str_repeat('═', 55) . "\n";
    echo "📊 Test Results: " . $passed . "/" . $total . " tests passed\n";
    
    if ($passed === $total) {
        echo "🎉 All tests passed! Module is ready for production.\n";
        return true;
    } else {
        echo "⚠️ Some tests failed. Please review and fix issues.\n";
        return false;
    }
}

/**
 * Test module configuration
 */
function test_module_configuration() {
    try {
        // Test if main module file exists and is readable
        if (!file_exists('comgate.php') || !is_readable('comgate.php')) {
            return ['success' => false, 'error' => 'Main module file not found or not readable'];
        }
        
        // Test configuration function
        include_once 'comgate.php';
        
        if (!function_exists('comgate_config')) {
            return ['success' => false, 'error' => 'Configuration function not found'];
        }
        
        $config = comgate_config();
        
        // Validate configuration structure
        $requiredFields = ['name', 'description', 'version', 'fields'];
        foreach ($requiredFields as $field) {
            if (!isset($config[$field])) {
                return ['success' => false, 'error' => 'Missing configuration field: ' . $field];
            }
        }
        
        // Validate required configuration fields
        $requiredConfigFields = ['merchant_id', 'secret', 'test_mode'];
        foreach ($requiredConfigFields as $field) {
            if (!isset($config['fields'][$field])) {
                return ['success' => false, 'error' => 'Missing required config field: ' . $field];
            }
        }
        
        return [
            'success' => true,
            'details' => 'Configuration valid with ' . count($config['fields']) . ' fields'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test API client initialization
 */
function test_api_client_initialization() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes',
            'debug_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        if (!$client instanceof ComgateClient) {
            return ['success' => false, 'error' => 'Failed to create ComgateClient instance'];
        }
        
        return [
            'success' => true,
            'details' => 'ComgateClient initialized successfully'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test payment methods retrieval
 */
function test_payment_methods_retrieval() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        // Test with invalid credentials (should fail gracefully)
        $result = $client->getPaymentMethods([
            'merchant' => 'INVALID',
            'secret' => 'INVALID',
            'type' => 'json'
        ]);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid response structure'];
        }
        
        // Should fail with invalid credentials
        if ($result['success']) {
            return ['success' => false, 'error' => 'Should fail with invalid credentials'];
        }
        
        return [
            'success' => true,
            'details' => 'Payment methods API call handled correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test payment creation
 */
function test_payment_creation() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        $paymentData = [
            'merchant' => 'INVALID',
            'price' => 10000, // 100.00 CZK
            'curr' => 'CZK',
            'label' => 'Test Payment',
            'refId' => 'TEST_' . time(),
            'method' => 'ALL',
            'test' => 'true',
            'prepareOnly' => 'true',
            'secret' => 'INVALID'
        ];
        
        $result = $client->createPayment($paymentData);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid response structure'];
        }
        
        // Should fail with invalid credentials
        if ($result['success']) {
            return ['success' => false, 'error' => 'Should fail with invalid credentials'];
        }
        
        return [
            'success' => true,
            'details' => 'Payment creation API call handled correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test payment status check
 */
function test_payment_status_check() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        $statusData = [
            'merchant' => 'INVALID',
            'transId' => 'TEST-TRANS-ID',
            'secret' => 'INVALID'
        ];
        
        $result = $client->getPaymentStatus($statusData);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid response structure'];
        }
        
        return [
            'success' => true,
            'details' => 'Payment status API call handled correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test callback validation
 */
function test_callback_validation() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        // Test valid callback data
        $validCallbackData = [
            'merchant' => 'TEST123456',
            'test' => 'true',
            'price' => '10000',
            'curr' => 'CZK',
            'refId' => 'TEST123',
            'transId' => 'TEST-TRANS-ID',
            'secret' => 'test_secret_key',
            'status' => 'PAID'
        ];
        
        $result = $client->validateCallback($validCallbackData);
        
        if (!$result['success']) {
            return ['success' => false, 'error' => 'Valid callback data rejected: ' . $result['message']];
        }
        
        // Test invalid callback data (wrong secret)
        $invalidCallbackData = $validCallbackData;
        $invalidCallbackData['secret'] = 'wrong_secret';
        
        $result = $client->validateCallback($invalidCallbackData);
        
        if ($result['success']) {
            return ['success' => false, 'error' => 'Invalid callback data accepted'];
        }
        
        return [
            'success' => true,
            'details' => 'Callback validation working correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test refund processing
 */
function test_refund_processing() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        $refundData = [
            'merchant' => 'INVALID',
            'transId' => 'TEST-TRANS-ID',
            'secret' => 'INVALID',
            'amount' => 5000, // 50.00 CZK
            'test' => 'true'
        ];
        
        $result = $client->refundPayment($refundData);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid response structure'];
        }
        
        return [
            'success' => true,
            'details' => 'Refund API call handled correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test pre-authorization
 */
function test_preauthorization() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        // Test capture
        $captureData = [
            'merchant' => 'INVALID',
            'transId' => 'TEST-TRANS-ID',
            'secret' => 'INVALID',
            'amount' => 10000
        ];
        
        $result = $client->capturePreauth($captureData);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid capture response structure'];
        }
        
        // Test cancel
        $cancelData = [
            'merchant' => 'INVALID',
            'transId' => 'TEST-TRANS-ID',
            'secret' => 'INVALID'
        ];
        
        $result = $client->cancelPreauth($cancelData);
        
        if (!isset($result['success'])) {
            return ['success' => false, 'error' => 'Invalid cancel response structure'];
        }
        
        return [
            'success' => true,
            'details' => 'Pre-authorization API calls handled correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test error handling
 */
function test_error_handling() {
    try {
        $testConfig = [
            'merchant_id' => 'TEST123456',
            'secret' => 'test_secret_key',
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        // Test with completely invalid data
        $invalidData = [
            'invalid_field' => 'invalid_value'
        ];
        
        $result = $client->createPayment($invalidData);
        
        // Should handle error gracefully
        if (!isset($result['success']) || $result['success']) {
            return ['success' => false, 'error' => 'Error not handled properly'];
        }
        
        if (!isset($result['message'])) {
            return ['success' => false, 'error' => 'Error message not provided'];
        }
        
        return [
            'success' => true,
            'details' => 'Error handling working correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test security features
 */
function test_security_features() {
    try {
        // Test file access protection
        $protectedFiles = ['comgate.php', 'comgate-client.php', 'admin.php'];
        
        foreach ($protectedFiles as $file) {
            if (!file_exists($file)) {
                continue;
            }
            
            $content = file_get_contents($file);
            
            // Check for HostBill protection
            if (strpos($content, "if (!defined('HOSTBILL'))") === false) {
                return ['success' => false, 'error' => 'Missing HostBill protection in ' . $file];
            }
        }
        
        // Test callback file protection
        if (file_exists('callback.php')) {
            $content = file_get_contents('callback.php');
            
            // Should include HostBill configuration
            if (strpos($content, 'configuration.php') === false) {
                return ['success' => false, 'error' => 'Callback file missing HostBill configuration'];
            }
        }
        
        return [
            'success' => true,
            'details' => 'Security features implemented correctly'
        ];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

/**
 * Test connection to Comgate API (requires valid credentials)
 */
function test_live_connection($merchantId, $secret) {
    try {
        $testConfig = [
            'merchant_id' => $merchantId,
            'secret' => $secret,
            'test_mode' => 'yes'
        ];
        
        $client = new ComgateClient($testConfig);
        
        $result = $client->testConnection();
        
        if ($result['success']) {
            echo "✅ Live connection test: PASSED\n";
            echo "   Available payment methods: " . $result['methods_count'] . "\n";
            return true;
        } else {
            echo "❌ Live connection test: FAILED\n";
            echo "   Error: " . $result['message'] . "\n";
            return false;
        }
        
    } catch (Exception $e) {
        echo "❌ Live connection test: ERROR\n";
        echo "   Exception: " . $e->getMessage() . "\n";
        return false;
    }
}

// Command line interface
if (php_sapi_name() === 'cli') {
    $action = isset($argv[1]) ? $argv[1] : 'test';
    
    switch ($action) {
        case 'test':
            run_comgate_tests();
            break;
        case 'live':
            if (!isset($argv[2]) || !isset($argv[3])) {
                echo "Usage: php test-module.php live <merchant_id> <secret>\n";
                exit(1);
            }
            test_live_connection($argv[2], $argv[3]);
            break;
        case 'help':
        default:
            echo "HostBill Comgate Payment Gateway Module Test Suite\n";
            echo "Usage: php test-module.php [action]\n";
            echo "Actions:\n";
            echo "  test              - Run all tests\n";
            echo "  live <id> <secret> - Test live connection with credentials\n";
            echo "  help              - Show this help message\n";
            break;
    }
}
?>
