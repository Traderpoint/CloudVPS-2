<?php
/**
 * HostBill Comgate Payment Gateway Module
 * 
 * Official Comgate payment gateway integration for HostBill
 * Supports all Comgate payment methods including cards, bank transfers, and mobile payments
 * 
 * @version 1.0.0
 * @author HostBill Comgate Module
 * @link https://help.comgate.cz/docs/api-protokol
 */

if (!defined('HOSTBILL')) {
    die('Unauthorized access');
}

/**
 * Module configuration
 */
function comgate_config() {
    return [
        'name' => 'Comgate Payment Gateway',
        'description' => 'Official Comgate payment gateway integration with support for all payment methods',
        'version' => '1.0.0',
        'author' => 'HostBill Comgate Module',
        'fields' => [
            'merchant_id' => [
                'name' => 'Merchant ID',
                'description' => 'Your Comgate merchant identifier (found in Comgate client portal)',
                'type' => 'text',
                'required' => true
            ],
            'secret' => [
                'name' => 'Secret Key',
                'description' => 'Secret key for background communication (found in Comgate client portal)',
                'type' => 'password',
                'required' => true
            ],
            'test_mode' => [
                'name' => 'Test Mode',
                'description' => 'Enable test mode for development and testing',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'payment_methods' => [
                'name' => 'Payment Methods',
                'description' => 'Allowed payment methods (ALL for all methods, or specific method IDs)',
                'type' => 'text',
                'default' => 'ALL'
            ],
            'country' => [
                'name' => 'Country',
                'description' => 'Default country code (CZ, SK, etc.)',
                'type' => 'text',
                'default' => 'CZ'
            ],
            'language' => [
                'name' => 'Language',
                'description' => 'Payment gateway language (cs, en, sk, etc.)',
                'type' => 'text',
                'default' => 'cs'
            ],
            'auto_redirect' => [
                'name' => 'Auto Redirect',
                'description' => 'Automatically redirect to payment gateway',
                'type' => 'yesno',
                'default' => 'yes'
            ],
            'embedded_mode' => [
                'name' => 'Embedded Mode',
                'description' => 'Display payment gateway in iframe',
                'type' => 'yesno',
                'default' => 'no'
            ],
            'preauth' => [
                'name' => 'Pre-authorization',
                'description' => 'Enable pre-authorization for card payments',
                'type' => 'yesno',
                'default' => 'no'
            ],
            'debug_mode' => [
                'name' => 'Debug Mode',
                'description' => 'Enable detailed logging for troubleshooting',
                'type' => 'yesno',
                'default' => 'no'
            ]
        ]
    ];
}

/**
 * Module activation
 */
function comgate_activate() {
    // Create callback URL configuration
    $callback_url = App::getUrl() . '/modules/gateways/comgate/callback.php';
    
    // Log activation
    logActivity('Comgate Payment Gateway activated');
    
    return [
        'status' => 'success',
        'description' => 'Comgate Payment Gateway activated successfully. Configure your callback URL in Comgate portal: ' . $callback_url
    ];
}

/**
 * Module deactivation
 */
function comgate_deactivate() {
    logActivity('Comgate Payment Gateway deactivated');
    
    return [
        'status' => 'success',
        'description' => 'Comgate Payment Gateway deactivated successfully'
    ];
}

/**
 * Generate payment link
 */
function comgate_link($params) {
    try {
        // Load Comgate client
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        // Prepare payment data
        $paymentData = [
            'merchant' => $params['merchant_id'],
            'price' => intval($params['amount'] * 100), // Convert to cents
            'curr' => $params['currency'],
            'label' => substr($params['description'], 0, 16), // Max 16 characters
            'refId' => $params['invoiceid'],
            'method' => $params['payment_methods'] ?: 'ALL',
            'country' => $params['country'] ?: 'CZ',
            'lang' => $params['language'] ?: 'cs',
            'test' => $params['test_mode'] === 'yes' ? 'true' : 'false',
            'prepareOnly' => 'true', // Always prepare first
            'secret' => $params['secret']
        ];
        
        // Add optional parameters
        if ($params['embedded_mode'] === 'yes') {
            $paymentData['embedded'] = 'true';
        }
        
        if ($params['preauth'] === 'yes') {
            $paymentData['preauth'] = 'true';
        }
        
        // Add customer information
        if (!empty($params['clientdetails']['email'])) {
            $paymentData['email'] = $params['clientdetails']['email'];
        }
        
        if (!empty($params['clientdetails']['phonenumber'])) {
            $paymentData['phone'] = $params['clientdetails']['phonenumber'];
        }
        
        // Add callback URLs
        $base_url = App::getUrl();
        $paymentData['returnUrl'] = $base_url . '/modules/gateways/comgate/return.php?invoiceid=' . $params['invoiceid'];
        $paymentData['notifyUrl'] = $base_url . '/modules/gateways/comgate/callback.php';
        
        // Create payment
        $result = $client->createPayment($paymentData);
        
        if ($result['success']) {
            // Log successful payment creation
            if ($params['debug_mode'] === 'yes') {
                logActivity('Comgate payment created: ' . $result['transId'] . ' for invoice ' . $params['invoiceid']);
            }
            
            // Store transaction ID for later reference
            update_query('tblinvoices', [
                'notes' => 'Comgate Transaction ID: ' . $result['transId']
            ], ['id' => $params['invoiceid']]);
            
            // Return payment URL
            if ($params['auto_redirect'] === 'yes') {
                // Direct redirect
                return '<script>window.location.href="' . $result['redirect'] . '";</script>';
            } else {
                // Show payment button
                return '<form method="post" action="' . $result['redirect'] . '">
                    <input type="submit" value="Pay with Comgate" class="btn btn-success" />
                </form>';
            }
        } else {
            // Log error
            logActivity('Comgate payment creation failed for invoice ' . $params['invoiceid'] . ': ' . $result['message']);
            
            return '<div class="alert alert-danger">Payment initialization failed: ' . htmlspecialchars($result['message']) . '</div>';
        }
        
    } catch (Exception $e) {
        // Log exception
        logActivity('Comgate payment exception for invoice ' . $params['invoiceid'] . ': ' . $e->getMessage());
        
        return '<div class="alert alert-danger">Payment system error. Please try again later.</div>';
    }
}

/**
 * Capture payment (for pre-authorized payments)
 */
function comgate_capture($params) {
    try {
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        // Get transaction ID from invoice notes
        $invoice = get_query_val('tblinvoices', 'notes', ['id' => $params['invoiceid']]);
        preg_match('/Comgate Transaction ID: ([A-Z0-9\-]+)/', $invoice, $matches);
        
        if (empty($matches[1])) {
            return ['status' => 'error', 'rawdata' => 'Transaction ID not found'];
        }
        
        $transId = $matches[1];
        
        // Capture pre-authorized payment
        $result = $client->capturePreauth([
            'merchant' => $params['merchant_id'],
            'transId' => $transId,
            'secret' => $params['secret'],
            'amount' => intval($params['amount'] * 100)
        ]);
        
        if ($result['success']) {
            logActivity('Comgate payment captured: ' . $transId . ' for invoice ' . $params['invoiceid']);
            return ['status' => 'success', 'transid' => $transId, 'rawdata' => $result['message']];
        } else {
            logActivity('Comgate capture failed: ' . $transId . ' - ' . $result['message']);
            return ['status' => 'error', 'rawdata' => $result['message']];
        }
        
    } catch (Exception $e) {
        logActivity('Comgate capture exception: ' . $e->getMessage());
        return ['status' => 'error', 'rawdata' => $e->getMessage()];
    }
}

/**
 * Refund payment
 */
function comgate_refund($params) {
    try {
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        // Get transaction ID from invoice notes
        $invoice = get_query_val('tblinvoices', 'notes', ['id' => $params['invoiceid']]);
        preg_match('/Comgate Transaction ID: ([A-Z0-9\-]+)/', $invoice, $matches);
        
        if (empty($matches[1])) {
            return ['status' => 'error', 'rawdata' => 'Transaction ID not found'];
        }
        
        $transId = $matches[1];
        
        // Process refund
        $result = $client->refundPayment([
            'merchant' => $params['merchant_id'],
            'transId' => $transId,
            'secret' => $params['secret'],
            'amount' => intval($params['amount'] * 100),
            'test' => $params['test_mode'] === 'yes' ? 'true' : 'false'
        ]);
        
        if ($result['success']) {
            logActivity('Comgate refund processed: ' . $transId . ' for invoice ' . $params['invoiceid']);
            return ['status' => 'success', 'transid' => $transId, 'rawdata' => $result['message']];
        } else {
            logActivity('Comgate refund failed: ' . $transId . ' - ' . $result['message']);
            return ['status' => 'error', 'rawdata' => $result['message']];
        }
        
    } catch (Exception $e) {
        logActivity('Comgate refund exception: ' . $e->getMessage());
        return ['status' => 'error', 'rawdata' => $e->getMessage()];
    }
}

/**
 * Admin area output
 */
function comgate_output($params) {
    // Include admin interface
    require_once dirname(__FILE__) . '/admin.php';
    return comgate_admin_dashboard($params);
}

/**
 * Get available payment methods
 */
function comgate_get_methods($params) {
    try {
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        return $client->getPaymentMethods([
            'merchant' => $params['merchant_id'],
            'secret' => $params['secret'],
            'type' => 'json',
            'lang' => $params['language'] ?: 'cs',
            'curr' => 'CZK'
        ]);
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Test connection to Comgate API
 */
function comgate_test_connection($params) {
    try {
        require_once dirname(__FILE__) . '/comgate-client.php';
        $client = new ComgateClient($params);
        
        // Test with methods call
        $result = $client->getPaymentMethods([
            'merchant' => $params['merchant_id'],
            'secret' => $params['secret'],
            'type' => 'json'
        ]);
        
        return $result;
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * Module information for HostBill
 */
function comgate_info() {
    return [
        'name' => 'Comgate Payment Gateway',
        'version' => '1.0.0',
        'description' => 'Official Comgate payment gateway integration',
        'author' => 'HostBill Comgate Module',
        'type' => 'gateway'
    ];
}
?>
